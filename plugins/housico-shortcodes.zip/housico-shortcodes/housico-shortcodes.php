<?php 
	/*
		Plugin Name: Housico Shortcodes
		Plugin URI: https://themeforest.net/item/housico-ultimate-construction-building-company-theme/21801770
		Author: FlexiPress
		Author URI: http://themeforest.net/user/flexipress
		Description: This plugin is required in order for the theme to work properly. It includes various shortcodes that have been developed exclusively for this theme.
		Version: 1.0
		Text Domain: housico-shortcodes
		Domain Path: /languages
		License: GNU General Public License v2 or later
		License URI: license/README_License.txt
	*/

	if ( !defined('ABSPATH') ) exit();

	// Check if theme license is valid or current theme is 'housico'
	$housico_theme_license = get_option('_housico_theme_license', '', true);
	$housico_theme_info = json_decode(get_option('_housico_theme_info', '', true), true);

	if ( empty($housico_theme_license) or strlen($housico_theme_license) != 36 or (!isset($housico_theme_info['name']) and $housico_theme_info['name'] != 'housico') ) {
		return;
	}

	if( !class_exists('Housico_Shortcodes') ) {
		class Housico_Shortcodes {
			public static $_version = '1.0';
			public static $_dir;
			public static $_url;
			
			public function __construct() {
				// Variables
				self::$_dir = plugin_dir_path( __FILE__ );
				self::$_url = plugin_dir_url( __FILE__ );

				// Functions
				require_once(self::$_dir .'functions.php');

				// Library Files
				require_once(self::$_dir .'lib/twitter/ezTweet.php');
				require_once(self::$_dir .'lib/HousicoVcLoopQueryBuilder.php');

				// Actions
				add_action('init', array($this, 'load_plugin_textdomain'));
				add_action('plugins_loaded', array($this, 'shortcodes'));
				add_action('wp_ajax_housico_get_cf7', array($this, 'get_cf7'));
				add_action('wp_ajax_housico_get_mc4wp', array($this, 'get_mc4wp'));
			}

			// Plugin Textdomain
			public function load_plugin_textdomain() {
				load_plugin_textdomain( 'housico-shortcodes', false, self::$_dir . 'languages/' );
			}

			// Shortcodes
			public function shortcodes() {
				require_once(self::$_dir .'shortcodes/heading.php');
				require_once(self::$_dir .'shortcodes/icon-box.php');
				require_once(self::$_dir .'shortcodes/image-box.php');
				require_once(self::$_dir .'shortcodes/before-after.php');
				require_once(self::$_dir .'shortcodes/animated-svg.php');
				require_once(self::$_dir .'shortcodes/pie-chart.php');
				require_once(self::$_dir .'shortcodes/blog.php');
				require_once(self::$_dir .'shortcodes/counter.php');
				require_once(self::$_dir .'shortcodes/filterable.php');
				require_once(self::$_dir .'shortcodes/filterable-item.php');
				require_once(self::$_dir .'shortcodes/gallery.php');
				require_once(self::$_dir .'shortcodes/gallery-item.php');
				require_once(self::$_dir .'shortcodes/social-networks.php');
				require_once(self::$_dir .'shortcodes/video-section.php');
				require_once(self::$_dir .'shortcodes/map.php');
				require_once(self::$_dir .'shortcodes/mailchimp-form.php');
				require_once(self::$_dir .'shortcodes/contact-form-7.php');
				require_once(self::$_dir .'shortcodes/team-member.php');
				require_once(self::$_dir .'shortcodes/testimonial.php');
				require_once(self::$_dir .'shortcodes/timeline.php');
				require_once(self::$_dir .'shortcodes/countdown.php');
				require_once(self::$_dir .'shortcodes/progress-bar.php');
				require_once(self::$_dir .'shortcodes/client.php');
				require_once(self::$_dir .'shortcodes/pricing-table.php');
				require_once(self::$_dir .'shortcodes/call-to-action.php');
				require_once(self::$_dir .'shortcodes/separator.php');
				require_once(self::$_dir .'shortcodes/image-slider.php');
				require_once(self::$_dir .'shortcodes/carousel.php');
				require_once(self::$_dir .'shortcodes/carousel-item.php');
				require_once(self::$_dir .'shortcodes/button.php');
				require_once(self::$_dir .'shortcodes/others.php');
			}

			// Get Contact Forms 7
			public function get_cf7() {
				$resposne = array();

				if ( !empty($_REQUEST['selected']) ) {
					$selected = @explode(',', $_REQUEST['selected']);
				} else {
					$selected = array();
				}

				$args = array(
					'post_type' => 'wpcf7_contact_form',
					'post_status' => 'publish',
					'posts_per_page' => -1
				);

				$cf7_loop = new WP_Query( $args );

				if ( $cf7_loop->have_posts() ) {
					while ( $cf7_loop->have_posts() ) : $cf7_loop->the_post();
						array_push($resposne, array('id' => get_the_ID(), 'text' => get_the_title(), 'selected' => ((array_search(get_the_ID(), $selected) !== false) ? true : false)));
					endwhile;
				}

				wp_reset_postdata();

				echo json_encode($resposne); exit();
			}

			// Get MailChimp Forms
			public function get_mc4wp() {
				$resposne = array();

				if ( !empty($_REQUEST['selected']) ) {
					$selected = @explode(',', $_REQUEST['selected']);
				} else {
					$selected = array();
				}

				$args = array(
					'post_type' => 'mc4wp-form',
					'post_status' => 'publish',
					'posts_per_page' => -1
				);

				$mc4wp_loop = new WP_Query( $args );

				if ( $mc4wp_loop->have_posts() ) {
					while ( $mc4wp_loop->have_posts() ) : $mc4wp_loop->the_post();
						array_push($resposne, array('id' => get_the_ID(), 'text' => get_the_title(), 'selected' => ((array_search(get_the_ID(), $selected) !== false) ? true : false)));
					endwhile;
				}

				wp_reset_postdata();

				echo json_encode($resposne); exit();
			}
		}
	}

	if ( class_exists('Housico_Shortcodes') ) {
		$Housico_Shortcodes = new Housico_Shortcodes();
	}
?>