<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Image Slider Shortcode
	 *
	 * @param string $atts['ratio']
	 * @param string $atts['show_captions']
	 * @param string $atts['lightbox']
	 * @param string $atts['navigation']
	 * @param string $atts['pagination']
	 * @param string $atts['autoplay']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['images']
	 * @param string $atts['_images'] Only images ids
	 * @param string $atts['css']
	 */

	function housico_image_slider_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"ratio" => "",
			"show_captions" => "",
			"lightbox" => "",
			"navigation" => "",
			"pagination" => "",
			"autoplay" => "",
			"class" => "",
			"images" => "",
			"_images" => "",
			"css" => ""
		), $atts, 'vu_image_slider' );

		if( function_exists('vc_shortcode_custom_css_class') ) {
			$atts['class'] .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim($atts['class']);

		if ( !empty($atts['_images']) ) {
			$images = @explode(',', $atts['_images']);
		} else {
			$images = json_decode(base64_decode($atts['images']), true);
		}

		$slider_options = array();

		$slider_options['singleItem'] = true;
		$slider_options['autoHeight'] = true;
		$slider_options['items'] = 1;
		$slider_options['autoPlay'] = ($atts['autoplay'] == '' || $atts['autoplay'] == '0') ? false : absint($atts['autoplay']);
		$slider_options['stopOnHover'] = true;
		$slider_options['navigation'] = ($atts['navigation'] == 'always' || $atts['navigation'] == 'hover') ? true : false;
		$slider_options['navigationText'] = array('<i class="vu_fp-keyboard_arrow_left"></i>', '<i class="vu_fp-keyboard_arrow_right"></i>');
		$slider_options['rewindNav'] = true;
		$slider_options['scrollPerPage'] = true;
		$slider_options['pagination'] = ($atts['pagination'] == 'always' || $atts['pagination'] == 'hover') ? true : false;
		$slider_options['paginationNumbers'] = false;

		ob_start();
	?>
		<div class="vu_image-slider vu_is-navigation-<?php echo esc_attr($atts['navigation']); ?> vu_is-pagination-<?php echo esc_attr($atts['pagination']); ?> <?php echo ($atts['show_captions'] == '1') ? 'vu_is-with-captions' : 'vu_is-without-captions'; ?> vu_carousel<?php echo ($atts['lightbox'] == '1') ? ' vu_lightbox vu_l-gallery' : ''; ?><?php housico_extra_class($atts['class']); ?>" data-options="<?php echo esc_attr(json_encode($slider_options)); ?>" data-delegate="a.vu_is-lightbox" data-ratio="<?php echo esc_attr($atts['ratio']); ?>">
			<?php 
				if ( is_array($images) and !empty($images) ) {
					foreach ($images as $image) {
						$image_id = (!empty($image['image_id'])) ? absint($image['image_id']) : absint($image);

						echo '<div class="vu_is-item">';
						echo ($atts['lightbox'] == '1') ? '<a href="'. housico_get_attachment_image_src($image_id, 'full') .'" '. ( ($atts['show_captions'] == '1'  && !empty($image['caption'])) ? 'title="'. esc_attr($image['caption']) .'"' : '') .' class="vu_is-lightbox">' : '';
						echo '<figure class="vu_is-i-figure vu_lazy-load" data-img="'. housico_get_attachment_image_src($image_id, 'full') .'">';

						echo wp_get_attachment_image($image_id, 'housico_ratio-'. esc_attr($atts['ratio']));

						if( $atts['show_captions'] == '1' && !empty($image['caption']) ) {
							echo '<figcaption class="vu_is-i-caption">'. esc_html($image['caption']) .'</figcaption>';
						}

						echo '</figure>';
						echo ($atts['lightbox'] == '1') ? '</a>' : '';
						echo '</div>';
					}
				}
			?>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_image_slider', 'housico_image_slider_shortcode');

	/**
	 * Image Slider VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_image_slider extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_image_slider", $atts);

				return do_shortcode( housico_generate_shortcode('vu_image_slider', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Image Slider", 'housico-shortcodes'),
				"description" => esc_html__("Animated slider with images", 'housico-shortcodes'),
				"base"		=> "vu_image_slider",
				"class"		=> "vc_vu_image-slider",
				"icon"		=> "vu_element-icon vu_image-slider-icon",
				"custom_markup" => "",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Ratio", 'housico-shortcodes'),
						"param_name" => "ratio",
						"admin_label" => true,
						"value" => housico_get_image_ratios(),
						"std" => '4:3',
						"save_always" => true,
						"description" => esc_html__("Select image ratio.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show Captions", 'housico-shortcodes'),
						"param_name" => "show_captions",
						"value" => array(esc_html__("Yes, please!", 'housico-shortcodes') => "1"),
						"std" => "0",
						"save_always" => true,
						"description" => esc_html__("Check to show image captions.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Enable lightbox", 'housico-shortcodes'),
						"param_name" => "lightbox",
						"value" => array(esc_html__("Yes, please!", 'housico-shortcodes') => "1"),
						"std" => "0",
						"save_always" => true,
						"description" => esc_html__("Check to open images in lightbox.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Show navigation", 'housico-shortcodes'),
						"param_name" => "navigation",
						"value" => array(
							esc_html__("Never", 'housico-shortcodes') => "none",
							esc_html__("Always", 'housico-shortcodes') => "always",
							esc_html__("Only on hover", 'housico-shortcodes') => "hover"
						),
						"std" => 'hover',
						"save_always" => true,
						"description" => esc_html__("Select when to show navigation.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Show pagination", 'housico-shortcodes'),
						"param_name" => "pagination",
						"value" => array(
							esc_html__("Never", 'housico-shortcodes') => "none",
							esc_html__("Always", 'housico-shortcodes') => "always",
							esc_html__("Only on hover", 'housico-shortcodes') => "hover"
						),
						"std" => 'hover',
						"save_always" => true,
						"description" => esc_html__("Select when to show pagination.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Auto play", 'housico-shortcodes'),
						"param_name" => "autoplay",
						"value" => "",
						"save_always" => true,
						"description" => wp_kses( __("Change to any integrer for example <b>5000</b> to play every <b>5</b> seconds. Leave blank to disable autoplay.", 'housico-shortcodes'), array('b' => array()) )
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Images', 'housico-shortcodes'),
						"type" => "universal",
						"heading" => esc_html__("Images", 'housico-shortcodes'),
						"param_name" => "images",
						"template" => '<div class="vc_row"><div class="vc_col-xs-6 vu_m-b-10 vu_p-r-5"><div class="wpb_element_label">'. esc_html__('Image', 'housico-shortcodes') .'</div><div class="vu_param_media vc_clearfix"><div class="vu_param_m-img-holder"><span class="vu_param_m-img"></span></div><div class="vu_param_m-content"><input type="hidden" name="image_id" class="vu_param_m-img-id"><input type="text" name="image_url" class="vu_param_m-img-url" readonly="readonly" placeholder="'. esc_attr__('No image selected.', 'housico-shortcodes') .'"><button type="button" class="vu_param_m-btn vu_as-param" data-control="upload" data-title="'. esc_attr__('Add Image', 'housico-shortcodes') .'" data-button="'. esc_attr__('Add Image', 'housico-shortcodes') .'">'. esc_html__('Upload', 'housico-shortcodes') .'</button><button type="button" class="vu_param_m-btn vu_as-param" data-control="remove">'. esc_html__('Remove', 'housico-shortcodes') .'</button></div></div></div><div class="vc_col-xs-6 vu_m-b-10"><div class="wpb_element_label">'. esc_html__('Caption', 'housico-shortcodes') .'</div><textarea name="caption" rows="3" style="height:80px;"></textarea></div></div>',
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Add images.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Design Options", 'housico-shortcodes' ),
						"type" => "css_editor",
						"heading" => esc_html__("CSS box", 'housico-shortcodes' ),
						"param_name" => "css"
					)
				)
			)
		);
	}
?>