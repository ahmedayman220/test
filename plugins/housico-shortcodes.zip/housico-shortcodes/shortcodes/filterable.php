<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Filterable Shortcode
	 *
	 * @param string $atts['filter_style']
	 * @param string $atts['alignment']
	 * @param string $atts['layout']
	 * @param string $atts['style']
	 * @param string $atts['category_text']
	 * @param string $atts['categories']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['css']
	 */

	function housico_filterable_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"filter_style" => "",
			"alignment" => "",
			"layout" => "",
			"style" => "",
			"class" => "",
			"categories" => "",
			"css" => "",
		), $atts, 'vu_filterable' );

		ob_start();
	?>
		<div class="vu_filterable vu_f-alignment-<?php echo esc_attr($atts['alignment']); ?> vu_f-layout-<?php echo esc_attr($atts['layout']); ?> vu_f-style-<?php echo esc_attr($atts['style']); ?><?php housico_extra_class($atts['class']); ?>">
			<div class="vu_f-filters vu_f-filters-style-<?php echo esc_attr($atts['filter_style']); ?>">
				<?php 
					$categories = @json_decode(base64_decode($atts['categories']), true);

					if( is_array($categories) ) {
						$num = 0;

						foreach ($categories as $category) {
							if ( $num <= 0 ) {
								echo '<span class="vu_f-filter active" data-filter="*"><span class="vu_f-filter-icon"><i class="'. esc_attr($category['icon']) .'"></i></span><span class="vu_f-filter-name">'. esc_html($category['name']) .'</span></span>';
							} else {
								echo '<span class="vu_f-filter" data-filter=".'. esc_attr(md5(sanitize_title($category['name']))) .'"><span class="vu_f-filter-icon"><i class="'. esc_attr($category['icon']) .'"></i></span><span class="vu_f-filter-name">'. esc_html($category['name']) .'</span></span>';
							}

							$num++;
						}
					}
				?>
			</div>

			<div class="vu_f-items">
				<?php echo do_shortcode($content); ?>
			</div>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_filterable', 'housico_filterable_shortcode');

	/**
	 * Filterable VC Shortcode
	 */

	if( class_exists('WPBakeryShortCodesContainer') ) {
		class WPBakeryShortCode_vu_filterable extends WPBakeryShortCodesContainer {
		}

		vc_map(
			array(
				"name"		=> esc_html__("Filterable", 'housico-shortcodes'),
				"description" => esc_html__("Filter anything", 'housico-shortcodes'),
				"base"		=> "vu_filterable",
				"class"		=> "vc_vu_filterable",
				"icon"		=> "vu_element-icon vu_filterable-icon",
				"controls"	=> "full",
				"as_parent" => array( 'only' => 'vu_filterable_item' ),
				"js_view" => 'VcColumnView',
				"content_element" => true,
				"is_container" => true,
				"container_not_allowed" => false,
				"category"  => esc_html__('Housico', 'housico-shortcodes'),
				'default_content' => '[vu_filterable_item][/vu_filterable_item]',
				"params"	=> array(
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "image_select",
						"heading" => esc_html__("Filter Style", 'housico-shortcodes'),
						"param_name" => "filter_style",
						"value" => array(
							"1" => array(
									"title" => esc_html__("#1", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/filterable-styles/1.jpg"
								),
							"2" => array(
									"title" => esc_html__("#2", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/filterable-styles/2.jpg"
								)
						),
						"width" => "calc(50% - 10px)",
						"height" => "auto",
						"std" => "1",
						"save_always" => true,
						"description" => esc_html__("Select filter style.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Alignment", 'housico-shortcodes'),
						"param_name" => "alignment",
						"value" => array(
							esc_html__('Left', 'housico-shortcodes') => 'left',
							esc_html__('Center', 'housico-shortcodes') => 'center',
							esc_html__('Right', 'housico-shortcodes') => 'right'
						),
						"std" => "center",
						"save_always" => true,
						"description" => esc_html__("Select filter alignment.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Layout", 'housico-shortcodes'),
						"param_name" => "layout",
						"value" => array(
							esc_html__("1 Column", 'housico-shortcodes') => '1',
							esc_html__("2 Columns", 'housico-shortcodes') => '2',
							esc_html__("3 Columns", 'housico-shortcodes') => '3',
							esc_html__("4 Columns", 'housico-shortcodes') => '4',
							esc_html__("5 Columns", 'housico-shortcodes') => '5',
							esc_html__("6 Columns", 'housico-shortcodes') => '6'
						),
						"std" => "3",
						"save_always" => true,
						"description" => esc_html__("Select filterable layout.", 'housico-shortcodes'),
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Style", 'housico-shortcodes'),
						"param_name" => "style",
						"value" => array(
							esc_html__("With Space", 'housico-shortcodes') => 'with-space',
							esc_html__("Without Space", 'housico-shortcodes') => 'without-space'
						),
						"save_always" => true,
						"description" => esc_html__("Select filterable style.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Categories', 'housico-shortcodes'),
						"type" => "universal",
						"heading" => esc_html__("Categories", 'housico-shortcodes'),
						"param_name" => "categories",
						"template" => '<div class="vc_row"><div class="vc_col-xs-3 vu_m-b-10"><div class="wpb_element_label">'. esc_html__("Icon", 'housico-shortcodes') .'</div><div class="input-group vu_ipc-container"><input data-placement="right" name="icon" class="icp vu_iconpicker" value="vu_fm-view_module" type="text" /><span class="input-group-addon vu_ipc-icon"></span></div></div><div class="vc_col-xs-9"><div class="wpb_element_label">'. esc_html__("Name", 'housico-shortcodes') .'</div><input name="name" type="text" value=""></div></div>',
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter categories.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Design Options", 'housico-shortcodes' ),
						"type" => "css_editor",
						"heading" => esc_html__("CSS box", 'housico-shortcodes' ),
						"param_name" => "css"
					)
				)
			)
		);
	}
?>