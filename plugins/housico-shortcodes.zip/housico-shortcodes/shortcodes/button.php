<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Button Shortcode
	 *
	 * @param string $atts['text']
	 * @param string $atts['link']
	 * @param string $atts['shape']
	 * @param string $atts['size']
	 * @param string $atts['stretch']
	 * @param string $atts['alignment']
	 * @param string $atts['border_width']
	 * @param string $atts['normal_color']
	 * @param string $atts['normal_text_color']
	 * @param string $atts['normal_bg_color']
	 * @param string $atts['normal_border_color']
	 * @param string $atts['hover_color']
	 * @param string $atts['hover_text_color']
	 * @param string $atts['hover_bg_color']
	 * @param string $atts['hover_border_color']
	 * @param string $atts['show_icon']
	 * @param string $atts['icon_library']
	 * @param string $atts['icon_flexipress']
	 * @param string $atts['icon_fontawesome']
	 * @param string $atts['icon_housico']
	 * @param string $atts['icon_position']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 */

	function housico_button_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"text" => "",
			"link" => "",
			"shape" => "",
			"size" => "",
			"stretch" => "",
			"alignment" => "",
			"border_width" => "",
			"normal_color" => "",
			"normal_text_color" => "",
			"normal_bg_color" => "",
			"normal_border_color" => "",
			"hover_color" => "",
			"hover_text_color" => "",
			"hover_bg_color" => "",
			"hover_border_color" => "",
			"show_icon" => "",
			"icon_library" => "",
			"icon_housico" => "",
			"icon_flexipress" => "",
			"icon_fontawesome" => "",
			"icon_position" => "",
			"class" => ""
		), $atts, 'vu_button' );

		$link = vc_build_link( $atts['link'] );
		
		$text = !empty($atts['text']) ? '<span>'. esc_html($atts['text']) .'</span>' : '';

		if ( $atts['show_icon'] == '1' ) {
			$icon = '<i class="'. esc_attr($atts['icon_'. esc_attr($atts['icon_library'])]) .'"></i>';

			if ( $atts['icon_position'] == 'before' ) {
				$text = $icon . $text;
			} else {
				$text = $text . $icon;
			}
		}

		if ( $atts['normal_color'] == 'custom' || $atts['hover_color'] == 'custom' ) {
			$custom_class = housico_custom_class();
			$atts['class'] .= ' '. $custom_class;
		}

		ob_start();
	?>
		<div class="vu_button-container vu_b-alignment-<?php echo esc_attr($atts['alignment']); ?> clearfix<?php housico_extra_class($atts['class']); ?>">
			<?php if ( $atts['normal_color'] == 'custom' || $atts['hover_color'] == 'custom' ) : ?>
				<style>
					<?php if ( !empty($atts['normal_text_color']) || !empty($atts['normal_border_color']) || !empty($atts['normal_bg_color']) ) : ?>
						.vu_button-container.<?php echo esc_attr($custom_class); ?> .vu_button{<?php echo (!empty($atts['normal_text_color'])) ? 'color:'. esc_attr($atts['normal_text_color']) .';' : ''; ?><?php echo (!empty($atts['normal_border_color'])) ? 'border-color:'. esc_attr($atts['normal_border_color']) .';' : ''; ?><?php echo (!empty($atts['normal_bg_color'])) ? 'background-color:'. esc_attr($atts['normal_bg_color']) .';' : ''; ?>}
					<?php endif; ?>
					<?php if ( !empty($atts['hover_text_color']) || !empty($atts['hover_border_color']) || !empty($atts['hover_bg_color']) ) : ?>
						.vu_button-container.<?php echo esc_attr($custom_class); ?> .vu_button:hover{<?php echo (!empty($atts['hover_text_color'])) ? 'color:'. esc_attr($atts['hover_text_color']) .';' : ''; ?><?php echo (!empty($atts['hover_border_color'])) ? 'border-color:'. esc_attr($atts['hover_border_color']) .';' : ''; ?><?php echo (!empty($atts['hover_bg_color'])) ? 'background-color:'. esc_attr($atts['hover_bg_color']) .';' : ''; ?>}
					<?php endif; ?>
				</style>
			<?php endif; ?>
			<a href="<?php echo esc_url($link['url']); ?>" title="<?php echo esc_url($link['title']); ?>" target="<?php echo ( strlen( $link['target'] ) > 0 ) ? esc_attr( $link['target'] ) : '_self'; ?>" class="vu_button vu_b-shape-<?php echo esc_attr( $atts['shape'] ); ?> vu_b-size-<?php echo esc_attr( $atts['size'] ); ?><?php echo ($atts['stretch'] == '1' ) ? ' vu_b-stretch' : ''; ?><?php echo ($atts['normal_color'] != 'custom' ) ? ' vu_b-normal-color-'. esc_attr($atts['normal_color']) : ''; ?><?php echo ($atts['hover_color'] != 'custom' ) ? ' vu_b-hover-color-'. esc_attr($atts['hover_color']) : ''; ?><?php echo ($atts['show_icon'] == '1' ) ? ' vu_b-with-icon' : ''; ?>"<?php echo (!empty($atts['border_width']) && $atts['border_width'] != 'none') ? ' style="border-width:'. esc_attr($atts['border_width']) .'"' : '' ?>>
				<?php echo wp_kses($text, array('span' => array(), 'i' => array('class' => array()))); ?>
			</a>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_button', 'housico_button_shortcode');

	/**
	 * Button VC Shortcode
	 */

	if ( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_button extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_button", $atts);

				return do_shortcode( housico_generate_shortcode('vu_button', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Button", 'housico-shortcodes'),
				"description" => esc_html__("Add custom button", 'housico-shortcodes'),
				"base"		=> "vu_button",
				"class"		=> "vc_vu_button",
				"icon"		=> "vu_element-icon vu_button-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"type" => "textfield",
						"heading" => esc_html__("Text", 'housico-shortcodes'),
						"param_name" => "text",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter button text.", 'housico-shortcodes')
					),
					array(
						"type" => "vc_link",
						"heading" => esc_html__("URL (Link)", 'housico-shortcodes'),
						"param_name" => "link",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Add link to button.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Shape", 'housico-shortcodes'),
						"param_name" => "shape",
						"value" => array(
							esc_html__("Square", 'housico-shortcodes') => "square",
							esc_html__("Round", 'housico-shortcodes') => "round",
							esc_html__("Pill", 'housico-shortcodes') => "pill"
						),
						"save_always" => true,
						"description" => esc_html__("Select button shape.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Size", 'housico-shortcodes'),
						"param_name" => "size",
						"value" => array(
							esc_html__("Mini", 'housico-shortcodes') => "mini",
							esc_html__("Small", 'housico-shortcodes') => "small",
							esc_html__("Normal", 'housico-shortcodes') => "normal",
							esc_html__("Large", 'housico-shortcodes') => "large"
						),
						"std" => 'normal',
						"save_always" => true,
						"description" => esc_html__("Select button size.", 'housico-shortcodes')
					),
					array(
						"type" => "checkbox",
						"heading" => esc_html__("Stretch", 'housico-shortcodes'),
						"param_name" => "stretch",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '0',
						"save_always" => true,
						"description" => esc_html__("Check to span the full width of its container.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Alignment", 'housico-shortcodes'),
						"param_name" => "alignment",
						"value" => array(
							esc_html__('Left', 'housico-shortcodes') => 'left',
							esc_html__('Center', 'housico-shortcodes') => 'center',
							esc_html__('Right', 'housico-shortcodes') => 'right'
						),
						"std" => "center",
						"save_always" => true,
						"description" => esc_html__("Select button alignment.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Border Width", 'housico-shortcodes'),
						"param_name" => "border_width",
						"value" => array(
							esc_html__('None', 'housico-shortcodes') => 'none',
							esc_html__('1px', 'housico-shortcodes') => '1px',
							esc_html__('2px', 'housico-shortcodes') => '2px',
							esc_html__('3px', 'housico-shortcodes') => '3px',
							esc_html__('4px', 'housico-shortcodes') => '4px',
							esc_html__('5px', 'housico-shortcodes') => '5px'
						),
						"std" => "none",
						"save_always" => true,
						"description" => esc_html__("Select button border width.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Normal Color", 'housico-shortcodes'),
						"param_name" => "normal_color",
						"value" => array(
							esc_html__("Primary", 'housico-shortcodes') => "primary",
							esc_html__("Secondary", 'housico-shortcodes') => "secondary",
							esc_html__("Black", 'housico-shortcodes') => "black",
							esc_html__("Gray", 'housico-shortcodes') => "gray",
							esc_html__("White", 'housico-shortcodes') => "white",
							esc_html__("Custom", 'housico-shortcodes') => "custom"
						),
						"std" => 'primary',
						"save_always" => true,
						"description" => esc_html__("Select button normal color.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Normal Text Color", 'housico-shortcodes'),
						"param_name" => "normal_text_color",
						"dependency" => array("element" => "normal_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select normal text color.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Normal Border Color", 'housico-shortcodes'),
						"param_name" => "normal_border_color",
						"dependency" => array("element" => "normal_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select normal border color.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Normal Background Color", 'housico-shortcodes'),
						"param_name" => "normal_bg_color",
						"dependency" => array("element" => "normal_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select normal background color.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Hover Color", 'housico-shortcodes'),
						"param_name" => "hover_color",
						"value" => array(
							esc_html__("Primary", 'housico-shortcodes') => "primary",
							esc_html__("Secondary", 'housico-shortcodes') => "secondary",
							esc_html__("Black", 'housico-shortcodes') => "black",
							esc_html__("Gray", 'housico-shortcodes') => "gray",
							esc_html__("White", 'housico-shortcodes') => "white",
							esc_html__("Custom", 'housico-shortcodes') => "custom"
						),
						"std" => 'secondary',
						"save_always" => true,
						"description" => esc_html__("Select button hover color.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Hover Text Color", 'housico-shortcodes'),
						"param_name" => "hover_text_color",
						"dependency" => array("element" => "hover_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select hover text color.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Hover Border Color", 'housico-shortcodes'),
						"param_name" => "hover_border_color",
						"dependency" => array("element" => "hover_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select hover border color.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Hover Background Color", 'housico-shortcodes'),
						"param_name" => "hover_bg_color",
						"dependency" => array("element" => "hover_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select hover background color.", 'housico-shortcodes')
					),
					array(
						"type" => "checkbox",
						"heading" => esc_html__("Show Icon", 'housico-shortcodes'),
						"param_name" => "show_icon",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '0',
						"save_always" => true,
						"description" => esc_html__("Check to show icon.", 'housico-shortcodes')
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Icon Library', 'housico-shortcodes'),
						'param_name' => 'icon_library',
						"dependency" => array("element" => "show_icon", "value" => "1"),
						'value' => array(
							esc_html__('FlexiPress', 'housico-shortcodes') => 'flexipress',
							esc_html__('FontAwesome', 'housico-shortcodes') => 'fontawesome',
							esc_html__('Housico', 'housico-shortcodes') => 'housico'
						),
						"save_always" => true,
						"description" => esc_html__("Select icon library.", 'housico-shortcodes')
					),
					array(
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "icon_flexipress",
						"dependency" => array("element" => "icon_library", "value" => "flexipress"),
						"settings" => array(
							"emptyIcon" => false,
							"type" => 'flexipress',
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "icon_fontawesome",
						"dependency" => array("element" => "icon_library", "value" => "fontawesome"),
						"settings" => array(
							"emptyIcon" => false,
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "icon_housico",
						"dependency" => array("element" => "icon_library", "value" => "housico"),
						"settings" => array(
							"emptyIcon" => false,
							"type" => 'housico',
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Icon Position", 'housico-shortcodes'),
						"param_name" => "icon_position",
						"dependency" => array("element" => "show_icon", "value" => "1"),
						"value" => array(
							esc_html__("Before Text", 'housico-shortcodes') => "before",
							esc_html__("After Text", 'housico-shortcodes') => "after"
						),
						"save_always" => true,
						"description" => esc_html__("Select icon position.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					)
				)
			)
		);
	}
?>