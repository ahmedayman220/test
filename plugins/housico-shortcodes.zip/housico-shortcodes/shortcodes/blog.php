<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Blog Shortcode
	 *
	 * @param string $atts['query']
	 * @param string $atts['type']
	 * @param string $atts['layout']
	 * @param string $atts['ratio']
	 * @param string $atts['show_date']
	 * @param string $atts['show_author']
	 * @param string $atts['show_categories']
	 * @param string $atts['show_comments']
	 * @param string $atts['show_content']
	 * @param string $atts['num_of_words']
	 * @param string $atts['show_pagination']
	 * @param string $atts['c_show_navigation']
	 * @param string $atts['c_navigation_position']
	 * @param string $atts['c_show_pagination']
	 * @param string $atts['c_autoplay']
	 * @param string $atts['c_stop_on_hover']
	 * @param string $atts['c_id']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 */

	function housico_blog_shortcode($atts, $content = null) {
		$atts = housico_shortcode_atts( array(
			"query" => "",
			"type" => "",
			"layout" => "",
			"ratio" => "",
			"show_date" => "",
			"show_author" => "",
			"show_categories" => "",
			"show_comments" => "",
			"show_content" => "",
			"num_of_words" => "",
			"show_read_more" => "",
			"read_more_text" => "",
			"show_pagination" => "",
			"c_show_navigation" => "",
			"c_navigation_position" => "",
			"c_show_pagination" => "",
			"c_autoplay" => "",
			"c_stop_on_hover" => "",
			"c_id" => "",
			"class" => "",
			"css" => ""
		), $atts, 'vu_blog' );

		if ( stripos($atts['query'], 'post_type:post') === false ){
			$atts['query'] .= '|post_type:post';
		}

		if ( $atts['type'] == 'grid' and $atts['show_pagination'] == '1' ) {
			$atts['query'] .= '|paged:'. get_query_var('paged');
		}

		$HousicoVcLoopQueryBuilder = new HousicoVcLoopQueryBuilder( esc_attr($atts['query']) );
		$blog_query = $HousicoVcLoopQueryBuilder->build();

		if ( function_exists('vc_shortcode_custom_css_class') ) {
			$atts['class'] .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		if ( $atts['type'] == 'carousel' && $atts['c_show_navigation'] == '1' && !empty($atts['c_navigation_position']) ) {
			$custom_class = housico_custom_class();
			$atts['class'] .= ' '. $custom_class;
		}

		$atts['class'] = trim($atts['class']);

		ob_start();
	?>
		<div class="vu_blog vu_b-type-<?php echo esc_attr($atts['type']); ?> vu_b-layout-<?php echo esc_attr($atts['layout']); ?> clearfix<?php housico_extra_class($atts['class']); ?>">
			<?php if ( $atts['type'] == 'carousel' ) : 
				$carousel_options = array(
					"singleItem" => false,
					"items" => absint($atts['layout']),
					"itemsDesktop" => array(1199, absint($atts['layout'])),
					"itemsDesktopSmall" => array(980, 2),
					"itemsTablet" => array(768, 2),
					"itemsMobile" => array(479, 1),
					"navigation" => ($atts['c_show_navigation'] == '1') ? true : false,
					"navigationText" => array('<i class="vu_fp-keyboard_arrow_left" aria-hidden="true"></i>', '<i class="vu_fp-keyboard_arrow_right" aria-hidden="true"></i>'),
					"pagination" => ($atts['c_show_pagination'] == '1') ? true : false,
					"autoHeight" => true,
					"rewindNav" => true,
					"scrollPerPage" => true,
					"autoPlay" => ($atts['c_autoplay'] == '' || $atts['c_autoplay'] == '0') ? false : absint($atts['c_autoplay']),
					"stopOnHover" => ($atts['c_stop_on_hover'] == '1') ? true : false
				);
			?>

				<?php if ( $atts['c_show_navigation'] == '1' && !empty($atts['c_navigation_position']) ) : ?>
					<style>.vu_blog.<?php echo esc_attr($custom_class); ?> .vu_carousel .owl-buttons .owl-prev, .vu_blog.<?php echo esc_attr($custom_class); ?> .vu_carousel .owl-buttons .owl-next { top: <?php echo esc_attr($atts['c_navigation_position']); ?>; margin-top: -25px; }</style>
				<?php endif; ?>

				<div<?php echo ( !empty($atts['c_id']) ) ? ' id="'. $atts['c_id'] .'"' : ''; ?> class="vu_b-carousel vu_carousel" data-options="<?php echo esc_attr(json_encode($carousel_options)); ?>">
			<?php else : ?>
				<div class="row">
			<?php endif; ?>

				<?php if ($blog_query->have_posts()) : while($blog_query->have_posts()): $blog_query->the_post(); ?>
					<?php if ( $atts['type'] != 'carousel' ) : ?>
						<div class="vu_b-item-wrap col-md-<?php echo (12 / absint($atts['layout'])); ?> col-sm-6 col-xs-12">
					<?php endif; ?>
						<article <?php post_class('vu_blog-item'); ?> data-id="<?php the_ID(); ?>" itemscope="itemscope" itemtype="https://schema.org/BlogPosting">
							<?php if ( has_post_thumbnail() ) : ?>
								<div class="vu_bi-image">
									<a href="<?php the_permalink(); ?>">
										<?php the_post_thumbnail('housico_ratio-'. esc_attr($atts['ratio']), array('itemprop' => 'image')); ?>
									</a>
								</div>
							<?php endif; ?>

							<div class="vu_bi-content-wrapper">
								<header class="vu_bi-header">
									<h3 class="vu_bi-title entry-title" itemprop="name">
										<a href="<?php the_permalink(); ?>" itemprop="url" rel="bookmark" title="<?php echo esc_attr( get_the_title() ); ?>"><?php the_title(); ?></a>
									</h3>

									<?php if ( $atts['show_author'] == '1' || $atts['show_date'] == '1' || $atts['show_categories'] == '1' || $atts['show_comments'] == '1' ) : ?>
										<div class="vu_bi-meta">
											<?php if ( $atts['show_author'] == '1' ) : ?>
												<span class="vu_bi-m-item vu_bi-author">
													<i class="fa fa-user-o"></i>
													<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" title="<?php esc_attr_e('Posts by', 'housico-shortcodes'); ?> <?php the_author(); ?>" rel="author"><span itemprop="author"><?php the_author(); ?></span></a>
												</span>
											<?php endif; ?>

											<?php if ( $atts['show_date'] == '1' ) : ?>
												<span class="vu_bi-m-item vu_bi-date">
													<i class="fa fa-calendar-o"></i>
													<time datetime="<?php the_time('c'); ?>" itemprop="datePublished"><?php echo get_the_date('M d Y'); ?></time>
												</span>
											<?php endif; ?>

											<?php if ( $atts['show_categories'] == '1' ) : ?>
												<span class="vu_bi-m-item vu_bi-categories">
													<i class="fa fa-folder-open-o"></i>
													<?php the_category(', '); ?>	
												</span>
											<?php endif; ?>

											<?php if ( $atts['show_comments'] == '1' ) : ?>
												<span class="vu_bi-m-item vu_bi-comments">
													<i class="fa fa-comment-o"></i>
													<a href="<?php comments_link(); ?>"><?php comments_number( esc_html__('No Comments', 'housico-shortcodes'), esc_html__('One Comment ', 'housico-shortcodes'), esc_html__('% Comments', 'housico-shortcodes') ); ?></a>
												</span>
											<?php endif; ?>
										</div>
									<?php endif; ?>
								</header>

								<?php if ( $atts['show_content'] == '1' ) : ?>
									<div class="vu_bi-content" itemprop="description">
										<?php housico_the_excerpt( absint($atts['num_of_words']) ); ?>
									</div>
								<?php endif; ?>

								<?php if ( $atts['show_read_more'] == '1' and !empty($atts['read_more_text']) ) : ?>
									<div class="clear"></div>
									<a href="<?php the_permalink(); ?>" class="vu_bi-read-more"><?php echo esc_html($atts['read_more_text']); ?></a>
								<?php endif; ?>

								<div class="clear"></div>
							</div>
						</article>
					<?php if ( $atts['type'] != 'carousel' ) : ?>
						</div>
					<?php endif; ?>
				<?php endwhile; endif; ?>
				<?php if ( $atts['type'] == 'grid' and $atts['show_pagination'] == '1' ) { housico_pagination($blog_query); } ?>
				<?php wp_reset_query(); ?>
			</div>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_blog', 'housico_blog_shortcode');

	/**
	 * Blog VC Shortcode
	 */

	if ( class_exists('WPBakeryShortCode') ){
		class WPBakeryShortCode_vu_blog extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_blog", $atts);

				return do_shortcode( housico_generate_shortcode('vu_blog', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Blog", 'housico-shortcodes'),
				"description" => esc_html__("Show blog posts", 'housico-shortcodes'),
				"base"		=> "vu_blog",
				"class"		=> "vc_vu_blog",
				"icon"		=> "vu_element-icon vu_blog-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "loop",
						"heading" => esc_html__("Blog Query", 'housico-shortcodes'),
						"param_name" => "query",
						'settings' => array(
							'size'          => array('hidden' => false, 'value' => '6'),
							'order_by'      => array('value' => 'date'),
							'categories'    => array('hidden' => false),
							'tags'          => array('hidden' => false),
							'tax_query'     => array('hidden' => true),
							'authors'     	=> array('hidden' => true),
							'post_type'     => array('hidden' => true, 'value' => 'post')
						),
						'value' => 'size:6|order_by:date|post_type:post',
						"save_always" => true,
						"description" => esc_html__("Create WordPress loop, to show posts from your site.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Type", 'housico-shortcodes'),
						"param_name" => "type",
						"admin_label" => true,
						"value" =>  array(
							esc_html__("Grid", 'housico-shortcodes') => "grid",
							esc_html__("Carousel", 'housico-shortcodes') => "carousel"
						),
						"save_always" => true,
						"description" => esc_html__("Select blog type.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Layout", 'housico-shortcodes'),
						"param_name" => "layout",
						"admin_label" => true,
						"value" => array(
							esc_html__("1 Column", 'housico-shortcodes') => '1',
							esc_html__("2 Columns", 'housico-shortcodes') => '2',
							esc_html__("3 Columns", 'housico-shortcodes') => '3',
							esc_html__("4 Columns", 'housico-shortcodes') => '4'
						),
						"std" => '3',
						"save_always" => true,
						"description" => esc_html__("Select blog layout.", 'housico-shortcodes'),
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Ratio", 'housico-shortcodes'),
						"param_name" => "ratio",
						"value" => housico_get_image_ratios(),
						"std" => '4:3',
						"save_always" => true,
						"description" => esc_html__("Select image ratio.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show date", 'housico-shortcodes'),
						"param_name" => "show_date",
						"value" =>  array( "Yes, please!" => "1"),
						"std" => "1",
						"save_always" => true,
						"description" => esc_html__("Check to show post date.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show author", 'housico-shortcodes'),
						"param_name" => "show_author",
						"value" =>  array( "Yes, please!" => "1"),
						"std" => "0",
						"save_always" => true,
						"description" => esc_html__("Check to show post author.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show categories", 'housico-shortcodes'),
						"param_name" => "show_categories",
						"value" =>  array( "Yes, please!" => "1"),
						"std" => "0",
						"save_always" => true,
						"description" => esc_html__("Check to show post categories.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show comments", 'housico-shortcodes'),
						"param_name" => "show_comments",
						"value" =>  array( "Yes, please!" => "1"),
						"std" => "0",
						"save_always" => true,
						"description" => esc_html__("Check to show post comments.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show content", 'housico-shortcodes'),
						"param_name" => "show_content",
						"value" =>  array( "Yes, please!" => "1"),
						"std" => "1",
						"save_always" => true,
						"description" => esc_html__("Check to show post content.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Number of words", 'housico-shortcodes'),
						"param_name" => "num_of_words",
						"dependency" => array("element" => "show_content", "value" => "1"),
						"value" => "20",
						"save_always" => true,
						"description" => esc_html__("Enter number of words to show as excerpt.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show read more", 'housico-shortcodes'),
						"param_name" => "show_read_more",
						"value" =>  array( "Yes, please!" => "1"),
						"std" => "1",
						"save_always" => true,
						"description" => esc_html__("Check to show read more text.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Read more text", 'housico-shortcodes'),
						"param_name" => "read_more_text",
						"dependency" => array("element" => "show_read_more", "value" => "1"),
						"value" => esc_html__("Read More", 'housico-shortcodes'),
						"save_always" => true,
						"description" => esc_html__("Enter read more text.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show pagination", 'housico-shortcodes'),
						"param_name" => "show_pagination",
						"dependency" => array("element" => "type", "value" => "grid"),
						"value" =>  array("Yes, please!" => "1"),
						"std" => "0",
						"save_always" => true,
						"description" => esc_html__("Check to show blog pagination.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Carousel Options', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show navigation", 'housico-shortcodes'),
						"param_name" => "c_show_navigation",
						"dependency" => array("element" => "type", "value" => "carousel"),
						"value" =>  array("Yes, please!" => "1"),
						"std" => "0",
						"save_always" => true,
						"description" => esc_html__("Check to show carousel navigation.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Carousel Options', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Navigation Position", 'housico-shortcodes'),
						"param_name" => "c_navigation_position",
						"dependency" => array("element" => "c_show_navigation", "value" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter distance of navigation from top. (Note: CSS measurement units allowed).", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Carousel Options', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show pagination", 'housico-shortcodes'),
						"param_name" => "c_show_pagination",
						"dependency" => array("element" => "type", "value" => "carousel"),
						"value" =>  array("Yes, please!" => "1"),
						"std" => "1",
						"save_always" => true,
						"description" => esc_html__("Check to show carousel pagination.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Carousel Options', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Auto play", 'housico-shortcodes'),
						"param_name" => "c_autoplay",
						"dependency" => array("element" => "type", "value" => "carousel"),
						"value" => "",
						"save_always" => true,
						"description" => wp_kses( __("Change to any integrer for example <b>5000</b> to play every <b>5</b> seconds. Leave blank to disable autoplay.", 'housico-shortcodes'), array('b' => array()) )
					),
					array(
						"group" => esc_html__('Carousel Options', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Stop autoplay on mouse hover", 'housico-shortcodes'),
						"param_name" => "c_stop_on_hover",
						"dependency" => array("element" => "c_autoplay", "not_empty" => true),
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"save_always" => true,
						"description" => esc_html__("Check to stop carousel on hover.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Carousel Options', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("ID", 'housico-shortcodes'),
						"param_name" => "c_id",
						"dependency" => array("element" => "type", "value" => "carousel"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Use this to option to add an ID for carousel.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Design Options", 'housico-shortcodes' ),
						"type" => "css_editor",
						"heading" => esc_html__("CSS box", 'housico-shortcodes' ),
						"param_name" => "css"
					)
				)
			)
		);
	}
?>