<?php 

	if ( !defined('ABSPATH') ) exit();

	/**
	 * Image Box Shortcode
	 *
	 * @param string $atts['image']
	 * @param string $atts['position']
	 * @param string $atts['ratio']
	 * @param string $atts['title']
	 * @param string $atts['link']
	 * @param string $atts['description']
	 * @param string $atts['read_more_text']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['css']
	 */

	function housico_image_box_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"image" => "",
			"position" => "",
			"ratio" => "",
			"title" => "",
			"link" => "",
			"description" => "",
			"read_more_text" => "",
			"class" => "",
			"css" => ""
		), $atts, 'vu_image_box' );

		if ( function_exists('vc_shortcode_custom_css_class') ) {
			$atts['class'] .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim($atts['class']);

		$url = vc_build_link( $atts['link'] );
		
		ob_start();
	?>
		<div class="vu_ib-image">
			<?php if ( strlen( $atts['link'] ) > 0 && strlen( $url['url'] ) > 0 ) {
				echo '<a href="'. esc_url( $url['url'] ) .'" title="'. esc_attr($url['title']) .'" target="'. (strlen($url['target']) > 0 ? esc_attr($url['target']) : '_self') . '">'. wp_get_attachment_image(absint($atts['image']), 'housico_ratio-'. esc_attr($atts['ratio'])) .'</a>';
			} else { 
				echo wp_get_attachment_image(absint($atts['image']), 'housico_ratio-'. esc_attr($atts['ratio']));
			} ?>
		</div>

	<?php 
		$image = ob_get_contents();
		ob_end_clean();
		
		ob_start();
	?>
		<div class="vu_image-box vu_ib-position-<?php echo esc_attr($atts['position']); ?> clearfix<?php housico_extra_class($atts['class']); ?>">
			<?php echo ( $atts['position'] == 'top' || $atts['position'] == 'left' ) ? $image : ''; ?>

			<div class="vu_ib-content">
				<h3 class="vu_ib-title">
					<?php if ( strlen( $atts['link'] ) > 0 && strlen( $url['url'] ) > 0 ) {
						echo '<a href="'. esc_url( $url['url'] ) .'" title="'. esc_attr($url['title']) .'" target="'. (strlen($url['target']) > 0 ? esc_attr($url['target']) : '_self') . '">'. esc_html($atts['title']) .'</a>';
					} else { 
						echo esc_html($atts['title']);
					} ?>
				</h3>

				<?php echo !empty($atts['description']) ? '<div class="vu_ib-description">'. wpautop($atts['description']) .'</div>' : ''; ?>

				<?php if ( $atts['read_more_text'] != '' && strlen( $atts['link'] ) > 0 && strlen( $url['url'] ) > 0 ) {
					echo '<div class="clear"></div><a href="'. esc_url( $url['url'] ) .'" title="'. esc_attr($url['title']) .'" target="'. (strlen($url['target']) > 0 ? esc_attr($url['target']) : '_self') . '" class="vu_ib-read-more vu_link-inverse">'. esc_html($atts['read_more_text']) .'</a>';
				} ?>
			</div>

			<?php echo ( $atts['position'] == 'right' || $atts['position'] == 'bottom' ) ? $image : ''; ?>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_image_box', 'housico_image_box_shortcode');

	/**
	 * Image Box VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ){
		class WPBakeryShortCode_vu_image_box extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_image_box", $atts);

				return do_shortcode( housico_generate_shortcode('vu_image_box', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Image Box", 'housico-shortcodes'),
				"description" => esc_html__("Text with image", 'housico-shortcodes'),
				"base"		=> "vu_image_box",
				"class"		=> "vc_vu_image_box",
				"icon"		=> "vu_element-icon vu_image-box-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"type" => "attach_image",
						"heading" => esc_html__("Image", 'housico-shortcodes'),
						"param_name" => "image",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select image from media library.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Ratio", 'housico-shortcodes'),
						"param_name" => "ratio",
						"value" => housico_get_image_ratios(),
						"std" => '2:1',
						"save_always" => true,
						"description" => esc_html__("Select image ratio.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Position", 'housico-shortcodes'),
						"param_name" => "position",
						"value" => array(
							esc_html__("Top", 'housico-shortcodes') => "top",
							esc_html__("Right", 'housico-shortcodes') => "right",
							esc_html__("Bottom", 'housico-shortcodes') => "bottom",
							esc_html__("Left", 'housico-shortcodes') => "left"
						),
						"std" => 'top',
						"save_always" => true,
						"description" => esc_html__("Select image position.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Title", 'housico-shortcodes'),
						"param_name" => "title",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter title.", 'housico-shortcodes')
					),
					array(
						"type" => "textarea",
						"heading" => esc_html__("Description", 'housico-shortcodes'),
						"param_name" => "description",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter description.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Read more text", 'housico-shortcodes'),
						"param_name" => "read_more_text",
						"admin_label" => true,
						"value" => esc_html__("Read More", 'housico-shortcodes'),
						"save_always" => true,
						"description" => esc_html__("Enter read more text.", 'housico-shortcodes')
					),
					array(
						"type" => "vc_link",
						"heading" => esc_html__("URL (Link)", 'housico-shortcodes'),
						"param_name" => "link",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Add link to image box.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Design Options", 'housico-shortcodes' ),
						"type" => "css_editor",
						"heading" => esc_html__("CSS box", 'housico-shortcodes' ),
						"param_name" => "css"
					)
				)
			)
		);
	}
?>