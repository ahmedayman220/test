<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Gallery Item Shortcode
	 *
	 * @param string $atts['image']
	 * @param string $atts['ratio']
	 * @param string $atts['title']
	 * @param string $atts['subtitle']
	 * @param string $atts['category']
	 * @param string $atts['link_type']
	 * @param string $atts['link']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 */

	function housico_gallery_item_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"image" => "",
			"ratio" => "",
			"size" => "",
			"title" => "",
			"subtitle" => "",
			"category" => "",
			"link_type" => "",
			"link" => "",
			"class" => "",
			"type" => "",
			"layout" => "",
			"style" => "1"
		), $atts, 'vu_gallery_item' );

		if( $atts['type'] == 'masonry' ) {
			$categories = @explode(',', $atts['category']);

			if( is_array($categories) ){
				foreach ($categories as $key => $value) {
					$categories[$key] = md5(sanitize_title($value));
				}
			} else {
				$categories = md5(sanitize_title($categories));
			}
		}

		ob_start();
	?>
		<?php if( $atts['type'] == 'standard' ) : ?>
			<div class="vu_g-item<?php echo ($atts['layout'] != 5) ? ' col-md-'. (12 / absint($atts['layout'])) : ''; ?> col-sm-6 col-xs-6 col-tn-12">
		<?php elseif( $atts['type'] == 'masonry' ) : ?>
			<div class="vu_g-item <?php echo esc_attr( @implode(' ', $categories) ); ?>" data-size="<?php echo esc_attr($atts['size']); ?>">
		<?php endif; ?>

			<div class="vu_gallery-item vu_gi-style-<?php echo esc_attr($atts['style']) ?><?php housico_extra_class($atts['class']); ?>">
				<?php if( !empty($atts['image']) ) : ?>
					<div class="vu_gi-image<?php echo ($atts['type'] == 'masonry') ? ' vu_lazy-load' : ''; ?>"<?php echo ($atts['type'] == 'masonry') ? ' data-img="'. housico_get_attachment_image_src($atts['image'], 'full') .'"' : ''; ?>>
						<?php 
							if( $atts['type'] == 'masonry' ) {
								echo wp_get_attachment_image( $atts['image'], 'housico_ratio-'. esc_attr(str_replace('x', ':', $atts['size'])) );
							} else {
								echo wp_get_attachment_image( $atts['image'], 'housico_ratio-'. esc_attr($atts['ratio']) );
							}
						?>
					</div>
				<?php endif; ?>
				<div class="vu_gi-details-container<?php echo (empty($atts['title']) && empty($atts['subtitle'])) ? ' vu_gi-empty' : ''; ?>">
					<div class="vu_gi-details">
						<?php if( $atts['link_type'] == 'lightbox' ) { ?>
							<a href="<?php echo housico_get_attachment_image_src( $atts['image'], 'full' ); ?>" title="<?php echo esc_attr($atts['title']); ?>" class="vu_gi-lightbox vu_gi-content-container">
						<?php } else if( $atts['link_type'] == 'url' ) { ?>
							<?php $link = vc_build_link( $atts['link'] ); ?>
							<a href="<?php echo esc_url($link['url']); ?>" title="<?php echo esc_attr($link['title']); ?>" class="vu_gi-content-container" target="<?php echo (strlen($link['target']) > 0 ? esc_attr($link['target']) : '_self' ); ?>">
						<?php } else { ?>
							<div class="vu_gi-content-container">
						<?php } ?>
								<section class="vu_gi-content">
									<?php if( !empty($atts['title']) ) : ?>
										<h5 class="vu_gi-title"><?php echo esc_html($atts['title']); ?></h5>
									<?php endif; ?>

									<?php if( !empty($atts['subtitle']) ) : ?>
										<span class="vu_gi-subtitle"><?php echo esc_html($atts['subtitle']); ?></span>
									<?php endif; ?>
								</section>
						<?php if( $atts['link_type'] == 'none' ) { ?>
							</div>
						<?php } else { ?>
							</a>
						<?php } ?>
					</div>
				</div>
			</div>

		<?php echo ($atts['type'] == 'standard' || $atts['type'] == 'masonry') ? '</div>' : ''; ?>
	<?php 
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_gallery_item', 'housico_gallery_item_shortcode');

	/**
	 * Gallery VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_gallery_item extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_gallery_item", $atts);

				return do_shortcode( housico_generate_shortcode('vu_gallery_item', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name" => esc_html__("Gallery Item", 'housico-shortcodes'),
				"description" => esc_html__("Add gallery item", 'housico-shortcodes'),
				"base" => "vu_gallery_item",
				"icon" => "vu_gallery-item-icon",
				"custom_markup" => '<input type="hidden" class="wpb_vc_param_value image attach_image" name="image" value="1"><h4 class="wpb_element_title">'. esc_html__('Gallery Item', 'housico-shortcodes') .' <img width="150" height="150" src="'. vc_asset_url('vc/blank.gif') .'" class="attachment-thumbnail vc_element-icon vu_element-icon" data-name="image" alt="" title="" style="display: none;"><span class="no_image_image vc_element-icon vu_element-icon vu_gallery-item-icon"></span></h4><span class="vc_admin_label admin_label_title hidden-label"><label>Title</label>: </span><span class="vc_admin_label admin_label_category hidden-label"><label>Category</label>: </span>',
				"controls" => "full",
				"as_child" => array( 'only' => 'vu_gallery' ),
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params" => array(
					array(
						"type" => "attach_image",
						"heading" => esc_html__("Image", 'housico-shortcodes'),
						"param_name" => "image",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select image from media library.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Ratio", 'housico-shortcodes'),
						"param_name" => "ratio",
						"admin_label" => true,
						"value" => housico_get_image_ratios(),
						"std" => '4:3',
						"save_always" => true,
						"description" => esc_html__("Select image ratio.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Size", 'housico-shortcodes'),
						"param_name" => "size",
						"admin_label" => true,
						"value" => array(
							"1x1" => "1x1",
							"1x2" => "1x2",
							"2x1" => "2x1",
							"2x2" => "2x2"
						),
						"std" => '1x1',
						"save_always" => true,
						"description" => esc_html__("Select image size.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Title", 'housico-shortcodes'),
						"param_name" => "title",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter gallery item title.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Subtitle", 'housico-shortcodes'),
						"param_name" => "subtitle",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter gallery item subtitle.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Category", 'housico-shortcodes'),
						"param_name" => "category",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter gallery item category.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Link Type", 'housico-shortcodes'),
						"param_name" => "link_type",
						"value" => array(
							esc_html__('No Link', 'housico-shortcodes') => "none",
							esc_html__('Lightbox', 'housico-shortcodes') => "lightbox",
							esc_html__('Link to URL', 'housico-shortcodes') => "url"
						),
						"std" => 'lightbox',
						"save_always" => true,
						"description" => esc_html__("Select gallery item link type.", 'housico-shortcodes'),
					),
					array(
						"type" => "vc_link",
						"heading" => esc_html__("URL (Link)", 'housico-shortcodes'),
						"param_name" => "link",
						"dependency" => array("element" => "link_type", "value" => "url"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Add link to gallery item.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					)
				)
			)
		);
	}
?>