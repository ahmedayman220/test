<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Timeline Shortcode
	 *
	 * @param string $atts['position']
	 * @param string $atts['date']
	 * @param string $atts['title']
	 * @param string $atts['desctription']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 */

	function housico_timeline_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"position" => "",
			"date" => "",
			"title" => "",
			"description" => "",
			"class" => ""
		), $atts, 'vu_timeline' );

		ob_start();
	?>
		<div class="vu_timeline vu_t-position-<?php echo esc_attr( $atts['position'] ); ?><?php housico_extra_class($atts['class']); ?>">
			<div class="vu_t-date"><?php echo esc_html( $atts['date'] ); ?></div>

			<div class="vu_t-container">
				<div class="vu_t-content">
					<?php if( !empty($atts['title']) ) : ?>
						<h4 class="vu_t-title"><?php echo esc_html( $atts['title'] ); ?></h4>
					<?php endif; ?>

					<?php if( !empty($atts['description']) ) : ?>
						<div class="vu_t-description">
							<?php echo wpautop( $atts['description'] ); ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_timeline', 'housico_timeline_shortcode');

	/**
	 * Timeline VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_timeline extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_timeline", $atts);

				return do_shortcode( housico_generate_shortcode('vu_timeline', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Timeline", 'housico-shortcodes'),
				"description" => esc_html__("Timeline/History", 'housico-shortcodes'),
				"base"		=> "vu_timeline",
				"class"		=> "vc_vu_timeline",
				"icon"		=> "vu_element-icon vu_timeline-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Position", 'housico-shortcodes'),
						"param_name" => "position",
						"value" => array(
							esc_html__("Left", 'housico-shortcodes') => "left",
							esc_html__("Right", 'housico-shortcodes') => "right",
						),
						"save_always" => true,
						"description" => esc_html__("Select position display style.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Date", 'housico-shortcodes'),
						"param_name" => "date",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter date.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Title", 'housico-shortcodes'),
						"param_name" => "title",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter title.", 'housico-shortcodes')
					),
					array(
						"type" => "textarea",
						"heading" => esc_html__("Content", 'housico-shortcodes'),
						"param_name" => "description",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter content.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					)
				)
			)
		);
	}
?>