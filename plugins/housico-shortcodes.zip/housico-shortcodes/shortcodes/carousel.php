<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Carousel Shortcode
	 *
	 * @param string $atts['items']
	 * @param string $atts['items_desktop_small']
	 * @param string $atts['items_tablet']
	 * @param string $atts['items_mobile']
	 * @param string $atts['slide_speed']
	 * @param string $atts['pagination_speed']
	 * @param string $atts['rewind_speed']
	 * @param string $atts['autoplay']
	 * @param string $atts['stop_on_hover']
	 * @param string $atts['navigation']
	 * @param string $atts['navigation_position']
	 * @param string $atts['rewind_nav']
	 * @param string $atts['pagination']
	 * @param string $atts['pagination_numbers']
	 * @param string $atts['pagination_custom_colors']
	 * @param string $atts['pagination_normal_text_color']
	 * @param string $atts['pagination_normal_bg_color']
	 * @param string $atts['pagination_active_text_color']
	 * @param string $atts['pagination_active_bg_color']
	 * @param string $atts['id']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 */

	function housico_carousel_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"items" => "",
			"items_desktop_small" => "",
			"items_tablet" => "",
			"items_mobile" => "",
			"slide_speed" => "",
			"pagination_speed" => "",
			"rewind_speed" => "",
			"scroll_per_page" => "",
			"autoplay" => "",
			"stop_on_hover" => "",
			"navigation" => "",
			"navigation_position" => "",
			"rewind_nav" => "",
			"pagination" => "",
			"pagination_numbers" => "",
			"pagination_custom_colors" => "",
			"pagination_normal_text_color" => "",
			"pagination_normal_bg_color" => "",
			"pagination_active_text_color" => "",
			"pagination_active_bg_color" => "",
			"id" => "",
			"class" => ""
		), $atts, 'vu_carousel' );

		$carousel_options = array();

		// Default
		$carousel_options['singleItem'] = false;
		$carousel_options['itemsScaleUp'] = false;
		$carousel_options['addClassActive'] = true;
		$carousel_options['navigationText'] = array('<i class="vu_fp-keyboard_arrow_left" aria-hidden="true"></i>', '<i class="vu_fp-keyboard_arrow_right" aria-hidden="true"></i>');
		//$carousel_options['baseClass'] = "owl-carousel";
		//$carousel_options['theme'] = "owl-theme";
		$carousel_options['autoHeight'] = true;

		// General
		$carousel_options['items'] = absint($atts['items']);
		$carousel_options['itemsDesktop'] = array(1199, $carousel_options['items']);
		$carousel_options['itemsDesktopSmall'] = array(980, absint($atts['items_desktop_small']));
		$carousel_options['itemsTablet'] = array(768, absint($atts['items_tablet']));
		$carousel_options['itemsMobile'] = array(479, absint($atts['items_mobile']));

		//Speeds
		$carousel_options['slideSpeed'] = absint($atts['slide_speed']);
		$carousel_options['paginationSpeed'] = absint($atts['pagination_speed']);
		$carousel_options['rewindSpeed'] = absint($atts['rewind_speed']);

		// Autoplay
		$carousel_options['autoPlay'] = ($atts['autoplay'] == '' || $atts['autoplay'] == '0') ? false : absint($atts['autoplay']);
		$carousel_options['stopOnHover'] = ($atts['stop_on_hover'] == '1') ? true : false;

		// Navigation
		$carousel_options['navigation'] = ($atts['navigation'] == '1') ? true : false;
		$carousel_options['rewindNav'] = ($atts['rewind_nav'] == '1') ? true : false;
		$carousel_options['scrollPerPage'] = ($atts['scroll_per_page'] == '1') ? true : false;

		//Pagination
		$carousel_options['pagination'] = ($atts['pagination'] == '1') ? true : false;
		$carousel_options['paginationNumbers'] = ($atts['pagination_numbers'] == '1') ? true : false;

		if ( ($atts['navigation'] == '1' && !empty($atts['navigation_position']) || ($atts['pagination_custom_colors']) == '1') ) {
			$custom_class = housico_custom_class();
			$atts['class'] .= ' '. $custom_class;
		}

		$atts['class'] = trim($atts['class']);

		ob_start();
	?>
		<div class="vu_carousel-container">
			<?php if ( ($atts['navigation'] == '1' && !empty($atts['§']) || ($atts['pagination_custom_colors']) == '1') ) : ?>
				<style>
					.vu_carousel.<?php echo esc_attr($custom_class); ?> .owl-buttons .owl-prev, .vu_carousel.<?php echo esc_attr($custom_class); ?> .owl-buttons .owl-next { <?php echo !empty($atts['navigation_position']) ? 'top: '. esc_attr($atts['navigation_position']) .'; ' : ''; ?>margin-top: -25px; }
					<?php if ( !empty($atts['pagination_normal_text_color']) ) : ?>
						.vu_carousel.<?php echo esc_attr($custom_class); ?> .owl-pagination .owl-page:not(.active) .owl-numbers { color: <?php echo esc_attr($atts['pagination_normal_text_color']); ?>; }
					<?php endif; ?>
					<?php if ( !empty($atts['pagination_normal_bg_color']) ) : ?>
						.vu_carousel.<?php echo esc_attr($custom_class); ?> .owl-pagination .owl-page:not(.active) span, .vu_carousel.<?php echo esc_attr($custom_class); ?> .owl-pagination .owl-page:not(.active) span:before { background-color: <?php echo esc_attr($atts['pagination_normal_bg_color']); ?>; border-color: <?php echo esc_attr($atts['pagination_normal_bg_color']); ?>; }
					<?php endif; ?>
					<?php if ( !empty($atts['pagination_active_text_color']) ) : ?>
						.vu_carousel.<?php echo esc_attr($custom_class); ?> .owl-pagination .owl-page.active .owl-numbers { color: <?php echo esc_attr($atts['pagination_active_text_color']); ?>; }
					<?php endif; ?>
					<?php if ( !empty($atts['pagination_active_bg_color']) ) : ?>
						.vu_carousel.<?php echo esc_attr($custom_class); ?> .owl-pagination .owl-page.active span, .vu_carousel.<?php echo esc_attr($custom_class); ?> .owl-pagination .owl-page.active span:before { background-color: <?php echo esc_attr($atts['pagination_active_bg_color']); ?>; border-color: <?php echo esc_attr($atts['pagination_active_bg_color']); ?>; }
					<?php endif; ?>
				</style>
			<?php endif; ?>

			<div<?php echo ( !empty($atts['id']) ) ? ' id="'. $atts['id'] .'"' : ''; ?> class="vu_carousel clearfix<?php housico_extra_class($atts['class']); ?>" data-options="<?php echo esc_attr(json_encode($carousel_options)); ?>">
				<?php echo do_shortcode($content); ?>
			</div>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_carousel', 'housico_carousel_shortcode');

	/**
	 * Carousel VC Shortcode
	 */

	if( class_exists('WPBakeryShortCodesContainer') ) {
		class WPBakeryShortCode_vu_carousel extends WPBakeryShortCodesContainer {
		}

		vc_map(
			array(
				"name"		=> esc_html__("Carousel", 'housico-shortcodes'),
				"description" => esc_html__("Carousel anything", 'housico-shortcodes'),
				"base"		=> "vu_carousel",
				"class"		=> "vc_vu_carousel",
				"icon"		=> "vu_element-icon vu_carousel-icon",
				"controls"	=> "full",
				"as_parent" => array( 'only' => 'vu_carousel_item' ),
				"js_view" => 'VcColumnView',
				"content_element" => true,
				"is_container" => true,
				"container_not_allowed" => false,
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				'default_content' => '[vu_carousel_item][/vu_carousel_item]',
				"params"	=> array(
					// General
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Items to display on screen", 'housico-shortcodes'),
						"param_name" => "items",
						"value" => "5",
						"save_always" => true,
						"description" => esc_html__("Maximum items to display at a time.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Items to display on small desktops", 'housico-shortcodes'),
						"param_name" => "items_desktop_small",
						"value" => "3",
						"save_always" => true,
						"description" => esc_html__("Maximum items to display at a time for smaller screened desktops.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Items to display on tablets", 'housico-shortcodes'),
						"param_name" => "items_tablet",
						"value" => "2",
						"save_always" => true,
						"description" => esc_html__("Maximum items to display at a time for tablet devices.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Items to display on mobile phones", 'housico-shortcodes'),
						"param_name" => "items_mobile",
						"value" => "1",
						"save_always" => true,
						"description" => esc_html__("Maximum items to display at a time for mobile devices.", 'housico-shortcodes')
					),
					//Basic Speeds
					array(
						"group" => esc_html__('Speeds', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Slide speed", 'housico-shortcodes'),
						"param_name" => "slide_speed",
						"value" => "200",
						"save_always" => true,
						"description" => esc_html__("Slide speed in milliseconds.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Speeds', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Pagination speed", 'housico-shortcodes'),
						"param_name" => "pagination_speed",
						"value" => "800",
						"save_always" => true,
						"description" => esc_html__("Pagination speed in milliseconds.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Speeds', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Rewind speed", 'housico-shortcodes'),
						"param_name" => "rewind_speed",
						"value" => "1000",
						"save_always" => true,
						"description" => esc_html__("Rewind speed in milliseconds.", 'housico-shortcodes')
					),
					//Autoplay
					array(
						"group" => esc_html__('Autoplay', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Auto play", 'housico-shortcodes'),
						"param_name" => "autoplay",
						"value" => "",
						"save_always" => true,
						"description" => wp_kses( __("Change to any integrer for example <b>5000</b> to play every <b>5</b> seconds. Leave blank to disable autoplay.", 'housico-shortcodes'), array('b' => array()) )
					),
					array(
						"group" => esc_html__('Autoplay', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Stop autoplay on mouse hover", 'housico-shortcodes'),
						"param_name" => "stop_on_hover",
						"dependency" => array("element" => "autoplay", "not_empty" => true),
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"save_always" => true
					),
					// Navigation
					array(
						"group" => esc_html__('Navigation', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Display 'next' and 'prev' buttons", 'housico-shortcodes'),
						"param_name" => "navigation",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '0',
						"save_always" => true
					),
					array(
						"group" => esc_html__('Navigation', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Navigation Position", 'housico-shortcodes'),
						"param_name" => "navigation_position",
						"dependency" => array("element" => "navigation", "value" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter distance of navigation from top. (Note: CSS measurement units allowed).", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Navigation', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Rewind Navigation", 'housico-shortcodes'),
						"param_name" => "rewind_nav",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '1',
						"save_always" => true,
						"description" => esc_html__("Slide to first item. Use 'Rewind speed' to change animation speed.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Navigation', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Scroll per page", 'housico-shortcodes'),
						"param_name" => "scroll_per_page",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '1',
						"save_always" => true,
						"description" => esc_html__("Scroll per page not per item. This affect next/prev buttons and mouse/touch dragging.", 'housico-shortcodes')
					),
					//Pagination
					array(
						"group" => esc_html__('Pagination', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show pagination", 'housico-shortcodes'),
						"param_name" => "pagination",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '1',
						"save_always" => true
					),
					array(
						"group" => esc_html__('Pagination', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show numbers inside pagination buttons", 'housico-shortcodes'),
						"param_name" => "pagination_numbers",
						"dependency" => array("element" => "pagination", "value" => "1"),
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '0',
						"save_always" => true
					),
					array(
						"group" => esc_html__('Pagination', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Custom Colors?", 'housico-shortcodes'),
						"param_name" => "pagination_custom_colors",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '0',
						"save_always" => true,
						"description" => esc_html__("Check to use custom colors.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Pagination', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Normal Text Color", 'housico-shortcodes'),
						"param_name" => "pagination_normal_text_color",
						"dependency" => array("element" => "pagination_custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select normal text color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Pagination', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Normal Background Color", 'housico-shortcodes'),
						"param_name" => "pagination_normal_bg_color",
						"dependency" => array("element" => "pagination_custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select normal background color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Pagination', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Active Text Color", 'housico-shortcodes'),
						"param_name" => "pagination_active_text_color",
						"dependency" => array("element" => "pagination_custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select active text color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Pagination', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Active Background Color", 'housico-shortcodes'),
						"param_name" => "pagination_active_bg_color",
						"dependency" => array("element" => "pagination_custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select active background color.", 'housico-shortcodes')
					),
					// Others
					array(
						"group" => esc_html__('Others', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Carousel ID", 'housico-shortcodes'),
						"param_name" => "id",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Use this to option to add an ID onto your carousel.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Others', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					)
				)
			)
		);
	}
?>