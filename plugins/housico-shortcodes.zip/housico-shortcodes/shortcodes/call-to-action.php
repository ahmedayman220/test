<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Call to Action Shortcode
	 *
	 * @param string $atts['bg_color']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['show_button']
	 * @param string $atts['btn_text']
	 * @param string $atts['btn_link']
	 * @param string $atts['btn_shape']
	 * @param string $atts['btn_border_width']
	 * @param string $atts['btn_normal_color']
	 * @param string $atts['btn_normal_text_color']
	 * @param string $atts['btn_normal_bg_color']
	 * @param string $atts['btn_normal_border_color']
	 * @param string $atts['btn_hover_color']
	 * @param string $atts['btn_hover_text_color']
	 * @param string $atts['btn_hover_bg_color']
	 * @param string $atts['btn_hover_border_color']
	 * @param string $atts['btn_show_icon']
	 * @param string $atts['btn_icon_library']
	 * @param string $atts['btn_icon_flexipress']
	 * @param string $atts['btn_icon_fontawesome']
	 * @param string $atts['btn_icon_housico']
	 * @param string $atts['btn_icon_position']
	 * @param string $atts['btn_class']
	 */

	function housico_call_to_action_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"bg_color" => "",
			"class" => "",
			"show_button" => "",
			"btn_text" => "",
			"btn_link" => "",
			"btn_shape" => "",
			"btn_border_width" => "",
			"btn_normal_color" => "",
			"btn_normal_text_color" => "",
			"btn_normal_bg_color" => "",
			"btn_normal_border_color" => "",
			"btn_hover_color" => "",
			"btn_hover_text_color" => "",
			"btn_hover_bg_color" => "",
			"btn_hover_border_color" => "",
			"btn_show_icon" => "",
			"btn_icon_library" => "",
			"btn_icon_flexipress" => "",
			"btn_icon_fontawesome" => "",
			"btn_icon_housico" => "",
			"btn_icon_position" => "",
			"btn_class" => ""
		), $atts, 'vu_call_to_action' );

		$btn_link = vc_build_link( $atts['btn_link'] );
		
		$btn_text = !empty($atts['btn_text']) ? '<span>'. esc_html($atts['btn_text']) .'</span>' : '';

		if ( $atts['btn_show_icon'] == '1' ) {
			$btn_icon = '<i class="'. esc_attr($atts['btn_icon_'. esc_attr($atts['btn_icon_library'])]) .'"></i>';

			if ( $atts['btn_icon_position'] == 'before' ) {
				$btn_text = $btn_icon . $btn_text;
			} else {
				$btn_text = $btn_text . $btn_icon;
			}
		}

		if ( $atts['btn_normal_color'] == 'custom' || $atts['btn_hover_color'] == 'custom' ) {
			$custom_class = housico_custom_class();
			$atts['btn_class'] .= ' '. $custom_class;
		}

		ob_start();
	?>
		<div class="vu_call-to-action<?php housico_extra_class($atts['class']); ?>"<?php echo ( !empty($atts['bg_color']) ) ? ' style="background-color:'. esc_attr($atts['bg_color']) .';"' : ''; ?>>
			<div class="container">
				<div class="row">
					<div class="vu_cta-wrapper">
						<div class="vu_cta-content col-md-<?php echo ($atts['show_button'] == '1') ? '9' : '12'; ?>">
							<?php echo housico_remove_wpautop($content, true); ?>
						</div>
						<?php if ( $atts['show_button'] == '1' ) : ?>
							<div class="vu_cta-button col-md-3">
								<?php if ( $atts['btn_normal_color'] == 'custom' || $atts['btn_hover_color'] == 'custom' ) : ?>
									<style>
										<?php if ( !empty($atts['btn_normal_text_color']) || !empty($atts['btn_normal_border_color']) || !empty($atts['btn_normal_bg_color']) ) : ?>
											.vu_call-to-action .vu_button.<?php echo esc_attr($custom_class); ?>{<?php echo (!empty($atts['btn_normal_text_color'])) ? 'color:'. esc_attr($atts['btn_normal_text_color']) .';' : ''; ?><?php echo (!empty($atts['btn_normal_border_color'])) ? 'border-color:'. esc_attr($atts['btn_normal_border_color']) .';' : ''; ?><?php echo (!empty($atts['btn_normal_bg_color'])) ? 'background-color:'. esc_attr($atts['btn_normal_bg_color']) .';' : ''; ?>}
										<?php endif; ?>
										<?php if ( !empty($atts['btn_hover_text_color']) || !empty($atts['btn_hover_border_color']) || !empty($atts['btn_hover_bg_color']) ) : ?>
											.vu_call-to-action .vu_button.<?php echo esc_attr($custom_class); ?>:hover{<?php echo (!empty($atts['btn_hover_text_color'])) ? 'color:'. esc_attr($atts['btn_hover_text_color']) .';' : ''; ?><?php echo (!empty($atts['btn_hover_border_color'])) ? 'border-color:'. esc_attr($atts['btn_hover_border_color']) .';' : ''; ?><?php echo (!empty($atts['btn_hover_bg_color'])) ? 'background-color:'. esc_attr($atts['btn_hover_bg_color']) .';' : ''; ?>}
										<?php endif; ?>
									</style>
								<?php endif; ?>
								<a href="<?php echo esc_url($btn_link['url']); ?>" title="<?php echo esc_url($btn_link['title']); ?>" target="<?php echo ( strlen( $btn_link['target'] ) > 0 ) ? esc_attr( $btn_link['target'] ) : '_self'; ?>" class="vu_button vu_b-size-normal vu_b-shape-<?php echo esc_attr( $atts['btn_shape'] ); ?><?php echo ($atts['btn_normal_color'] != 'custom' ) ? ' vu_b-normal-color-'. esc_attr($atts['btn_normal_color']) : ''; ?><?php echo ($atts['btn_hover_color'] != 'custom' ) ? ' vu_b-hover-color-'. esc_attr($atts['btn_hover_color']) : ''; ?><?php echo ($atts['btn_show_icon'] == '1' ) ? ' vu_b-with-icon' : ''; ?><?php housico_extra_class($atts['btn_class']); ?>"<?php echo (!empty($atts['btn_border_width']) && $atts['btn_border_width'] != 'none') ? ' style="border-width:'. esc_attr($atts['btn_border_width']) .'"' : '' ?>><?php echo wp_kses($btn_text, array('span' => array(), 'i' => array('class' => array()))); ?></a>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_call_to_action', 'housico_call_to_action_shortcode');

	/**
	 * Call to Action VC Shortcode
	 */

	if ( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_call_to_action extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_call_to_action", $atts);

				return do_shortcode( housico_generate_shortcode('vu_call_to_action', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Call to Action", 'housico-shortcodes'),
				"description" => esc_html__("Catch visitors attention with CTA block", 'housico-shortcodes'),
				"base"		=> "vu_call_to_action",
				"class"		=> "vc_vu_call_to_action",
				"icon"		=> "vu_element-icon vu_call-to-action-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"group" => esc_html__("General", 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Background Color", 'housico-shortcodes'),
						"param_name" => "bg_color",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select background color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("General", 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Content", 'housico-shortcodes'),
						"type" => "textarea_html",
						"heading" => esc_html__("Content", 'housico-shortcodes'),
						"param_name" => "content",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter CTA content.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show Button", 'housico-shortcodes'),
						"param_name" => "show_button",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '1',
						"save_always" => true,
						"description" => esc_html__("Uncheck to hide button.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Button Text", 'housico-shortcodes'),
						"param_name" => "btn_text",
						"dependency" => array("element" => "show_button", "value" => "1"),
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter button text.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "vc_link",
						"heading" => esc_html__("URL (Link)", 'housico-shortcodes'),
						"param_name" => "btn_link",
						"dependency" => array("element" => "show_button", "value" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Add link to button.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Shape", 'housico-shortcodes'),
						"param_name" => "btn_shape",
						"dependency" => array("element" => "show_button", "value" => "1"),
						"value" => array(
							esc_html__("Square", 'housico-shortcodes') => "square",
							esc_html__("Round", 'housico-shortcodes') => "round",
							esc_html__("Pill", 'housico-shortcodes') => "pill"
						),
						"save_always" => true,
						"description" => esc_html__("Select button shape.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Border Width", 'housico-shortcodes'),
						"param_name" => "btn_border_width",
						"dependency" => array("element" => "show_button", "value" => "1"),
						"value" => array(
							esc_html__('None', 'housico-shortcodes') => 'none',
							esc_html__('1px', 'housico-shortcodes') => '1px',
							esc_html__('2px', 'housico-shortcodes') => '2px',
							esc_html__('3px', 'housico-shortcodes') => '3px',
							esc_html__('4px', 'housico-shortcodes') => '4px',
							esc_html__('5px', 'housico-shortcodes') => '5px'
						),
						"std" => "none",
						"save_always" => true,
						"description" => esc_html__("Select button border width.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Normal Color", 'housico-shortcodes'),
						"param_name" => "btn_normal_color",
						"dependency" => array("element" => "show_button", "value" => "1"),
						"value" => array(
							esc_html__("Primary", 'housico-shortcodes') => "primary",
							esc_html__("Secondary", 'housico-shortcodes') => "secondary",
							esc_html__("Black", 'housico-shortcodes') => "black",
							esc_html__("Gray", 'housico-shortcodes') => "gray",
							esc_html__("White", 'housico-shortcodes') => "white",
							esc_html__("Custom", 'housico-shortcodes') => "custom"
						),
						"std" => 'primary',
						"save_always" => true,
						"description" => esc_html__("Select button normal color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Normal Text Color", 'housico-shortcodes'),
						"param_name" => "btn_normal_text_color",
						"dependency" => array("element" => "btn_normal_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select normal text color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Normal Border Color", 'housico-shortcodes'),
						"param_name" => "btn_normal_border_color",
						"dependency" => array("element" => "btn_normal_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select normal border color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Normal Background Color", 'housico-shortcodes'),
						"param_name" => "btn_normal_bg_color",
						"dependency" => array("element" => "btn_normal_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select normal background color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Hover Color", 'housico-shortcodes'),
						"param_name" => "btn_hover_color",
						"dependency" => array("element" => "show_button", "value" => "1"),
						"value" => array(
							esc_html__("Primary", 'housico-shortcodes') => "primary",
							esc_html__("Secondary", 'housico-shortcodes') => "secondary",
							esc_html__("Black", 'housico-shortcodes') => "black",
							esc_html__("Gray", 'housico-shortcodes') => "gray",
							esc_html__("White", 'housico-shortcodes') => "white",
							esc_html__("Custom", 'housico-shortcodes') => "custom"
						),
						"std" => 'secondary',
						"save_always" => true,
						"description" => esc_html__("Select button hover color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Hover Text Color", 'housico-shortcodes'),
						"param_name" => "btn_hover_text_color",
						"dependency" => array("element" => "btn_hover_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select hover text color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Hover Border Color", 'housico-shortcodes'),
						"param_name" => "btn_hover_border_color",
						"dependency" => array("element" => "btn_hover_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select hover border color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Hover Background Color", 'housico-shortcodes'),
						"param_name" => "btn_hover_bg_color",
						"dependency" => array("element" => "btn_hover_color", "value" => "custom"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select hover background color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show Icon", 'housico-shortcodes'),
						"param_name" => "btn_show_icon",
						"dependency" => array("element" => "show_button", "value" => "1"),
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '0',
						"save_always" => true,
						"description" => esc_html__("Check to show icon.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						'type' => 'dropdown',
						'heading' => esc_html__('Icon Library', 'housico-shortcodes'),
						'param_name' => 'btn_icon_library',
						"dependency" => array("element" => "btn_show_icon", "value" => "1"),
						'value' => array(
							esc_html__('FlexiPress', 'housico-shortcodes') => 'flexipress',
							esc_html__('FontAwesome', 'housico-shortcodes') => 'fontawesome',
							esc_html__('Housico', 'housico-shortcodes') => 'housico'
						),
						"save_always" => true,
						"description" => esc_html__("Select icon library.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "btn_icon_flexipress",
						"dependency" => array("element" => "btn_icon_library", "value" => "flexipress"),
						"settings" => array(
							"emptyIcon" => false,
							"type" => 'flexipress',
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "btn_icon_fontawesome",
						"dependency" => array("element" => "btn_icon_library", "value" => "fontawesome"),
						"settings" => array(
							"emptyIcon" => false,
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "btn_icon_housico",
						"dependency" => array("element" => "btn_icon_library", "value" => "housico"),
						"settings" => array(
							"emptyIcon" => false,
							"type" => 'housico',
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Icon Position", 'housico-shortcodes'),
						"param_name" => "btn_icon_position",
						"dependency" => array("element" => "btn_show_icon", "value" => "1"),
						"value" => array(
							esc_html__("Before Text", 'housico-shortcodes') => "before",
							esc_html__("After Text", 'housico-shortcodes') => "after"
						),
						"save_always" => true,
						"description" => esc_html__("Select icon position.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Button", 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "btn_class",
						"dependency" => array("element" => "show_button", "value" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					)
				)
			)
		);
	}
?>