<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Contact Form 7 Shortcode
	 *
	 * @param string $atts['title']
	 * @param string $atts['id']
	 * @param string $atts['style']
	 * @param string $atts['hide_valid_msgs']
	 * @param string $atts['html_id']
	 * @param string $atts['html_name']
	 * @param string $atts['html_class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['css']
	 */

	function housico_contact_form_7_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"title" => "",
			"id" => "",
			"style" => "",
			"hide_valid_msgs" => "",
			"html_id" => "",
			"html_name" => "",
			"html_class" => "",
			"css" => ""
		), $atts, 'vu_contact_form_7' );

		$atts['html_class'] = trim( $atts['html_class'] . ' vu_cf7-frm' );

		if( function_exists('vc_shortcode_custom_css_class') ) {
			$vc_shortcode_custom_css_class = ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		ob_start();
	?>
		<div class="vu_contact-form-7 vu_cf7-style-<?php echo esc_attr($atts['style']); ?><?php echo ($atts['hide_valid_msgs'] == '1') ? ' vu_cf7-hide-valid-msgs' : ''; ?> clearfix<?php echo (isset($vc_shortcode_custom_css_class) && !empty($vc_shortcode_custom_css_class)) ? esc_attr($vc_shortcode_custom_css_class) : ''; ?>">
			<?php if( !empty($atts['title']) ) : ?>
				<h4 class="vu_cf7-title"><?php echo esc_html( $atts['title'] ); ?></h4>
			<?php endif; ?>

			<?php echo do_shortcode( housico_generate_shortcode('contact-form-7', $atts, $content) ); ?>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_contact_form_7', 'housico_contact_form_7_shortcode');

	/**
	 * Contact Form 7 VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_contact_form_7 extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_contact_form_7", $atts);

				return do_shortcode( housico_generate_shortcode('vu_contact_form_7', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Contact Form 7", 'housico-shortcodes'),
				"description" => esc_html__("Contact Form 7", 'housico-shortcodes'),
				"base"		=> "vu_contact_form_7",
				"class"		=> "vc_vu_contact_form_7",
				"icon"		=> "vu_element-icon vu_contact-form-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"type" => "textfield",
						"heading" => esc_html__("Title", 'housico-shortcodes'),
						"param_name" => "title",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter form title. Leave blank if no title is needed.", 'housico-shortcodes')
					),
					array(
						"type" => "select2",
						"heading" => esc_html__("Form", 'housico-shortcodes'),
						"param_name" => "id",
						"admin_label" => true,
						"options" => array(
							"source" => admin_url("admin-ajax.php?action=housico_get_cf7"),
							"tags" => true
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select contact from.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Style", 'housico-shortcodes'),
						"param_name" => "style",
						"value" => array(
							esc_html__("Default", 'housico-shortcodes') => "default",
							esc_html__("Inverse", 'housico-shortcodes') => "inverse"
						),
						"save_always" => true,
						"description" => esc_html__("Select form style.", 'housico-shortcodes')
					),
					array(
						"type" => "checkbox",
						"heading" => esc_html__("Hide Validation Messages?", 'housico-shortcodes'),
						"param_name" => "hide_valid_msgs",
						"value" => array(esc_html__("Yes, please!", 'housico-shortcodes') => "1"),
						"std" => "0",
						"save_always" => true,
						"description" => esc_html__("Check to hide validation messages for all fields.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("ID", 'housico-shortcodes'),
						"param_name" => "html_id",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Use this to option to add an ID onto your contact form. Leave blank if no title is needed.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Name", 'housico-shortcodes'),
						"param_name" => "html_name",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Use this to option to add an Name onto your contact form. Leave blank if no title is needed.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Class", 'housico-shortcodes'),
						"param_name" => "html_class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Use this to option to add an extra Class onto your contact form. Leave blank if no title is needed.", 'housico-shortcodes')
					),
					array(
						'group' => esc_html__( 'Design Options', 'housico-shortcodes' ),
						'type' => 'css_editor',
						'heading' => esc_html__( 'CSS box', 'housico-shortcodes' ),
						'param_name' => 'css'
					)
				)
			)
		);
	}
?>