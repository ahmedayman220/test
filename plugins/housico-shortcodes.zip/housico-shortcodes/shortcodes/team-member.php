<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Team Member Shortcode
	 *
	 * @param string $atts['image']
	 * @param string $atts['ratio']
	 * @param string $atts['name']
	 * @param string $atts['link']
	 * @param string $atts['position']
	 * @param string $atts['description']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['style']
	 * @param string $atts['show_social_networks']
	 * @param string $atts['social_networks']
	 * @param string $atts['css']
	 */

	function housico_team_member_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"image" => "",
			"ratio" => "",
			"name" => "",
			"link" => "",
			"position" => "",
			"description" => "",
			"class" => "",
			"style" => "",
			"show_social_networks" => "",
			"social_networks" => "",
			"css" => ""
		), $atts, 'vu_team_member' );

		$link = vc_build_link( $atts['link'] );

		$social_networks = json_decode(base64_decode($atts['social_networks']), true);

		if( function_exists('vc_shortcode_custom_css_class') ) {
			$atts['class'] .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim($atts['class']);

		ob_start();
	?>
		<div class="vu_team-member vu_tm-style-<?php echo esc_attr($atts['style']); ?><?php housico_extra_class($atts['class']); ?>" itemscope="itemscope" itemtype="https://schema.org/Person">
			<?php if( $atts['style'] != "2" ) : ?>
				<div class="vu_tm-container">
					<?php if( !empty( $atts['image'] ) ) : ?>
						<div class="vu_tm-image">
							<?php echo wp_get_attachment_image( $atts['image'], 'housico_ratio-'. $atts['ratio'], false, array("itemprop" => "image") ); ?>

							<?php if ( $atts['show_social_networks'] == "1" and is_array($social_networks) and !empty($social_networks) ) : ?>
								<div class="vu_tm-social-networks">
									<ul class="list-unstyled">
										<?php 
											foreach ($social_networks as $social_network) {
												if( !empty( $social_network['icon'] ) ) {
													echo '<li><a href="'. esc_url( $social_network['url'] ) .'" target="_blank" itemprop="url"><i class="fa '. esc_attr($social_network['icon']) .'"></i></a></li>';
												}
											}
										?>
									</ul>
								</div>
							<?php endif; ?>
						</div>
					<?php endif; ?>

					<div class="vu_tm-info">
						<?php 
							if ( strlen( $atts['link'] ) > 0 && strlen( $link['url'] ) > 0 ) {
								echo '<h5 class="vu_tm-name"><a href="'. esc_url( $link['url'] ) .'" title="'. esc_attr( $link['title'] ) .'" target="'. ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '">'. esc_html( $atts['name'] ) .'</a></h5>';
							} else {
								echo '<h5 class="vu_tm-name">'. esc_html( $atts['name'] ) .'</h5>';
							}
						?>
						
						<?php if( !empty( $atts['position'] ) ) : ?>
							<span class="vu_tm-position" itemprop="jobTitle"><?php echo esc_html( $atts['position'] ); ?></span>
						<?php endif; ?>
					</div>
				</div>
				
				<?php if( !empty( $atts['description'] ) ) : ?>
					<div class="vu_tm-description" itemprop="description">
						<?php echo wpautop( $atts['description'] ); ?>
					</div>
				<?php endif; ?>
			<?php else : ?>
				<?php if( !empty( $atts['image'] ) ) : ?>
					<div class="vu_tm-image">
						<?php echo wp_get_attachment_image( $atts['image'], 'housico_ratio-'. $atts['ratio'], false, array("itemprop" => "image") ); ?>
					</div>
				<?php endif; ?>

				<div class="vu_tm-container">
					<div class="vu_tm-info">
						<?php 
							if ( strlen( $atts['link'] ) > 0 && strlen( $link['url'] ) > 0 ) {
								echo '<h5 class="vu_tm-name"><a href="'. esc_url( $link['url'] ) .'" title="'. esc_attr( $link['title'] ) .'" target="'. ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '">'. esc_html( $atts['name'] ) .'</a></h5>';
							} else {
								echo '<h5 class="vu_tm-name">'. esc_html( $atts['name'] ) .'</h5>';
							}
						?>
						
						<?php if( !empty( $atts['position'] ) ) : ?>
							<span class="vu_tm-position" itemprop="jobTitle"><?php echo esc_html( $atts['position'] ); ?></span>
						<?php endif; ?>
					</div>
					
					<?php if( !empty( $atts['description'] ) ) : ?>
						<div class="vu_tm-description" itemprop="description">
							<?php echo wpautop( $atts['description'] ); ?>
						</div>
					<?php endif; ?>

					<?php if ( $atts['show_social_networks'] == "1" and is_array($social_networks) and !empty($social_networks) ) : ?>
						<div class="vu_tm-social-networks">
							<ul class="list-unstyled">
								<?php 
									foreach ($social_networks as $social_network) {
										if( !empty( $social_network['icon'] ) ) {
											echo '<li><a href="'. esc_url( $social_network['url'] ) .'" target="_blank" itemprop="url"><i class="fa '. esc_attr($social_network['icon']) .'"></i></a></li>';
										}
									}
								?>
							</ul>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_team_member', 'housico_team_member_shortcode');

	/**
	 * Team Member VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_team_member extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_team_member", $atts);

				return do_shortcode( housico_generate_shortcode('vu_team_member', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Team Member", 'housico-shortcodes'),
				"description" => esc_html__("Add team member", 'housico-shortcodes'),
				"base"		=> "vu_team_member",
				"class"		=> "vc_vu_team_member",
				"icon"		=> "vu_element-icon vu_team-member-icon",
				"controls"	=> "full",
				"category"  => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "attach_image",
						"heading" => esc_html__("Image", 'housico-shortcodes'),
						"param_name" => "image",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select member image.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Ratio", 'housico-shortcodes'),
						"param_name" => "ratio",
						"value" => housico_get_image_ratios(),
						"std" => '3:4',
						"save_always" => true,
						"description" => esc_html__("Select image ratio.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Name", 'housico-shortcodes'),
						"param_name" => "name",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter member name.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "vc_link",
						"heading" => esc_html__("URL (Link)", 'housico-shortcodes'),
						"param_name" => "link",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Add link to name.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Position", 'housico-shortcodes'),
						"param_name" => "position",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter member position.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textarea",
						"heading" => esc_html__("Description", 'housico-shortcodes'),
						"param_name" => "description",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter member description.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Style', 'housico-shortcodes'),
						"type" => "image_select",
						"heading" => esc_html__("Style", 'housico-shortcodes'),
						"param_name" => "style",
						"value" =>  array(
							"1" => array(
									"title" => esc_html__("#1", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/team-member-styles/1.jpg"
								),
							"2" => array(
									"title" => esc_html__("#2", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/team-member-styles/2.jpg"
								),
							"3" => array(
									"title" => esc_html__("#3", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/team-member-styles/3.jpg"
								)
						),
						"width" => "calc(100% / 3 - 10px)",
						"height" => "auto",
						"std" => "1",
						"save_always" => true,
						"description" => esc_html__("Select team member style.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Social Networks', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show social networks?", 'housico-shortcodes'),
						"param_name" => "show_social_networks",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => "1"),
						"std" => '0',
						"save_always" => true,
						"description" => esc_html__("Check to show social networks.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Social Networks', 'housico-shortcodes'),
						"type" => "universal",
						"heading" => esc_html__("Social Networks", 'housico-shortcodes'),
						"param_name" => "social_networks",
						"dependency" => array("element" => "show_social_networks", "value" => "1"),
						"template" => '<div class="vc_row"><div class="vc_col-xs-3 vu_m-b-10"><div class="wpb_element_label">'. esc_html__("Icon", 'housico-shortcodes') .'</div><div class="input-group vu_ipc-container"><input data-placement="right" name="icon" class="icp vu_iconpicker" value="fa-facebook" type="text" /><span class="input-group-addon vu_ipc-icon"></span></div></div><div class="vc_col-xs-9"><div class="wpb_element_label">'. esc_html__("URL", 'housico-shortcodes') .'</div><input name="url" type="text" value=""></div></div>',
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Add social networks.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Design Options", 'housico-shortcodes' ),
						"type" => "css_editor",
						"heading" => esc_html__("CSS box", 'housico-shortcodes' ),
						"param_name" => "css"
					)
				)
			)
		);
	}
?>