<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Social Networks Shortcode
	 *
	 * @param string $atts['size']
	 * @param string $atts['alignment']
	 * @param string $atts['custom_colors']
	 * @param string $atts['icons_normal_color']
	 * @param string $atts['icons_normal_bg_color']
	 * @param string $atts['icons_hover_color']
	 * @param string $atts['icons_hover_bg_color']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['social_networks']
	 * @param string $atts['css']
	 */

	function housico_social_networks_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"size" => "",
			"alignment" => "",
			"custom_colors" => "",
			"icons_normal_color" => "",
			"icons_normal_bg_color" => "",
			"icons_hover_color" => "",
			"icons_hover_bg_color" => "",
			"class" => "",
			"social_networks" => "",
			"css" => ""
		), $atts, 'vu_social_networks' );

		$social_networks = json_decode(base64_decode($atts['social_networks']), true);

		if ( $atts['custom_colors'] == '1' ) {
			$custom_class = housico_custom_class();
			$atts['class'] .= ' '. $custom_class;
		}

		if( function_exists('vc_shortcode_custom_css_class') ) {
			$atts['class'] .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim($atts['class']);

		ob_start();
	?>
		<div class="vu_social-networks vu_sn-size-<?php echo esc_attr($atts['size']); ?> vu_sn-alignment-<?php echo esc_attr($atts['alignment']); ?><?php housico_extra_class($atts['class']); ?>">
				<?php if( $atts['custom_colors'] == '1' ) : ?>
					<style>
						<?php if( !empty($atts['icons_normal_color']) or !empty($atts['icons_normal_bg_color']) ) : ?>
							<?php if( !empty($atts['icons_normal_color']) ) : ?>
								.vu_social-networks.<?php echo esc_attr($custom_class); ?> .vu_social-icon a { color: <?php echo esc_attr($atts['icons_normal_color']); ?> !important; }
							<?php endif; ?>
							<?php if( !empty($atts['icons_normal_bg_color']) ) : ?>
								.vu_social-networks.<?php echo esc_attr($custom_class); ?> .vu_social-icon a { background-color: <?php echo esc_attr($atts['icons_normal_bg_color']); ?> !important; }
							<?php endif; ?>
						<?php endif; ?>
						<?php if( !empty($atts['icons_hover_color']) or !empty($atts['icons_hover_bg_color']) ) : ?>
							<?php if( !empty($atts['icons_hover_color']) ) : ?>
								.vu_social-networks.<?php echo esc_attr($custom_class); ?> .vu_social-icon a:hover { color: <?php echo esc_attr($atts['icons_hover_color']); ?> !important; }
							<?php endif; ?>
							<?php if( !empty($atts['icons_hover_bg_color']) ) : ?>
								.vu_social-networks.<?php echo esc_attr($custom_class); ?> .vu_social-icon a:hover { background-color: <?php echo esc_attr($atts['icons_hover_bg_color']); ?> !important; }
							<?php endif; ?>
						<?php endif; ?>
					</style>
				<?php endif; ?>
			<div class="vu_sn-container">
				<?php 
					if ( is_array($social_networks) and !empty($social_networks) ) {
						foreach ($social_networks as $social_network) {
							$_atts = shortcode_atts(array(
								'url' => '#',
								'target' => '_blank',
								'icon' => ''
							), $social_network, 'vu_social_network');

							$_atts['icon'] = !empty($_atts['icon']) ? 'fa '. $_atts['icon'] : '';

							
							echo do_shortcode( housico_generate_shortcode('vu_social_network', $_atts, null) );
						}
					}
				?>
			</div>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_social_networks', 'housico_social_networks_shortcode');

	/**
	 * Social Networks VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_social_networks extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_social_networks", $atts);

				return do_shortcode( housico_generate_shortcode('vu_social_networks', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Social Networks", 'housico-shortcodes'),
				"description" => esc_html__("Social media icons and links", 'housico-shortcodes'),
				"base"		=> "vu_social_networks",
				"class"		=> "vc_vu_social_networks",
				"icon"		=> "vu_element-icon vu_social-networks-icon",
				"controls"	=> "full",
				"category"  => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Size", 'housico-shortcodes'),
						"param_name" => "size",
						"admin_label" => true,
						"value" => array(
							esc_html__("Large", 'housico-shortcodes') => "large",
							esc_html__("Medium", 'housico-shortcodes') => "medium",
							esc_html__("Small", 'housico-shortcodes') => 'small'
						),
						"std" => "medium",
						"save_always" => true,
						"description" => esc_html__("Select icon size.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Alignment", 'housico-shortcodes'),
						"param_name" => "alignment",
						"admin_label" => true,
						"value" => array(
							esc_html__('Left', 'housico-shortcodes') => 'left',
							esc_html__('Center', 'housico-shortcodes') => 'center',
							esc_html__('Right', 'housico-shortcodes') => 'right'
						),
						"std" => "left",
						"save_always" => true,
						"description" => esc_html__("Select social networks alignment.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Custom Colors?", 'housico-shortcodes'),
						"param_name" => "custom_colors",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '0',
						"save_always" => true,
						"description" => esc_html__("Check to use custom colors.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icons Normal Color", 'housico-shortcodes'),
						"param_name" => "icons_normal_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select icons normal color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icons Normal BG Color", 'housico-shortcodes'),
						"param_name" => "icons_normal_bg_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select icons normal background color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icons Hover Color", 'housico-shortcodes'),
						"param_name" => "icons_hover_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select icons hover color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icons Hover BG Color", 'housico-shortcodes'),
						"param_name" => "icons_hover_bg_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select icons hover background color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Social Networks', 'housico-shortcodes'),
						"type" => "universal",
						"heading" => esc_html__("Social Networks", 'housico-shortcodes'),
						"param_name" => "social_networks",
						"template" => '<div class="vc_row"><div class="vc_col-xs-3 vu_m-b-10"><div class="wpb_element_label">'. esc_html__("Icon", 'housico-shortcodes') .'</div><div class="input-group vu_ipc-container"><input data-placement="right" name="icon" class="icp vu_iconpicker" value="fa fa-facebook" type="text" /><span class="input-group-addon vu_ipc-icon"></span></div></div><div class="vc_col-xs-9"><div class="wpb_element_label">'. esc_html__("URL", 'housico-shortcodes') .'</div><input name="url" type="text" value=""></div></div>',
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Add social networks.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Design Options", 'housico-shortcodes' ),
						"type" => "css_editor",
						"heading" => esc_html__("CSS box", 'housico-shortcodes' ),
						"param_name" => "css"
					)
				)
			)
		);
	}
?>