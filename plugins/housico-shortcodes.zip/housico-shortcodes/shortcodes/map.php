<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Map Shortcode
	 *
	 * @author Vedat Ujkani
	 */

	function housico_map_shortcode($atts, $content = null) {
		$atts = housico_shortcode_atts( array(
			"inherit_options" => "",
			"center_lat" => "",
			"center_lng" => "",
			"zoom_level" => "",
			"map_height" => "",
			"map_type" => "",
			"map_style" => "",
			"tilt_45" => "",
			"draggable" => "",
			"zoom_control" => "",
			"disable_double_click_zoom" => "",
			"scrollwheel" => "",
			"pan_control" => "",
			"fullscreen_control" => "",
			"map_type_control" => "",
			"scale_control" => "",
			"street_view_control" => "",
			"use_custom_marker" => "",
			"custom_marker" => "",
			"enable_map_animation" => "",
			"locations" => "",
			"class" => ""
		), $atts, 'vu_map' );

		//map options
		if( $atts['inherit_options'] != "1") {
			$map_options = array(
				"zoom_level" => esc_attr($atts['zoom_level']),
				"center_lat" => esc_attr($atts['center_lat']),
				"center_lng" => esc_attr($atts['center_lng']),
				"map_type" => esc_attr($atts['map_type']),
				"tilt_45" => esc_attr($atts['tilt_45']),
				"others_options" => array(
					"draggable" => esc_attr($atts['draggable']),
					"zoomControl" => esc_attr($atts['zoom_control']),
					"disableDoubleClickZoom" => esc_attr($atts['disable_double_click_zoom']),
					"scrollwheel" => esc_attr($atts['scrollwheel']),
					"panControl" => esc_attr($atts['pan_control']),
					"fullscreenControl" => esc_attr($atts['fullscreen_control']),
					"mapTypeControl" => esc_attr($atts['map_type_control']),
					"scaleControl" => esc_attr($atts['scale_control']),
					"streetViewControl" => esc_attr($atts['street_view_control'])
				),
				"use_custom_marker" => esc_attr($atts['use_custom_marker']),
				"custom_marker" => esc_url(housico_get_attachment_image_src($atts['custom_marker'], 'full')),
				"enable_animation" => esc_attr($atts['enable_map_animation']),
				"locations" => json_decode(base64_decode($atts['locations']), true)
			);
		} else {
			$map_options = housico_get_map_options();
		}

		//styles
		if( $map_options['map_type'] == "roadmap" ){
			$map_style_array = @explode('#', housico_get_option('map-style'));
			$map_style_temp = isset($map_style_array[1]) ? $map_style_array[1] : null;

			$map_style = ($atts['inherit_options'] != "1") ? $atts['map_style'] : $map_style_temp;
			
			$map_options['styles'] = housico_get_map_style($map_style);
		}

		$map_height = ($atts['inherit_options'] != "1") ? absint($atts['map_height']) : absint(housico_get_option('map-height'));

		wp_enqueue_script('jquery-gmap3');

		return '<div class="vu_map vu_m-fullwith'. housico_extra_class($atts['class'], false) .'" data-options="'. esc_attr(json_encode($map_options)) .'"'. ($map_height > 0 ? ' style="height:'. $map_height .'px;"' : '') .'></div>';
	}

	add_shortcode('vu_map', 'housico_map_shortcode');
	
	/**
	 * Map VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ){
		class WPBakeryShortCode_vu_map extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_map", $atts);

				return do_shortcode( housico_generate_shortcode('vu_map', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Map", 'housico-shortcodes'),
				"description" => esc_html__('Single or multiple locations', 'housico-shortcodes'),
				"base"		=> "vu_map",
				"class"		=> "vc_vu_map",
				"icon"		=> "vu_element-icon vu_map-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Inherit from Theme Options", 'housico-shortcodes'),
						"param_name" => "inherit_options",
						"admin_label" => true,
						"value" => array(esc_html__("Yes, please!", 'housico-shortcodes') => "1"),
						"std" => "1",
						"save_always" => true,
						"description" => esc_html__("Map options will be inherited form general theme options. Uncheck to ignore and set up new options.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Center Latitude", 'housico-shortcodes'),
						"param_name" => "center_lat",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter latitude for the map center point.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Center Longitude", 'housico-shortcodes'),
						"param_name" => "center_lng",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter longitude for the map center point.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Default Zoom Level", 'housico-shortcodes'),
						"param_name" => "zoom_level",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Value should be between 1-18, 1 being the entire earth and 18 being right at street level.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Height", 'housico-shortcodes'),
						"param_name" => "map_height",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter map height.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Type", 'housico-shortcodes'),
						"param_name" => "map_type",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(
							esc_html__("Roadmap", 'housico-shortcodes') => "roadmap",
							esc_html__("Satellite", 'housico-shortcodes') => "satellite",
							esc_html__("Hybrid", 'housico-shortcodes') => "hybrid",
							esc_html__("Terrain", 'housico-shortcodes') => "terrain"
						),
						"save_always" => true,
						"description" => esc_html__("Select map type.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Tilt 45°", 'housico-shortcodes'),
						"param_name" => "tilt_45",
						"dependency" => array("element" => "map_type", "value" => "satellite"),
						"value" => array(esc_html__("Yes, please!", 'housico-shortcodes') => "1"),
						"save_always" => true
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"edit_field_class" => "vc_col-sm-12 vc_column",
						"heading" => esc_html__("Others Options", 'housico-shortcodes'),
						"param_name" => "draggable",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(esc_html__("Draggable", 'housico-shortcodes') => "1"),
						"std" => "0",
						"save_always" => true
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"edit_field_class" => "vc_col-sm-12 vc_column vu_p-t-0",
						"param_name" => "zoom_control",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(esc_html__("Zoom Control", 'housico-shortcodes') => "1"),
						"save_always" => true
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"edit_field_class" => "vc_col-sm-12 vc_column vu_p-t-0",
						"param_name" => "disable_double_click_zoom",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(esc_html__("Disable Double Click Zoom", 'housico-shortcodes') => "1"),
						"save_always" => true
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"edit_field_class" => "vc_col-sm-12 vc_column vu_p-t-0",
						"param_name" => "scrollwheel",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(esc_html__("Scroll Wheel", 'housico-shortcodes') => "1"),
						"std" => "1",
						"save_always" => true
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"edit_field_class" => "vc_col-sm-12 vc_column vu_p-t-0",
						"param_name" => "pan_control",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(esc_html__("Pan Control", 'housico-shortcodes') => "1"),
						"save_always" => true
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"edit_field_class" => "vc_col-sm-12 vc_column vu_p-t-0",
						"param_name" => "fullscreen_control",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(esc_html__("Fullscreen Control", 'housico-shortcodes') => "1"),
						"std" => "1",
						"save_always" => true
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"edit_field_class" => "vc_col-sm-12 vc_column vu_p-t-0",
						"param_name" => "map_type_control",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(esc_html__("Type Control", 'housico-shortcodes') => "1"),
						"save_always" => true
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"edit_field_class" => "vc_col-sm-12 vc_column vu_p-t-0",
						"param_name" => "scale_control",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(esc_html__("Scale Control", 'housico-shortcodes') => "1"),
						"save_always" => true
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "checkbox",
						"edit_field_class" => "vc_col-sm-12 vc_column vu_p-t-0",
						"param_name" => "street_view_control",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(esc_html__("Street View Control", 'housico-shortcodes') => "1"),
						"save_always" => true,
						"description" => esc_html__("Select other options you want to apply on map.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Style', 'housico-shortcodes'),
						"type" => "image_select",
						"heading" => esc_html__("Style", 'housico-shortcodes'),
						"param_name" => "map_style",
						"dependency" => array("element" => "map_type", "value" => "roadmap"),
						"value" => array(
							"0" => array(
									"title" => esc_html__("Default", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/0.png"
								),
							"1" => array(
									"title" => esc_html__("Theme Style", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/1.png"
								),
							"2" => array(
									"title" => esc_html__("Subtle Grayscale", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/2.png"
								),
							"3" => array(
									"title" => esc_html__("Blue Water", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/3.png"
								),
							"4" => array(
									"title" => esc_html__("Shades of Grey", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/4.png"
								),
							"5" => array(
									"title" => esc_html__("Pale Dawn", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/5.png"
								),
							"6" => array(
									"title" => esc_html__("Apple Maps-esque", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/6.png"
								),
							"7" => array(
									"title" => esc_html__("Light Monochrome", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/7.png"
								),
							"8" => array(
									"title" => esc_html__("Greyscale", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/8.png"
								),
							"9" => array(
									"title" => esc_html__("Neutral Blue", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/9.png"
								),
							"10" => array(
									"title" => esc_html__("Become a Dinosaur", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/10.png"
								),
							"11" => array(
									"title" => esc_html__("Blue Gray", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/11.png"
								),
							"12" => array(
									"title" => esc_html__("Icy Blue", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/12.png"
								),
							"13" => array(
									"title" => esc_html__("Clean Cut", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/13.png"
								),
							"14" => array(
									"title" => esc_html__("Muted Blue", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/14.png"
								),
							"15" => array(
									"title" => esc_html__("Old Timey", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/15.png"
								),
							"16" => array(
									"title" => esc_html__("Red Hues", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/16.png"
								),
							"17" => array(
									"title" => esc_html__("Nature", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/17.png"
								),
							"18" => array(
									"title" => esc_html__("Turquoise Water", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/18.png"
								),
							"19" => array(
									"title" => esc_html__("Just Places", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/19.png"
								),
							"20" => array(
									"title" => esc_html__("Ultra Light", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/20.png"
								),
							"21" => array(
									"title" => esc_html__("Subtle Green", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/21.png"
								),
							"22" => array(
									"title" => esc_html__("Simple & Light", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/22.png"
								),
							"23" => array(
									"title" => esc_html__("Dankontorstole", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/map-styles/23.png"
								)
						),
						"width" => "calc(33.33333% - 10px)",
						"height" => "auto",
						"std" => "1",
						"save_always" => true,
						"description" => esc_html__("Select map style.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Marker', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Use Custom Marker", 'housico-shortcodes'),
						"param_name" => "use_custom_marker",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(esc_html__("Yes, please!", 'housico-shortcodes') => "1"),
						"save_always" => true,
						"description" => esc_html__("Check to use a custom image as map marker.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Marker', 'housico-shortcodes'),
						"type" => "attach_image",
						"heading" => esc_html__("Custom Marker", 'housico-shortcodes'),
						"param_name" => "custom_marker",
						"dependency" => array("element" => "use_custom_marker", "value" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Upload custom image/icon marker.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Marker', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Enable Marker Animation", 'housico-shortcodes'),
						"param_name" => "enable_map_animation",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"value" => array(esc_html__("Yes, please!", 'housico-shortcodes') => "1"),
						"save_always" => true,
						"description" => esc_html__("If checked, marker(s) will do a quick bounce as they load in.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Locations', 'housico-shortcodes'),
						"type" => "universal",
						"heading" => esc_html__("Locations", 'housico-shortcodes'),
						"param_name" => "locations",
						"dependency" => array("element" => "inherit_options", "value_not_equal_to" => "1"),
						"template" => '<div class="vc_row"><div class="vc_col-xs-6 vu_m-b-10"><div class="wpb_element_label">'. esc_html__('Latitude', 'housico-shortcodes') .'</div><input name="lat" type="text" value=""></div><div class="vc_col-xs-6 vu_m-b-10"><div class="wpb_element_label">'. esc_html__('Longitude', 'housico-shortcodes') .'</div><input name="lng" type="text" value=""></div><div class="vc_col-xs-12 vu_m-b-10"><div class="wpb_element_label">'. esc_html__('Info Window', 'housico-shortcodes') .'</div><textarea name="info"></textarea></div><div class="vc_col-xs-12 vu_m-b-10"><div class="wpb_element_label">'. esc_html__('Marker', 'housico-shortcodes') .'</div><div class="vu_param_media vc_clearfix"><div class="vu_param_m-img-holder"><span class="vu_param_m-img"></span></div><div class="vu_param_m-content"><input type="hidden" name="marker_id" class="vu_param_m-img-id"><input type="text" name="marker_url" class="vu_param_m-img-url" readonly="readonly" placeholder="'. esc_attr__('No marker selected. Custom marker will be inhereted.', 'housico-shortcodes') .'"><button type="button" class="vu_param_m-btn vu_as-param" data-control="upload" data-title="'. esc_attr__('Add Image', 'housico-shortcodes') .'" data-button="'. esc_attr__('Add Image', 'housico-shortcodes') .'">'. esc_html__('Upload', 'housico-shortcodes') .'</button><button type="button" class="vu_param_m-btn vu_as-param" data-control="remove">'. esc_html__('Remove', 'housico-shortcodes') .'</button></div></div></div></div>',
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter map locations details.", 'housico-shortcodes')
					)
				)
			)
		);
	}
?>