<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Countdown Shortcode
	 *
	 * @param string $atts['date']
	 * @param string $atts['format']
	 * @param string $atts['size']
	 * @param string $atts['alignment']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['css']
	 */

	function housico_countdown_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"date" => "",
			"format" => "dHMS",
			"size" => "",
			"alignment" => "",
			"class" => "",
			"css" => ""
		), $atts, 'vu_countdown' );

		if( function_exists('vc_shortcode_custom_css_class') ) {
			$atts['class'] .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		ob_start();
	?>
		<div class="vu_countdown vu_c-size-<?php echo esc_attr($atts['size']); ?> vu_c-alignment-<?php echo esc_attr($atts['alignment']); ?> clearfix<?php housico_extra_class($atts['class']); ?>" data-date="<?php echo esc_attr($atts['date']); ?>" data-format="<?php echo esc_attr($atts['format']); ?>"></div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_countdown', 'housico_countdown_shortcode');

	/**
	 * Countdown VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_countdown extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_countdown", $atts);

				return do_shortcode( housico_generate_shortcode('vu_countdown', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Countdown", 'housico-shortcodes'),
				"description" => esc_html__('Countdown element', 'housico-shortcodes'),
				"base"		=> "vu_countdown",
				"class"		=> "vc_vu_countdown",
				"icon"		=> "vu_element-icon vu_countdown-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"type" => "textfield",
						"heading" => esc_html__("Date", 'housico-shortcodes'),
						"param_name" => "date",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => wp_kses( __("Enter date in '<b>yyyy-mm-dd</b>' format.", 'housico-shortcodes'), array('b' => array()) )
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Format", 'housico-shortcodes'),
						"param_name" => "format",
						"admin_label" => true,
						"value" => "dHMS",
						"save_always" => true,
						"description" => wp_kses( __("Enter date format. Default is <b>dHMS</b>.", 'housico-shortcodes'), array('b' => array()) )
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Size", 'housico-shortcodes'),
						"param_name" => "size",
						"value" => array(
							esc_html__('Large', 'housico-shortcodes') => "large",
							esc_html__('Medium', 'housico-shortcodes') => "medium",
							esc_html__('Small', 'housico-shortcodes') => "small"
						),
						"std" => 'large',
						"save_always" => true,
						"description" => esc_html__("Select countdown size.", 'housico-shortcodes'),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Alignment", 'housico-shortcodes'),
						"param_name" => "alignment",
						"value" => array(
							esc_html__('Left', 'housico-shortcodes') => 'left',
							esc_html__('Center', 'housico-shortcodes') => 'center',
							esc_html__('Right', 'housico-shortcodes') => 'right'
						),
						"std" => "center",
						"save_always" => true,
						"description" => esc_html__("Select countdown alignment.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Design Options", 'housico-shortcodes' ),
						"type" => "css_editor",
						"heading" => esc_html__("CSS box", 'housico-shortcodes' ),
						"param_name" => "css"
					)
				)
			)
		);
	}
?>