<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * MailChimp Form Shortcode
	 *
	 * @param string $atts['title']
	 * @param string $atts['id']
	 * @param string $atts['style']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['css']
	 */

	function housico_mailchimp_form_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"title" => "",
			"description" => "",
			"id" => "",
			"style" => "",
			"class" => "",
			"css" => ""
		), $atts, 'vu_mailchimp_form' );

		if( function_exists('vc_shortcode_custom_css_class') ) {
			$atts['class'] .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim($atts['class']);

		ob_start();
	?>
		<div class="vu_mailchimp-form vu_mcf-style-<?php echo esc_attr($atts['style']); ?> clearfix<?php housico_extra_class($atts['class']); ?>">
			<?php if( !empty($atts['title']) ) : ?>
				<h4 class="vu_mcf-title"><?php echo esc_html( $atts['title'] ); ?></h4>
			<?php endif; ?>

			<?php if( !empty($atts['description']) ) : ?>
				<div class="vu_mcf-description">
					<?php echo wpautop($atts['description']); ?>
				</div>
			<?php endif; ?>

			<?php echo do_shortcode( housico_generate_shortcode('mc4wp_form', array('id' => $atts['id']), $content) ); ?>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_mailchimp_form', 'housico_mailchimp_form_shortcode');

	/**
	 * Contact Form 7 VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_mailchimp_form extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_mailchimp_form", $atts);

				return do_shortcode( housico_generate_shortcode('vu_mailchimp_form', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("MailChimp Form", 'housico-shortcodes'),
				"description" => esc_html__("Newsletter/Subscribe", 'housico-shortcodes'),
				"base"		=> "vu_mailchimp_form",
				"class"		=> "vc_vu_mailchimp_form",
				"icon"		=> "vu_element-icon vu_mailchimp-form-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"type" => "textfield",
						"heading" => esc_html__("Title", 'housico-shortcodes'),
						"param_name" => "title",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter form title. Leave blank if no title is needed.", 'housico-shortcodes')
					),
					array(
						"type" => "textarea",
						"heading" => esc_html__("Description", 'housico-shortcodes'),
						"param_name" => "description",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter form description.", 'housico-shortcodes')
					),
					array(
						"type" => "select2",
						"heading" => esc_html__("Form", 'housico-shortcodes'),
						"param_name" => "id",
						"admin_label" => true,
						"options" => array(
							"source" => admin_url("admin-ajax.php?action=housico_get_mc4wp"),
							"tags" => true
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select MailChimp form.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Style", 'housico-shortcodes'),
						"param_name" => "style",
						"value" => array(
							esc_html__("Default", 'housico-shortcodes') => "default",
							esc_html__("Inverse", 'housico-shortcodes') => "inverse"
						),
						"save_always" => true,
						"description" => esc_html__("Select form style.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						'group' => esc_html__( 'Design Options', 'housico-shortcodes' ),
						'type' => 'css_editor',
						'heading' => esc_html__( 'CSS box', 'housico-shortcodes' ),
						'param_name' => 'css'
					)
				)
			)
		);
	}
?>