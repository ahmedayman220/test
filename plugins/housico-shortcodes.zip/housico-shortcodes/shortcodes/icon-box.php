<?php 

	if ( !defined('ABSPATH') ) exit();

	/**
	 * Icon Box Shortcode
	 *
	 * @param string $atts['icon_library']
	 * @param string $atts['icon_housico']
	 * @param string $atts['icon_flexipress']
	 * @param string $atts['icon_fontawesome']
	 * @param string $atts['size']
	 * @param string $atts['position']
	 * @param string $atts['style']
	 * @param string $atts['link']
	 * @param string $atts['title']
	 * @param string $atts['description']
	 * @param string $atts['read_more_text']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['custom_colors']
	 * @param string $atts['icon_normal_color']
	 * @param string $atts['icon_normal_border_color']
	 * @param string $atts['icon_normal_bg_color']
	 * @param string $atts['icon_hover_color']
	 * @param string $atts['icon_hover_border_color']
	 * @param string $atts['icon_hover_bg_color']
	 * @param string $atts['title_normal_color']
	 * @param string $atts['title_hover_color']
	 * @param string $atts['description_color']
	 * @param string $atts['css']
	 */

	function housico_icon_box_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"icon_library" => "",
			"icon_housico" => "",
			"icon_flexipress" => "",
			"icon_fontawesome" => "",
			"size" => "",
			"position" => "",
			"style" => "",
			"color" => "",
			"link" => "",
			"title" => "",
			"description" => "",
			"read_more_text" => "",
			"class" => "",
			"custom_colors" => "",
			"icon_normal_color" => "",
			"icon_normal_border_color" => "",
			"icon_normal_bg_color" => "",
			"icon_hover_color" => "",
			"icon_hover_border_color" => "",
			"icon_hover_bg_color" => "",
			"title_normal_color" => "",
			"title_hover_color" => "",
			"description_color" => "",
			"css" => ""
		), $atts, 'vu_icon_box' );

		if ( $atts['custom_colors'] == '1' ) {
			$custom_class = housico_custom_class();
			$atts['class'] .= ' '. $custom_class;
		}

		if ( function_exists('vc_shortcode_custom_css_class') ) {
			$atts['class'] .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim($atts['class']);

		$link = vc_build_link( $atts['link'] );
		
		ob_start();
		?>
			<div class="vu_icon-box vu_ib-size-<?php echo esc_attr($atts['size']); ?> vu_ib-position-<?php echo esc_attr($atts['position']); ?> vu_ib-style-<?php echo esc_attr($atts['style']); ?> vu_ib-color-<?php echo esc_attr($atts['color']); ?> clearfix <?php housico_extra_class($atts['class']); ?>">
				<?php if ( $atts['custom_colors'] == '1' ) : ?>
					<style>
						<?php if ( !empty($atts['icon_normal_color']) ) : ?>
							.vu_icon-box.<?php echo esc_attr($custom_class); ?> .vu_ib-icon { color: <?php echo esc_attr($atts['icon_normal_color']); ?> !important; }
						<?php endif; ?>
						<?php if ( !empty($atts['icon_normal_border_color']) ) : ?>
							.vu_icon-box.<?php echo esc_attr($custom_class); ?> .vu_ib-icon { border-color: <?php echo esc_attr($atts['icon_normal_border_color']); ?> !important; }
						<?php endif; ?>
						<?php if ( !empty($atts['icon_normal_bg_color']) ) : ?>
							.vu_icon-box.<?php echo esc_attr($custom_class); ?> .vu_ib-icon { background-color: <?php echo esc_attr($atts['icon_normal_bg_color']); ?> !important; }
						<?php endif; ?>
						<?php if ( !empty($atts['icon_hover_color']) ) : ?>
							.vu_icon-box.<?php echo esc_attr($custom_class); ?>:hover .vu_ib-icon { color: <?php echo esc_attr($atts['icon_hover_color']); ?> !important; }
						<?php endif; ?>
						<?php if ( !empty($atts['icon_hover_border_color']) ) : ?>
							.vu_icon-box.<?php echo esc_attr($custom_class); ?>:hover .vu_ib-icon { border-color: <?php echo esc_attr($atts['icon_hover_border_color']); ?> !important; }
						<?php endif; ?>
						<?php if ( !empty($atts['icon_hover_bg_color']) ) : ?>
							.vu_icon-box.<?php echo esc_attr($custom_class); ?>:hover .vu_ib-icon { background-color: <?php echo esc_attr($atts['icon_hover_bg_color']); ?> !important; }
						<?php endif; ?>
						<?php if ( !empty($atts['title_normal_color']) ) : ?>
							.vu_icon-box.<?php echo esc_attr($custom_class); ?> .vu_ib-title { color: <?php echo esc_attr($atts['title_normal_color']); ?> !important; }
						<?php endif; ?>
						<?php if ( !empty($atts['title_hover_color']) ) : ?>
							.vu_icon-box.<?php echo esc_attr($custom_class); ?> .vu_ib-title:hover { color: <?php echo esc_attr($atts['title_hover_color']); ?> !important; }
						<?php endif; ?>
						<?php if ( !empty($atts['description_color']) ) : ?>
							.vu_icon-box.<?php echo esc_attr($custom_class); ?> .vu_ib-description p { color: <?php echo esc_attr($atts['description_color']); ?> !important; }
						<?php endif; ?>
					</style>
				<?php endif; ?>

				<span class="vu_ib-icon"><i class="<?php echo esc_attr($atts['icon_'. esc_attr($atts['icon_library'])]); ?>"></i></span>

				<?php if ( !empty($atts['title']) or !empty($atts['description']) ) : ?>
					<div class="vu_ib-content">
						<?php 
							if ( !empty($atts['title']) ) {
								if ( strlen( $atts['link'] ) > 0 and strlen( $link['url'] ) > 0 ) {
									echo '<h5 class="vu_ib-title"><a href="'. esc_url( $link['url'] ) .'" title="'. esc_attr( $link['title'] ) .'" target="'. ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '">'. esc_html($atts['title']) .'</a></h5>';
								} else {
									echo '<h5 class="vu_ib-title">'. esc_html($atts['title']) .'</h5>';
								}
							} 
						?>
						<?php if ( !empty($atts['description']) ) { echo '<div class="vu_ib-description">'. wpautop($atts['description']) .'</div>'; } ?>

						<?php if ( !empty($atts['read_more_text']) and strlen( $atts['link'] ) > 0 and strlen( $link['url'] ) > 0 ) { echo '<div class="clear"></div><a href="'. esc_url( $link['url'] ) .'" title="'. esc_attr( $link['title'] ) .'" target="'. ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '" class="vu_ib-read-more vu_link-inverse">'. esc_html($atts['read_more_text']) .'</a>'; } ?>
					</div>
				<?php endif; ?>
			</div>
		<?php

		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_icon_box', 'housico_icon_box_shortcode');

	/**
	 * Icon Box VC Shortcode
	 */

	if ( class_exists('WPBakeryShortCode') ){
		class WPBakeryShortCode_vu_icon_box extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_icon_box", $atts);

				return do_shortcode( housico_generate_shortcode('vu_icon_box', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Icon Box", 'housico-shortcodes'),
				"description" => esc_html__("Add icon box", 'housico-shortcodes'),
				"base"		=> "vu_icon_box",
				"class"		=> "vc_vu_icon_box",
				"icon"		=> "vu_element-icon vu_icon-box-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						'type' => 'dropdown',
						'heading' => esc_html__('Icon Library', 'housico-shortcodes'),
						'param_name' => 'icon_library',
						'value' => array(
							esc_html__('Housico', 'housico-shortcodes') => 'housico',
							esc_html__('FlexiPress', 'housico-shortcodes') => 'flexipress',
							esc_html__('FontAwesome', 'housico-shortcodes') => 'fontawesome'
						),
						"save_always" => true,
						"description" => esc_html__("Select icon library.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "icon_housico",
						"dependency" => array("element" => "icon_library", "value" => "housico"),
						"settings" => array(
							"emptyIcon" => false,
							"type" => 'housico',
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "icon_flexipress",
						"dependency" => array("element" => "icon_library", "value" => "flexipress"),
						"settings" => array(
							"emptyIcon" => false,
							"type" => 'flexipress',
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "icon_fontawesome",
						"dependency" => array("element" => "icon_library", "value" => "fontawesome"),
						"settings" => array(
							"emptyIcon" => false,
							"type" => 'fontawesome',
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Size", 'housico-shortcodes'),
						"param_name" => "size",
						"value" => array(
							esc_html__("Large", 'housico-shortcodes') => "large",
							esc_html__("Medium", 'housico-shortcodes') => "medium",
							esc_html__("Small", 'housico-shortcodes') => 'small'
						),
						"save_always" => true,
						"description" => esc_html__("Select icon size.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						'type' => 'dropdown',
						'heading' => esc_html__('Position', 'housico-shortcodes'),
						'param_name' => 'position',
						'value' => array(
							esc_html__('Left', 'housico-shortcodes') => 'left',
							esc_html__('Top', 'housico-shortcodes') => 'top',
							esc_html__('Right', 'housico-shortcodes') => 'right'
						),
						"save_always" => true,
						"description" => esc_html__("Select icon position.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						'type' => 'dropdown',
						'heading' => esc_html__('Style', 'housico-shortcodes'),
						'param_name' => 'style',
						'value' => array(
							esc_html__('None', 'housico-shortcodes') => 'none',
							esc_html__('Circle Fill', 'housico-shortcodes') => 'circle-fill',
							esc_html__('Circle Outline', 'housico-shortcodes') => 'circle-outline',
							esc_html__('Square Fill', 'housico-shortcodes') => 'square-fill',
							esc_html__('Square Outline', 'housico-shortcodes') => 'square-outline',
							esc_html__('Rounded Fill', 'housico-shortcodes') => 'rounded-fill',
							esc_html__('Rounded Outline', 'housico-shortcodes') => 'rounded-outline',
							esc_html__('Rhombus Fill', 'housico-shortcodes') => 'rhombus-fill',
							esc_html__('Rhombus Outline', 'housico-shortcodes') => 'rhombus-outline',
							esc_html__('Octagon Fill', 'housico-shortcodes') => 'octagon-fill',
							esc_html__('Octagon Outline', 'housico-shortcodes') => 'octagon-outline'
						),
						"save_always" => true,
						"description" => esc_html__("Select icon style.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Color", 'housico-shortcodes'),
						"param_name" => "color",
						"value" => array(
							esc_html__("Primary", 'housico-shortcodes') => "primary",
							esc_html__("Secondary", 'housico-shortcodes') => "secondary",
							esc_html__("Black", 'housico-shortcodes') => "black",
							esc_html__("Gray", 'housico-shortcodes') => "gray",
							esc_html__("White", 'housico-shortcodes') => "white"
						),
						"std" => 'primary',
						"save_always" => true,
						"description" => esc_html__("Select icon box color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Title", 'housico-shortcodes'),
						"param_name" => "title",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter title.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textarea",
						"heading" => esc_html__("Description", 'housico-shortcodes'),
						"param_name" => "description",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter description.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Read more text", 'dentalpress-shortcodes'),
						"param_name" => "read_more_text",
						"value" => esc_html__("Read More", 'housico-shortcodes'),
						"save_always" => true,
						"description" => esc_html__("Enter read more text.", 'dentalpress-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "vc_link",
						"heading" => esc_html__("URL (Link)", 'housico-shortcodes'),
						"param_name" => "link",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Add link to icon box.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Custom Colors?", 'housico-shortcodes'),
						"param_name" => "custom_colors",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '0',
						"save_always" => true,
						"description" => esc_html__("Check to use custom colors.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icon Normal Color", 'housico-shortcodes'),
						"param_name" => "icon_normal_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select icon normal color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icon Normal Border Color", 'housico-shortcodes'),
						"param_name" => "icon_normal_border_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select icon normal border color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icon Normal BG Color", 'housico-shortcodes'),
						"param_name" => "icon_normal_bg_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select icon normal background color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icon Hover Color", 'housico-shortcodes'),
						"param_name" => "icon_hover_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select icon hover color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icon Hover Border Color", 'housico-shortcodes'),
						"param_name" => "icon_hover_border_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select icon hover border color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icon Hover BG Color", 'housico-shortcodes'),
						"param_name" => "icon_hover_bg_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select icon hover background color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Title Normal Color", 'housico-shortcodes'),
						"param_name" => "title_normal_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select title normal color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Title Hover Color", 'housico-shortcodes'),
						"param_name" => "title_hover_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select title hover color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Description Color", 'housico-shortcodes'),
						"param_name" => "description_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-4",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select description color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Design Options", 'housico-shortcodes' ),
						"type" => "css_editor",
						"heading" => esc_html__("CSS box", 'housico-shortcodes' ),
						"param_name" => "css"
					)
				)
			)
		);
	}
?>