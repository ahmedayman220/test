<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Pie Chart Shortcode
	 *
	 * @param string $atts['style']
	 * @param string $atts['type']
	 * @param string $atts['text']
	 * @param string $atts['icon_library']
	 * @param string $atts['icon_flexipress']
	 * @param string $atts['icon_fontawesome']
	 * @param string $atts['icon_housico']
	 * @param string $atts['value']
	 * @param string $atts['line_width']
	 * @param string $atts['size']
	 * @param string $atts['text_color']
	 * @param string $atts['bar_color']
	 * @param string $atts['track_color']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['css']
	 */

	function housico_pie_chart_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"style" => "",
			"type" => "",
			"text" => "",
			"icon_library" => "",
			"icon_flexipress" => "",
			"icon_fontawesome" => "",
			"icon_housico" => "",
			"font_size" => "",
			"value" => "",
			"line_width" => "",
			"size" => "",
			"text_color" => "",
			"bar_color" => "",
			"track_color" => "",
			"class" => "",
			"css" => ""
		), $atts, 'vu_pie_chart' );

		if( function_exists('vc_shortcode_custom_css_class') ) {
			$atts['class'] .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim($atts['class']);

		$size = absint($atts['size']);

		$pie_chart_options = array();

		$pie_chart_options['scaleColor'] = false;
		$pie_chart_options['lineCap'] = 'square';
		$pie_chart_options['animate'] = array("duration" => 1000, "enabled" => true);

		$pie_chart_options['barColor'] = esc_attr($atts['bar_color']);
		$pie_chart_options['trackColor'] = ($atts['style'] != '1') ? esc_attr($atts['track_color']) : false;
		$pie_chart_options['lineWidth'] = absint($atts['line_width']);
		$pie_chart_options['size'] = $size;

		$custom_class = 'vu_pc-custom-'. rand(100000, 999999);

		ob_start();
	?>
		<div class="vu_pie-chart vu_pc-style-<?php echo esc_attr($atts['style']); ?> <?php echo esc_attr($custom_class); ?><?php housico_extra_class($atts['class']); ?>">
			<div class="vu_pc-graph" data-percent="<?php echo esc_attr($atts['value']); ?>" data-options="<?php echo esc_attr(json_encode($pie_chart_options)); ?>"<?php echo ($size > 0) ? ' style="height:'. $size .'px;"' : ''; ?>>
				<div class="vu_pc-graph-text"<?php echo ($size > 0) ? ' style="width:'. $size .'px;height:'. $size .'px;line-height:'. $size .'px;margin-left:-'. $size / 2 .'px;"' : ''; ?>>
					<?php 
						if( $atts['type'] == 'icon' ) {
							echo '<span class="vu_pc-icon"'. (!empty($atts['text_color']) ? ' style="font-size:'. esc_attr($atts['font_size']) .'px;color:'. esc_attr($atts['text_color']) .';"' : '') .'><i class="'. esc_attr($atts['icon_'. esc_attr($atts['icon_library'])]) .'"></i></span>';
						} else {
							echo '<span class="vu_pc-text" title="'. esc_attr($atts['text']) .'"'. (!empty($atts['text_color']) ? ' style="font-size:'. esc_attr($atts['font_size']) .'px;color:'. esc_attr($atts['text_color']) .';"' : '') .'>'. esc_html($atts['text']) .'</span>';
						}
					?>
				</div>

				<?php echo !empty($atts['track_color']) ? '<style>.vu_pie-chart.'. esc_attr($custom_class) .' .vu_pc-graph-text:before,.vu_pie-chart.'. esc_attr($custom_class) .' .vu_pc-graph-text:after{border-color:'. esc_attr($atts['track_color']) .'!important;}.vu_pie-chart.'. esc_attr($custom_class) .' .vu_pc-graph-text:after{top:'. absint($atts['line_width']) .'px;right:'. absint($atts['line_width']) .'px;bottom:'. absint($atts['line_width']) .'px;left:'. absint($atts['line_width']) .'px;}</style>' : ''; ?>
			</div>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_pie_chart', 'housico_pie_chart_shortcode');

	/**
	 * Pie Chart VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_pie_chart extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_pie_chart", $atts);

				return do_shortcode( housico_generate_shortcode('vu_pie_chart', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Pie Chart", 'housico-shortcodes'),
				"description" => esc_html__("Custom animate pie chart", 'housico-shortcodes'),
				"base"		=> "vu_pie_chart",
				"class"		=> "vc_vu_pie_chart",
				"icon"		=> "vu_element-icon vu_pie-chart-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"type" => "image_select",
						"heading" => esc_html__("Style", 'housico-shortcodes'),
						"param_name" => "style",
						"value" => array(
							"1" => array(
									"title" => esc_html__("#1", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/pie-chart-styles/1.jpg"
								),
							"2" => array(
									"title" => esc_html__("#2", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/pie-chart-styles/2.jpg"
								),
							"3" => array(
									"title" => esc_html__("#3", 'housico-shortcodes'),
									"image" => Housico_Shortcodes::$_url ."assets/img/pie-chart-styles/3.jpg"
								)
						),
						"width" => "calc(33.33333% - 10px)",
						"height" => "auto",
						"std" => "1",
						"save_always" => true,
						"description" => esc_html__("Select pie chart style.", 'housico-shortcodes')
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__("Type", 'housico-shortcodes'),
						"param_name" => "type",
						"value" => array(
							esc_html__("Text", 'housico-shortcodes') => "text",
							esc_html__("Icon", 'housico-shortcodes') => "icon"
						),
						"save_always" => true,
						"description" => esc_html__("Select pie chart type.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Text", 'housico-shortcodes'),
						"param_name" => "text",
						"dependency" => array("element" => "type", "value" => "text"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter pie chart text.", 'housico-shortcodes')
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Icon Library', 'housico-shortcodes'),
						'param_name' => 'icon_library',
						"dependency" => array("element" => "type", "value" => "icon"),
						'value' => array(
							esc_html__('FlexiPress', 'housico-shortcodes') => 'flexipress',
							esc_html__('FontAwesome', 'housico-shortcodes') => 'fontawesome',
							esc_html__('Housico', 'housico-shortcodes') => 'housico'
						),
						"save_always" => true,
						"description" => esc_html__("Select icon library.", 'housico-shortcodes')
					),
					array(
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "icon_flexipress",
						"dependency" => array("element" => "icon_library", "value" => "flexipress"),
						"settings" => array(
							"emptyIcon" => false,
							"type" => 'flexipress',
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "icon_housico",
						"dependency" => array("element" => "icon_library", "value" => "housico"),
						"settings" => array(
							"emptyIcon" => false,
							"type" => 'housico',
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", 'housico-shortcodes'),
						"param_name" => "icon_fontawesome",
						"dependency" => array("element" => "icon_library", "value" => "fontawesome"),
						"settings" => array(
							"emptyIcon" => false,
							"iconsPerPage" => 100
						),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Pick an icon from the library.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Value", 'housico-shortcodes'),
						"param_name" => "value",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter value for graph from 0 to 100.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Line Width", 'housico-shortcodes'),
						"param_name" => "line_width",
						"value" => "10",
						"save_always" => true,
						"description" => esc_html__("Enter pie chart line width in px.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Size", 'housico-shortcodes'),
						"param_name" => "size",
						"value" => "170",
						"save_always" => true,
						"description" => esc_html__("Enter chart size (note: it applies for both width and height).", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Font Size", 'housico-shortcodes'),
						"param_name" => "font_size",
						"value" => "36",
						"save_always" => true,
						"description" => esc_html__("Enter font size for text/icon in integer.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Text Color", 'housico-shortcodes'),
						"param_name" => "text_color",
						"value" => "#303745",
						"save_always" => true,
						"description" => esc_html__("Select text/icon color.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Bar Color", 'housico-shortcodes'),
						"param_name" => "bar_color",
						"value" => "#eeb10b",
						"save_always" => true,
						"description" => esc_html__("Select bar color.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Track Color", 'housico-shortcodes'),
						"param_name" => "track_color",
						"value" => "#f2f2f2",
						"save_always" => true,
						"description" => esc_html__("Select track color.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						'group' => esc_html__( 'Design Options', 'housico-shortcodes' ),
						'type' => 'css_editor',
						'heading' => esc_html__( 'CSS box', 'housico-shortcodes' ),
						'param_name' => 'css'
					)
				)
			)
		);
	}
?>