<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Pricing Table Shortcode
	 *
	 * @param string $atts['title']
	 * @param string $atts['amount']
	 * @param string $atts['currency']
	 * @param string $atts['period']
	 * @param string $atts['bg_color']
	 * @param string $atts['content']
	 * @param string $atts['show_button']
	 * @param string $atts['button_text']
	 * @param string $atts['button_link']
	 * @param string $atts['active']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 */

	function housico_pricing_table_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"title" => "",
			"amount" => "",
			"currency" => "",
			"period" => "",
			"show_button" => "",
			"button_text" => "",
			"button_link" => "",
			"active" => "",
			"class" => ""
		), $atts, 'vu_pricing_table' );

		$button_link = vc_build_link( $atts['button_link'] );

		$amount = @explode('.', $atts['amount']);

		ob_start();
	?>
		<div class="vu_pricing-table<?php echo ($atts['active'] == '1') ? ' vu_pt-active' : ''; ?><?php housico_extra_class($atts['class']); ?>">
			<div class="vu_pt-header">
				<div class="vu_pt-price">
					<span class="vu_pt-currency"><?php echo esc_html($atts['currency']); ?></span>
					<span class="vu_pt-amount<?php echo (isset($amount[1]) && !empty($amount[1])) ? ' vu_pt-amount-with-decimal' : ''; ?>"><?php echo isset($amount[0]) ? esc_html($amount[0]) : esc_html($atts['amount']); ?><?php echo (isset($amount[1]) && !empty($amount[1])) ? '<sup>'. esc_html($amount[1]) .'</sup>' : ''; ?></span>
					<span class="vu_pt-period"><?php echo esc_html($atts['period']); ?></span>
				</div>

				<h4 class="vu_pt-title"><?php echo esc_html($atts['title']); ?></h4>
			</div>

			<div class="vu_pt-content">
				<?php echo housico_remove_wpautop($content, true); ?>
			</div>
			
			<?php if ( $atts['show_button'] == '1' ) { ?>
				<div class="vu_pt-button">
					<?php echo '<a href="'. esc_url( $button_link['url'] ) .'" title="'. esc_attr( $button_link['title'] ) .'" target="'. ( strlen( $button_link['target'] ) > 0 ? esc_attr( $button_link['target'] ) : '_self' ) . '">'. esc_attr($atts['button_text']) .'</a>'; ?>
				</div>
			<?php } ?>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_pricing_table', 'housico_pricing_table_shortcode');

	/**
	 * Pricing Table VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_pricing_table extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_pricing_table", $atts);

				return do_shortcode( housico_generate_shortcode('vu_pricing_table', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Pricing Table", 'housico-shortcodes'),
				"description" => esc_html__("Add pricing table item", 'housico-shortcodes'),
				"base"		=> "vu_pricing_table",
				"class"		=> "vc_vu_pricing-table",
				"icon"		=> "vu_element-icon vu_pricing-table-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"group" => esc_html__('Header', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Title", 'housico-shortcodes'),
						"param_name" => "title",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter table title [eg. Basic Pack].", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Header', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Amount", 'housico-shortcodes'),
						"param_name" => "amount",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter amount/price [eg. 35]", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Header', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Currency", 'housico-shortcodes'),
						"param_name" => "currency",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter table currency [eg. $]", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Header', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Period", 'housico-shortcodes'),
						"param_name" => "period",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter price period [eg. per month, year]", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Header', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Active", 'housico-shortcodes'),
						"param_name" => "active",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => "0",
						"save_always" => true,
						"description" => esc_html__("Check to make pricing table active.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Header', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Content', 'housico-shortcodes'),
						"type" => "textarea_html",
						"heading" => esc_html__("Content", 'housico-shortcodes'),
						"param_name" => "content",
						"value" => "<ul><li>item</li><li>item</li><li>item</li><li>item</li><li>item</li></ul>",
						"save_always" => true,
						"description" => esc_html__("Write pricing table content.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Button', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Show Button", 'housico-shortcodes'),
						"param_name" => "show_button",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => "0",
						"save_always" => true,
						"description" => esc_html__("Check this to show button.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Button', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Text", 'housico-shortcodes'),
						"param_name" => "button_text",
						"dependency" => array("element" => "show_button", "value" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter button text. [eg. get now, see more].", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Button', 'housico-shortcodes'),
						"type" => "vc_link",
						"heading" => esc_html__("URL (Link)", 'housico-shortcodes'),
						"param_name" => "button_link",
						"dependency" => array("element" => "show_button", "value" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Add link to button.", 'housico-shortcodes')
					)
				)
			)
		);
	}
?>