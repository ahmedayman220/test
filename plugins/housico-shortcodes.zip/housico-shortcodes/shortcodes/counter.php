<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Counter Shortcode
	 *
	 * @param string $atts['digit']
	 * @param string $atts['prefix']
	 * @param string $atts['suffix']
	 * @param string $atts['label']
	 * @param string $atts['custom_colors']
	 * @param string $atts['digit_color']
	 * @param string $atts['label_color']
	 * @param string $atts['line_color']
	 * @param string $atts['delay']
	 * @param string $atts['time']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['css']
	 */

	function housico_counter_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"digit" => "",
			"label" => "",
			"prefix" => "",
			"suffix" => "",
			"custom_colors" => "",
			"digit_color" => "",
			"label_color" => "",
			"line_color" => "",
			"delay" => "",
			"time" => "",
			"class" => "",
			"css" => ""
		), $atts, 'vu_counter' );

		if( $atts['custom_colors'] == '1' ) {
			$custom_class = housico_custom_class();
			$atts['class'] .= ' '. $custom_class;
		}

		if( function_exists('vc_shortcode_custom_css_class') ) {
			$atts['class'] .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		ob_start();
	?>
		<div class="vu_counter<?php housico_extra_class($atts['class']); ?>">
			<?php if( $atts['custom_colors'] == '1' ) : ?>
				<style>
					<?php if( !empty($atts['digit_color']) ) : ?>
						.vu_counter.<?php echo esc_attr($custom_class); ?> .vu_c-holder { color: <?php echo esc_attr($atts['digit_color']); ?>}
					<?php endif; ?>

					<?php if( !empty($atts['label_color']) ) : ?>
						.vu_counter.<?php echo esc_attr($custom_class); ?> .vu_c-label { color: <?php echo esc_attr($atts['label_color']); ?>}
					<?php endif; ?>

					<?php if( !empty($atts['line_color']) ) : ?>
						.vu_counter.<?php echo esc_attr($custom_class); ?> .vu_c-holder:after { background-color: <?php echo esc_attr($atts['line_color']); ?>}
					<?php endif; ?>
				</style>
			<?php endif; ?>

			<span class="vu_c-holder">
				<?php if( !empty($atts['prefix']) ) : ?>
					<span class="vu_c-prefix"><?php echo esc_html($atts['prefix']); ?></span>
				<?php endif; ?>

				<span class="vu_c-digit"<?php echo ((!empty($atts['delay'])) ? ' data-delay="'. esc_attr($atts['delay']) .'"' : '') . ((!empty($atts['time'])) ? ' data-time="'. esc_attr($atts['time']) .'"' : ''); ?>><?php echo esc_html($atts['digit']); ?></span>

				<?php if( !empty($atts['suffix']) ) : ?>
					<span class="vu_c-suffix"><?php echo esc_html($atts['suffix']); ?></span>
				<?php endif; ?>
			</span>

			<p class="vu_c-label"><?php echo esc_html($atts['label']); ?></p>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_counter', 'housico_counter_shortcode');

	/**
	 * Counter VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_counter extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_counter", $atts);

				return do_shortcode( housico_generate_shortcode('vu_counter', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Counter", 'housico-shortcodes'),
				"description" => esc_html__("Counter/Milestone", 'housico-shortcodes'),
				"base"		=> "vu_counter",
				"class"		=> "vc_vu_counter",
				"icon"		=> "vu_element-icon vu_counter-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"type" => "textfield",
						"heading" => esc_html__("Digit", 'housico-shortcodes'),
						"param_name" => "digit",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter counter digit. Eg. 1234.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Prefix", 'housico-shortcodes'),
						"param_name" => "prefix",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter counter prefix. Eg. $.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Suffix", 'housico-shortcodes'),
						"param_name" => "suffix",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter counter suffix. Eg. %.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Label", 'housico-shortcodes'),
						"param_name" => "label",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter counter label eg. Customers.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Delay", 'housico-shortcodes'),
						"param_name" => "delay",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Specify time delay in milliseconds after which counter digit will begin to increase.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Time", 'housico-shortcodes'),
						"param_name" => "time",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Specify time interval in milliseconds by which the last counter digit will be displayed. Default is 1000ms", 'housico-shortcodes')
					),
					array(
						"type" => "checkbox",
						"heading" => esc_html__("Custom Colors?", 'housico-shortcodes'),
						"param_name" => "custom_colors",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '0',
						"save_always" => true,
						"description" => esc_html__("Check to use custom colors.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Digit Color", 'housico-shortcodes'),
						"param_name" => "digit_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select digit custom color.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Label Color", 'housico-shortcodes'),
						"param_name" => "label_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select label custom color.", 'housico-shortcodes')
					),
					array(
						"type" => "colorpicker",
						"heading" => esc_html__("Line Color", 'housico-shortcodes'),
						"param_name" => "line_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select line custom color.", 'housico-shortcodes')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Design Options", 'housico-shortcodes' ),
						"type" => "css_editor",
						"heading" => esc_html__("CSS box", 'housico-shortcodes' ),
						"param_name" => "css"
					)
				)
			)
		);
	}
?>