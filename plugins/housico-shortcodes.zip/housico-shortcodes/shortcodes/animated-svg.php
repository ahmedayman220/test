<?php 

	if ( !defined('ABSPATH') ) exit();
	
	/**
	 * Animated SVG Shortcode
	 *
	 * @param string $atts['svg']
	 * @param string $atts['width']
	 * @param string $atts['position']
	 * @param string $atts['title']
	 * @param string $atts['link']
	 * @param string $atts['description']
	 * @param string $atts['class'] Add a class name and then refer to it in your css file.
	 * @param string $atts['animation']
	 * @param string $atts['delay']
	 * @param string $atts['duration']
	 * @param string $atts['timing']
	 * @param string $atts['custom_colors']
	 * @param string $atts['svg_normal_color']
	 * @param string $atts['svg_hover_color']
	 * @param string $atts['title_normal_color']
	 * @param string $atts['title_hover_color']
	 * @param string $atts['description_color']
	 * @param string $atts['css']
	 */

	function housico_animated_svg_shortcode( $atts, $content = null ) {
		$atts = housico_shortcode_atts( array(
			"svg" => "",
			"width" => "",
			"position" => "",
			"title" => "",
			"link" => "",
			"description" => "",
			"class" => "",
			"animation" => "",
			"delay" => "",
			"duration" => "",
			"timing" => "",
			"custom_colors" => "",
			"svg_normal_color" => "",
			"svg_hover_color" => "",
			"title_normal_color" => "",
			"title_hover_color" => "",
			"description_color" => "",
			"class" => "",
			"css" => ""
		), $atts, 'vu_animated_svg' );

		if ( $atts['custom_colors'] == '1' ) {
			$custom_class = housico_custom_class();
			$atts['class'] .= ' '. $custom_class;
		}

		if( function_exists('vc_shortcode_custom_css_class') ) {
			$atts['class'] .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim($atts['class']);

		$options = array(
			"type" => $atts['animation'],
			"file" => housico_get_attachment_image_src(absint($atts['svg']), 'full'),
			"start" => 'inViewport',
			"duration" => absint($atts['duration']),
			"delay" => absint($atts['delay']),
			"_id" => 'vu_as-svg-'. rand(100000, 999999),
			"_timing" => $atts['timing']
		);

		$link = vc_build_link( $atts['link'] );

		ob_start();
	?>
		<div class="vu_animated-svg vu_as-position-<?php echo esc_attr($atts['position']); ?> <?php housico_extra_class($atts['class']); ?>" data-options="<?php echo esc_attr(json_encode($options)); ?>">
			<?php if( $atts['custom_colors'] == '1' ) : ?>
				<style>
					<?php if( !empty($atts['svg_normal_color']) ) : ?>
						.vu_animated-svg.<?php echo esc_attr($custom_class); ?> .vu_as-svg svg path[stroke] { stroke: <?php echo esc_attr($atts['svg_normal_color']); ?> !important; }
					<?php endif; ?>
					<?php if( !empty($atts['svg_hover_color']) ) : ?>
						.vu_animated-svg.<?php echo esc_attr($custom_class); ?>:hover .vu_as-svg svg path[stroke] { stroke: <?php echo esc_attr($atts['svg_hover_color']); ?> !important; }
					<?php endif; ?>
					<?php if( !empty($atts['title_normal_color']) ) : ?>
						.vu_animated-svg.<?php echo esc_attr($custom_class); ?> .vu_as-title { color: <?php echo esc_attr($atts['title_normal_color']); ?> !important; }
					<?php endif; ?>
					<?php if( !empty($atts['title_hover_color']) ) : ?>
						.vu_animated-svg.<?php echo esc_attr($custom_class); ?> .vu_as-title:hover { color: <?php echo esc_attr($atts['title_hover_color']); ?> !important; }
					<?php endif; ?>
					<?php if( !empty($atts['description_color']) ) : ?>
						.vu_animated-svg.<?php echo esc_attr($custom_class); ?> .vu_as-description p { color: <?php echo esc_attr($atts['description_color']); ?> !important; }
					<?php endif; ?>
				</style>
			<?php endif; ?>

			<div id="<?php echo esc_attr($options['_id']); ?>" class="vu_as-svg" style="width:<?php echo esc_attr($atts['width']); ?>;"></div>

			<?php if( !empty($atts['title']) or !empty($atts['description']) ) : ?>
				<div class="vu_as-content"<?php echo ($atts['position'] != 'top') ? ' style="margin-'. esc_attr($atts['position']) .':calc('. esc_attr($atts['width']) .' + 30px);"' : ''; ?>>
					<?php 
						if( !empty($atts['title']) ) {
							if ( strlen( $atts['link'] ) > 0 && strlen( $link['url'] ) > 0 ) {
								echo '<h5 class="vu_as-title"><a href="'. esc_url( $link['url'] ) .'" title="'. esc_attr( $link['title'] ) .'" target="'. ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '">'. esc_html($atts['title']) .'</a></h5>';
							} else {
								echo '<h5 class="vu_as-title">'. esc_html($atts['title']) .'</h5>';
							}
						} 
					?>
					<?php if( !empty($atts['description']) ) { echo '<div class="vu_as-description">'. wpautop($atts['description']) .'</div>'; } ?>
				</div>
			<?php endif; ?>
		</div>
	<?php
		$output = ob_get_contents();
		ob_end_clean();
		
		return $output;
	}

	add_shortcode('vu_animated_svg', 'housico_animated_svg_shortcode');

	/**
	 * Animated SVG VC Shortcode
	 */

	if( class_exists('WPBakeryShortCode') ) {
		class WPBakeryShortCode_vu_animated_svg extends WPBakeryShortCode {
			public function content($atts, $content = null) {
				$atts = vc_map_get_attributes("vu_animated_svg", $atts);

				return do_shortcode( housico_generate_shortcode('vu_animated_svg', $atts, $content) );
			}
		}

		vc_map(
			array(
				"name"		=> esc_html__("Animated SVG", 'housico-shortcodes'),
				"description" => esc_html__("SVG icon with animation", 'housico-shortcodes'),
				"base"		=> "vu_animated_svg",
				"class"		=> "vc_vu_animated_svg",
				"icon"		=> "vu_element-icon vu_animated-svg-icon",
				"controls"	=> "full",
				"category" => esc_html__('Housico', 'housico-shortcodes'),
				"params"	=> array(
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "attach_image",
						"heading" => esc_html__("SVG", 'housico-shortcodes'),
						"param_name" => "svg",
						"value" => "",
						"admin_label" => true,
						"save_always" => true,
						"description" => esc_html__("Select SVG file from media library.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Width", 'housico-shortcodes'),
						"param_name" => "width",
						"value" => "64px",
						"save_always" => true,
						"description" => esc_html__("Enter SVG width. (Note: CSS measurement units allowed).", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						'type' => 'dropdown',
						'heading' => esc_html__('Position', 'housico-shortcodes'),
						'param_name' => 'position',
						'value' => array(
							esc_html__('Left', 'housico-shortcodes') => 'left',
							esc_html__('Top', 'housico-shortcodes') => 'top',
							esc_html__('Right', 'housico-shortcodes') => 'right'
						),
						"save_always" => true,
						"description" => esc_html__("Select position.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Title", 'housico-shortcodes'),
						"param_name" => "title",
						"admin_label" => true,
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter title.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "vc_link",
						"heading" => esc_html__("URL (Link)", 'housico-shortcodes'),
						"param_name" => "link",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Add link to title.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textarea",
						"heading" => esc_html__("Description", 'housico-shortcodes'),
						"param_name" => "description",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter description.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('General', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Extra class name", 'housico-shortcodes'),
						"param_name" => "class",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Animation', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Animation", 'housico-shortcodes'),
						"param_name" => "animation",
						"value" => array(
							esc_html__("Delayed", 'housico-shortcodes') => "delayed",
							esc_html__("Syncronous", 'housico-shortcodes') => "async",
							esc_html__("One By One", 'housico-shortcodes') => "oneByOne"
						),
						"save_always" => true,
						"description" => esc_html__("Select animation type.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Animation', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Delay", 'housico-shortcodes'),
						"param_name" => "delay",
						"dependency" => array("element" => "animation", "value" => "delayed"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Enter time between the drawing of first and last path in milliseconds. Delay must be shorter than duration.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Animation', 'housico-shortcodes'),
						"type" => "textfield",
						"heading" => esc_html__("Duration", 'housico-shortcodes'),
						"param_name" => "duration",
						"value" => "200",
						"save_always" => true,
						"description" => esc_html__("Enter animation duration, in milliseconds.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Animation', 'housico-shortcodes'),
						"type" => "dropdown",
						"heading" => esc_html__("Timing Path Function", 'housico-shortcodes'),
						"param_name" => "timing",
						"value" => array(
							esc_html__("Linear", 'housico-shortcodes') => "linear",
							esc_html__("Ease", 'housico-shortcodes') => "ease",
							esc_html__("Ease In", 'housico-shortcodes') => "ease-in",
							esc_html__("Ease Out", 'housico-shortcodes') => "ease-out",
							esc_html__("Ease Out Bounce", 'housico-shortcodes') => "ease-out-bounce"
						),
						"save_always" => true,
						"description" => esc_html__("Select timing animation function.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "checkbox",
						"heading" => esc_html__("Custom Colors?", 'housico-shortcodes'),
						"param_name" => "custom_colors",
						"value" =>  array( esc_html__("Yes, please!", 'housico-shortcodes') => '1'),
						"std" => '0',
						"save_always" => true,
						"description" => esc_html__("Check to use custom colors.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icon Normal Color", 'housico-shortcodes'),
						"param_name" => "svg_normal_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select SVG normal color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Icon Hover Color", 'housico-shortcodes'),
						"param_name" => "svg_hover_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select SVG hover color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Title Normal Color", 'housico-shortcodes'),
						"param_name" => "title_normal_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select title normal color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Title Hover Color", 'housico-shortcodes'),
						"param_name" => "title_hover_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"edit_field_class" => "vc_col-xs-6",
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select title hover color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__('Colors', 'housico-shortcodes'),
						"type" => "colorpicker",
						"heading" => esc_html__("Description Color", 'housico-shortcodes'),
						"param_name" => "description_color",
						"dependency" => array("element" => "custom_colors", "value" => "1"),
						"value" => "",
						"save_always" => true,
						"description" => esc_html__("Select description color.", 'housico-shortcodes')
					),
					array(
						"group" => esc_html__("Design Options", 'housico-shortcodes' ),
						"type" => "css_editor",
						"heading" => esc_html__("CSS box", 'housico-shortcodes' ),
						"param_name" => "css"
					)
				)
			)
		);
	}
?>