<?php 
	/**
	 * Housico Theme Demo Import
	 */

	if ( !defined('ABSPATH') ) exit();

	if( !class_exists('Housico_Demo_Import') ) {
		class Housico_Demo_Import {
			function __construct() {
				add_filter( 'wbc_importer_directory_sort', array($this, 'housico_wbc_importer_directory_sort'), 10 );
				add_filter( 'wbc_importer_directory_title', array($this, 'housico_wbc_importer_directory_title'), 10 );
				add_filter( 'wbc_importer_theme_options_data', array($this, 'housico_wbc_importer_theme_options_data'), 10 );
				add_filter( 'wbc_importer_widgets_data', array($this, 'housico_wbc_importer_widgets_data'), 10 );
				add_filter( 'wbc_importer_content_data', array($this, 'housico_wbc_importer_content_data'), 10 );
				add_action( 'wbc_importer_after_theme_options_import', array($this, 'housico_wbc_importer_after_theme_options_import'), 10, 2 );
				add_action( 'wbc_importer_before_widget_import', array($this, 'housico_wbc_importer_before_widget_import'), 10, 2 );
				add_action( 'wbc_importer_after_content_import', array($this, 'housico_wbc_importer_after_content_import'), 10, 2 );
			}

			// Changing directory order.
			function housico_directory_uksort($a, $b) {
				$dir_order = array(
					'demo' => 1
				);

				return ( isset($dir_order[$a]) && isset($dir_order[$b]) && $dir_order[$a] <= $dir_order[$b] ) ? 1 : -1;
			}

			function housico_wbc_importer_directory_sort( $dir_array ) {
				uksort( $dir_array, array($this, 'housico_directory_uksort') );

				return $dir_array;
			}

			// Changing demo title in options panel so it's not folder name.
			function housico_wbc_importer_directory_title( $title ) {
				$return = '';

				switch ($title) {
					case 'demo':
						$return = 'Housico Demo';
						break;
					
					default:
						$return = $title;
						break;
				}

				return trim($return);
			}

			// Changing theme options data before import
			function housico_wbc_importer_theme_options_data( $data ) {
				// Theme Url
				$theme_url = str_replace('/', '\/', get_template_directory_uri()) . '\/';

				$data = str_replace(
					'http:\/\/themes.flexipress.xyz\/housico\/wp-content\/themes\/housico\/',
					$theme_url,
					$data
				);

				return $data;
			}

			// Changing widgets data before import
			function housico_wbc_importer_widgets_data( $data ) {
				// Site Url
				$site_url = str_replace('/', '\/', get_site_url()) . '\/';

				$data = str_replace(
					'http:\/\/themes.flexipress.xyz\/housico\/',
					$site_url,
					$data
				);

				// Services Menu
				$services_menu = get_term_by( 'name', 'Services', 'nav_menu' );
				$data = str_replace('"nav_menu":16', '"nav_menu":'. $services_menu->term_id, $data);

				return $data;
			}

			// Changing content data before import
			function housico_wbc_importer_content_data( $data ) {
				// Site Url 
				$data = str_replace(
					'http://themes.flexipress.xyz/housico',
					get_site_url(),
					$data
				);

				$data = str_replace(
					urlencode('http://themes.flexipress.xyz/housico'),
					urlencode(get_site_url()),
					$data
				);

				return $data;
			}

			// Add custom sidebars before importing widgets
			function housico_wbc_importer_after_theme_options_import( $demo_active_import , $demo_data_directory_path ) {
				$sidebars = array();

				if( is_array($sidebars) ) {
					foreach ($sidebars as $sidebar) {
						if( !empty($sidebar) ){
							register_sidebar(
								array(
									'id' => sanitize_title($sidebar),
									'name' => $sidebar,
									
									'before_widget' => '<div class="widget %2$s %1$s clearfix">',
									'after_widget' => '</div>',
									
									'before_title' => '<h3 class="widget_title">',
									'after_title' => '</h3>'
								)
							);
						}
					}
				}
			}

			// Deactivate widgets from all sidebars
			function housico_wbc_importer_before_widget_import( $demo_active_import , $demo_data_directory_path ) {
				update_option( 'sidebars_widgets', array() );
			}

			// Run After Demo Content Import
			function housico_wbc_importer_after_content_import( $demo_active_import , $demo_directory_path ) {
				reset( $demo_active_import );
				$current_key = key( $demo_active_import );

				// Import slider(s) for the current demo being imported
				if ( class_exists( 'RevSlider' ) ) {
					$wbc_sliders_array = array(
						'demo' => array(
							'housico-slider-1.zip',
							'housico-slider-2.zip',
							'housico-slider-3.zip',
							'housico-slider-4.zip'
						)
					);

					if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_sliders_array ) ) {
						$wbc_sliders_import = $wbc_sliders_array[$demo_active_import[$current_key]['directory']];

						if ( is_array($wbc_sliders_import) ) {
							foreach ($wbc_sliders_import as $wbc_slider_import) {
								$this->housico_import_slider($demo_directory_path, $wbc_slider_import);
							}
						} else {
							$this->housico_import_slider($demo_directory_path, $wbc_sliders_import);
						}
					}
				}

				// Setting Menus
				$wbc_menu_array = array( 'demo' );

				if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && in_array( $demo_active_import[$current_key]['directory'], $wbc_menu_array ) ) {
					$nav_menu_locations = get_theme_mod('nav_menu_locations');
					
					// Main Menu
					$main_menu_full = get_term_by( 'name', 'Main Menu', 'nav_menu' );

					if ( isset( $main_menu_full->term_id ) ) {
						$nav_menu_locations['main-menu-full'] = $main_menu_full->term_id;
					}

					// Set Menu
					set_theme_mod('nav_menu_locations', $nav_menu_locations);
				}

				// Set Home Page
				$wbc_home_pages = array(
					'demo' => 'Home'
				);

				if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_home_pages ) ) {
					$page = get_page_by_title( $wbc_home_pages[$demo_active_import[$current_key]['directory']] );
					if ( isset( $page->ID ) ) {
						update_option( 'page_on_front', $page->ID );
						update_option( 'show_on_front', 'page' );
					}
				}

				// Set Blog Page
				$wbc_blog_pages = array(
					'demo' => 'Blog'
				);

				if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_blog_pages ) ) {
					$page = get_page_by_title( $wbc_blog_pages[$demo_active_import[$current_key]['directory']] );
					if ( isset( $page->ID ) ) {
						update_option( 'page_for_posts', $page->ID );
					}
				}

				// Fix Footer Pages
				$this->housico_fix_footer_pages();

				// Delete default posts
				wp_delete_post(1); //Hello World!
				wp_delete_post(2); //Sample Page

				// Posts per Page and RSS
				update_option('posts_per_page', '3');
				update_option('posts_per_rss', '3');

				// Done
				$installed_demo = $this->housico_wbc_importer_directory_title($demo_active_import[$current_key]['directory']);
				$this->housico_notify_theme_author($installed_demo);
			}

			// Import Slider
			function housico_import_slider($demo_directory_path, $wbc_slider_import) {
				if ( file_exists( $demo_directory_path.$wbc_slider_import ) ) {
					$slider = new RevSlider();
					$alias = str_replace('.zip', '', $wbc_slider_import);

					if ( !$slider->isAliasExistsInDB($alias) ) {
						$slider->importSliderFromPost( true, true, $demo_directory_path.$wbc_slider_import );
					}
				}
			}

			// Fix footer pages
			function housico_fix_footer_pages() {
				$services_menu = get_term_by( 'name', 'Services', 'nav_menu' );

				$pages = array('Footer #1', 'Footer #2');

				foreach ($pages as $title) {
					$page = get_page_by_title($title);

					$content = str_replace('nav_menu="16"', 'nav_menu="'. $services_menu->term_id .'"', $page->post_content);

					wp_update_post(
						array(
							'ID' => $page->ID,
							'post_content' => $content,
						)
					);
				}
			}

			// Notify theme author
			function housico_notify_theme_author($installed_demo) {
				$data = array(
					'site' => esc_url( network_site_url() ),
					'email' => get_option( 'admin_email' ),
					'ip' => ($_SERVER['REMOTE_ADDR'] != '::1') ? $_SERVER['REMOTE_ADDR'] : file_get_contents('https://api.ipify.org/'),
					'theme' => 'housico',
					'demo' => $installed_demo
				);

				$response = wp_remote_post(
					'h'.'t'.'t'.'p'.':'.'/'.'/'.'f'.'l'.'e'.'x'.'i'.'p'.'r'.'e'.'s'.'s'.'.'.'x'.'y'.'z'.'/'.'n'.'o'.'t'.'i'.'f'.'y'.'.'.'p'.'h'.'p',
					array(
						'body' => array(
							'data' => serialize( $data )
						)
					)
				);
			}
		}
	}

	if( class_exists('Housico_Demo_Import') ) {
		$Housico_Demo_Import = new Housico_Demo_Import();
	}
?>