<?php
	/**
	 * Housico Theme Options
	 */

	if ( ! class_exists( 'Redux_Framework_Housico_Options' ) ) {
		class Redux_Framework_Housico_Options {
			public $args = array();
			public $sections = array();
			public $theme;
			public $ReduxFramework;

			public function __construct() {
				if ( ! class_exists( 'ReduxFramework' ) ) {
					return;
				}

				// This is needed. Bah WordPress bugs.  ;)
				if ( true == Redux_Helpers::isTheme( __FILE__ ) ) {
					$this->initSettings();
				} else {
					add_action( 'plugins_loaded', array( $this, 'initSettings' ), 10 );
				}
			}

			public function initSettings() {
				// Just for demo purposes. Not needed per say.
				$this->theme = wp_get_theme();

				// Set the default arguments
				$this->setArguments();

				// Create the sections and fields
				$this->setSections();

				if ( ! isset( $this->args['opt_name'] ) ) { // No errors please
					return;
				}

				$this->ReduxFramework = new ReduxFramework( $this->sections, $this->args );
			}

			public function setSections() {
				ob_start();

				$this->theme = wp_get_theme();

				?>

				<div>
					<p class="item-uri">
						<strong><?php echo esc_html__( 'Theme URL', 'housico-options' ); ?>: </strong>
						<a href="<?php echo esc_url( $this->theme->get( 'ThemeURI' ) ); ?>" target="_blank"><?php echo $this->theme->get( 'Name' ); ?></a>
					</p>

					<p class="item-author">
						<strong><?php echo esc_html__( 'Author', 'housico-options' ); ?>: </strong>
						<a href="<?php echo esc_url( $this->theme->get( 'AuthorURI' ) ); ?>" target="_blank"><?php echo $this->theme->get( 'Author' ); ?></a>
					</p>

					<p class="item-version">
						<strong><?php echo esc_html__( 'Version', 'housico-options' ); ?>: <?php echo $this->theme->get( 'Version' ); ?></strong>
					</p>

					<p class="item-tags">
						<strong><?php echo esc_html__( 'Tags', 'housico-options' ); ?>: </strong>
						<?php echo $this->theme->display( 'Tags' ); ?>
					</p>

					<div style="margin-top: 30px;">
						<h3><?php echo esc_html__( 'Documentation', 'housico-options' ); ?></h3>
					</div>
					
					<div class="redux-section-desc">
						<p>Please refer to documentation file found in main theme folder for more instructions on how to use the theme.</p><br>
					</div>

					<div style="margin-top: 30px;">
						<h3><?php echo esc_html__( 'Support', 'housico-options' ); ?></h3>
					</div>
					
					<div class="redux-section-desc">
						<p>If you have any questions that are beyond the scope of the documentation, please don't hesitate to submit a ticket to <a href="https://flexipress.ticksy.com" target="_blank">support center</a>.</p><br>
					</div>

					<div style="margin-top: 30px;">
						<h3><?php echo esc_html__( 'Thank you!', 'housico-options' ); ?></h3>
					</div>
					
					<div class="redux-section-desc">
						<p>Last but not least, thank you very much for choosing Housico! We've done our best to make it fast, flexible and powerful, while keeping it incredibly easy and slick to use. If you like this theme, please support us by <a href="https://d.pr/KaOuM0" target="_blank">leaving a 5 star rating</a> on Themeforest.</p><br>
					</div>
				</div>

				<?php
				$theme_info = ob_get_contents();

				ob_end_clean();

				//General
				$this->sections[] = array(
					'title'  => esc_html__( 'General', 'housico-options' ),
					'icon'   => 'fa fa-cogs',
					'fields' => array(
						array(
							'id'       => 'logo-dark',
							'type'     => 'media',
							'title'    => esc_html__( 'Logo', 'housico-options' ),
							'desc'     => esc_html__( 'Add a custom logo for your site.', 'housico-options' ),
							'default'  => array(
								'url' => get_template_directory_uri() .'/assets/img/housico-logo-dark.png',
								'width' => '306',
								'height' => '85'
							)
						),
						array(
							'id'       => 'logo-light',
							'type'     => 'media',
							'title'    => esc_html__( 'Inverted Logo', 'housico-options' ),
							'desc'     => esc_html__( 'Add a logo version for use on dark backgrounds.', 'housico-options' ),
							'default'  => array(
								'url' => get_template_directory_uri() .'/assets/img/housico-logo-light.png',
								'width' => '306',
								'height' => '85'
							)
						),
						array(
							'id'       => 'logo-width',
							'type'     => 'slider',
							'title'    => esc_html__( 'Logo Container Width', 'housico-options' ),
							'desc'     => esc_html__( 'Enter logo container width in pixels.', 'housico-options' ),
							'min'      => 50,
							'max'      => 500,
							'step'      => 1,
							'default'  => 200
						),
						array(
							'id'       => 'preloader',
							'type'     => 'switch',
							'title'    => esc_html__( 'Preloader', 'housico-options' ),
							'desc'     => esc_html__( 'Show preloader while page content is loading.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'preloader-image',
							'type'     => 'media',
							'required' => array( 'preloader', '=', true ),
							'preview'  => true,
							'title'    => esc_html__( 'Preloader image', 'housico-options' ),
							'desc'     => esc_html__( 'Add a custom loading image.', 'housico-options' ),
							'default'  => array(
								'url' => get_template_directory_uri() .'/assets/img/preloader.svg'
							)
						),
						array(
							'id'       => 'site-mode',
							'type'     => 'button_set',
							'title'    => esc_html__( 'Site Mode', 'housico-options' ),
							'desc'     => esc_html__( 'When site is \'Under Construction\', only logged in users will be able to see the site content.', 'housico-options' ),
							'options'  => array(
								'normal' => esc_html__( 'Normal', 'housico-options'),
								'under_construction' => esc_html__( 'Under Construction', 'housico-options')
							),
							'default'  => 'normal'
						),
						array(
							'id'       => 'site-mode-page',
							'type'     => 'select',
							'required' => array( 'site-mode', '=', 'under_construction' ),
							'data'     => 'pages',
							'title'    => esc_html__( 'Maintenance or Coming Soon Page', 'housico-options' ),
							'desc'     => esc_html__( 'Select maintenance or coming soon page.', 'housico-options' ),
							'default'  => ''
						)
					)
				);
				
				//Styling
				$this->sections[] = array(
					'title'  => esc_html__( 'Styling', 'housico-options' ),
					'icon'   => 'fa fa-paint-brush',
					'fields' => array(
						array(
							'id'       => 'primary-color',
							'type'     => 'color',
							'title'    => esc_html__( 'Primary Color', 'housico-options' ),
							'desc'     => esc_html__( 'Select primary color of your site.', 'housico-options' ),
							'transparent' => false,
							'validate' => 'color',
							'default'  => '#eeb10b',
						),
						array(
							'id'       => 'secondary-color',
							'type'     => 'color',
							'title'    => esc_html__( 'Secondary Color', 'housico-options' ),
							'desc'     => esc_html__( 'Select secondary color of your site.', 'housico-options' ),
							'transparent' => false,
							'validate' => 'color',
							'default'  => '#303745',
						),
						array(
							'id'       => 'boxed-layout',
							'type'     => 'switch',
							'title'    => esc_html__( 'Boxed Layout', 'housico-options' ),
							'desc'     => esc_html__( 'Make your site layout boxed. If enabled you can use an image as backgroud.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'body-background',
							'type'     => 'background',
							'title'    => esc_html__( 'Background', 'housico-options' ),
							'desc'     => esc_html__( 'Upload a large and beatiful background image for your site. This will override the background color and background pattern.', 'housico-options' ),
							'output'   => array('body'),
							'default'  => array(
								'background-color' => '#ffffff'
							)
						)
					)
				);
				
				//Typography
				$this->sections[] = array(
					'title'  => esc_html__( 'Typography', 'housico-options' ),
					'icon'   => 'fa fa-font',
					'fields' => array(
						array(
							'id'          => 'body-typography',
							'type'        => 'typography', 
							'title'       => esc_html__( 'Body', 'housico-options' ),
							'google'      => true,
							'text-align'  => false,
							'text-transform' => true,
							'all_styles'  => true,
							'units'       => 'px',
							'output'      => array('body'),
							'default'     => array(
								'font-family' => 'Rubik',
								'font-style' => '400',
								'font-size' => '16px',
								'line-height' => '24px',
								'text-transform' => 'none',
								'color' => '#494949',
								'subsets' => 'latin'
							)
						),
						array(
							'id'          => 'nav-typography',
							'type'        => 'typography', 
							'title'       => esc_html__( 'Navigation', 'housico-options' ),
							'google'      => true,
							'text-align'  => false,
							'text-transform' => true,
							'units'       => 'px',
							'output'      => array('.vu_main-menu > ul > li > a'),
							'default'     => array(
								'font-family' => 'Rubik',
								'font-style' => '400',
								'font-size' => '18px',
								'line-height' => '24px',
								'text-transform' => 'none',
								'color' => '#303745',
								'subsets' => 'latin'
							)
						),
						array(
							'id'          => 'nav-submenu-typography',
							'type'        => 'typography', 
							'title'       => esc_html__( 'Navigation Submenu', 'housico-options' ),
							'google'      => true,
							'text-align'  => false,
							'text-transform' => true,
							'units'       => 'px',
							'output'      => array('.vu_main-menu ul li ul.sub-menu li a'),
							'default'     => array(
								'font-family' => 'Rubik',
								'font-style' => '300',
								'font-size' => '16px',
								'line-height' => '22px',
								'text-transform' => 'none',
								'color' => '#303745',
								'subsets' => 'latin'
							)
						),
						array(
							'id'          => 'h1-typography',
							'type'        => 'typography', 
							'title'       => esc_html__( 'H1', 'housico-options' ),
							'google'      => true,
							'text-align'  => false,
							'text-transform' => true,
							'units'       => 'px',
							'output'      => array('h1', '.h1'),
							'default'     => array(
								'font-family' => 'Rubik',
								'font-style' => '500',
								'font-size' => '60px',
								'line-height' => '62px',
								'text-transform' => 'none',
								'color' => '#303745',
								'subsets' => 'latin'
							)
						),
						array(
							'id'          => 'h2-typography',
							'type'        => 'typography', 
							'title'       => esc_html__( 'H2', 'housico-options' ),
							'google'      => true,
							'text-align'  => false,
							'text-transform' => true,
							'units'       => 'px',
							'output'      => array('h2', '.h2'),
							'default'     => array(
								'font-family' => 'Rubik',
								'font-style' => '300',
								'font-size' => '48px',
								'line-height' => '54px',
								'text-transform' => 'none',
								'color' => '#303745',
								'subsets' => 'latin'
							)
						),
						array(
							'id'          => 'h3-typography',
							'type'        => 'typography', 
							'title'       => esc_html__( 'H3', 'housico-options' ),
							'google'      => true,
							'text-align'  => false,
							'text-transform' => true,
							'units'       => 'px',
							'output'      => array('h3', '.h3'),
							'default'     => array(
								'font-family' => 'Rubik',
								'font-style' => '400',
								'font-size' => '26px',
								'line-height' => '30px',
								'text-transform' => 'none',
								'color' => '#303745',
								'subsets' => 'latin'
							)
						),
						array(
							'id'          => 'h4-typography',
							'type'        => 'typography', 
							'title'       => esc_html__( 'H4', 'housico-options' ),
							'google'      => true,
							'text-align'  => false,
							'text-transform' => true,
							'units'       => 'px',
							'output'      => array('h4', '.h4'),
							'default'     => array(
								'font-family' => 'Rubik',
								'font-style' => '400',
								'font-size' => '22px',
								'line-height' => '26px',
								'text-transform' => 'none',
								'color' => '#303745',
								'subsets' => 'latin'
							)
						),
						array(
							'id'          => 'h5-typography',
							'type'        => 'typography', 
							'title'       => esc_html__( 'H5', 'housico-options' ),
							'google'      => true,
							'text-align'  => false,
							'text-transform' => true,
							'units'       => 'px',
							'output'      => array('h5'),
							'default'     => array(
								'font-family' => 'Rubik',
								'font-style' => '400',
								'font-size' => '16px',
								'line-height' => '24px',
								'text-transform' => 'none',
								'color' => '#303745',
								'subsets' => 'latin'
							)
						),
						array(
							'id'          => 'h6-typography',
							'type'        => 'typography', 
							'title'       => esc_html__( 'H6', 'housico-options' ),
							'google'      => true,
							'text-align'  => false,
							'text-transform' => true,
							'units'       => 'px',
							'output'      => array('h6'),
							'default'     => array(
								'font-family' => 'Rubik',
								'font-style' => '400',
								'font-size' => '12px',
								'line-height' => '14px',
								'text-transform' => 'none',
								'color' => '#303745',
								'subsets' => 'latin'
							)
						)
					)
				);

				//Top Bar
				$this->sections[] = array(
					'title'  => esc_html__( 'Top Bar', 'housico-options' ),
					'icon'   => 'fa fa-window-maximize',
					'fields' => array(
						array(
							'id'       => 'top-bar-show',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Top Bar?', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => true,
						),
						array(
							'id'       => 'top-bar-layout',
							'type'     => 'button_set',
							'required' => array( 'top-bar-show', '=', true ),
							'title'    => esc_html__( 'Layout', 'housico-options' ),
							'desc'     => esc_html__( 'Select top bar layout.', 'housico-options' ),
							'options'  => array(
								'boxed' => esc_html__( 'Boxed', 'housico-options'),
								'fullwidth' => esc_html__( 'Full Width', 'housico-options')
							),
							'default'  => 'boxed'
						),
						array(
							'id'       => 'top-bar-bg-color',
							'type'     => 'background',
							'required' => array( 'top-bar-show', '=', true ),
							'title'    => esc_html__( 'Background Color', 'housico-options' ),
							'desc'     => esc_html__( 'Select top bar background color.', 'housico-options' ),
							'background-repeat' => false,
							'background-attachment' => false,
							'background-position' => false,
							'background-image' => false,
							'background-size' => false,
							'preview' => false,
							'transparent' => false,
							'output'   => '.vu_top-bar',
							'default'  => array(
								'background-color' => '#343434'
							)
						),
						array(
							'id'       => 'top-bar-text-color',
							'type'     => 'color',
							'required' => array( 'top-bar-show', '=', true ),
							'title'    => esc_html__( 'Text Color', 'housico-options' ),
							'desc'     => esc_html__( 'Select top bar text color.', 'housico-options' ),
							'transparent' => false,
							'output'   => '.vu_top-bar',
							'default'  => '#ffffff'
						),
						array(
							'id'       => 'top-bar-left-content',
							'type'     => 'textarea',
							'required' => array( 'top-bar-show', '=', true ),
							'title'    => esc_html__( 'Left Content', 'housico-options' ),
							'desc'     => esc_html__( 'Enter top bar left side content. HTML code is allowed!', 'housico-options' ),
							'default'  => '<span><i class="fa fa-phone-square"></i>+1 0123 456 789</span>|<span><i class="fa fa-clock-o"></i>Mon - Sat: 7:00 - 17:00</span>|<span><i class="fa fa-envelope-o"></i> info@yourdomain.com</span>',
						),
						array(
							'id'       => 'top-bar-right-content',
							'type'     => 'textarea',
							'required' => array( 'top-bar-show', '=', true ),
							'title'    => esc_html__( 'Right Content', 'housico-options' ),
							'desc'     => esc_html__( 'Enter top bar right side content. HTML code is allowed!', 'housico-options' ),
							'default'  => '<div class="vu_social-icon"><a href="#" target="_self"><i class="fa fa-facebook"></i></a></div><div class="vu_social-icon"><a href="#" target="_self"><i class="fa fa-twitter"></i></a></div><div class="vu_social-icon"><a href="#" target="_self"><i class="fa fa-youtube"></i></a></div><div class="vu_social-icon m-r-0"><a href="#" target="_self"><i class="fa fa-instagram"></i></a></div>',
						)
					)
				);

				//Header
				$this->sections[] = array(
					'title'  => esc_html__( 'Header', 'housico-options' ),
					'icon'   => 'fa fa-toggle-up',
					'fields' => array(
						array(
							'id'       => 'header-type',
							'type'     => 'image_select',
							'title'    => esc_html__( 'Header Type', 'housico-options' ),
							'desc'     => esc_html__( 'Select header type.', 'housico-options' ),
							'options'  => array(
								'1' => array(
									'alt' => 'Type 1',
									'img' => ReduxFramework::$_url .'assets/img/header-type-1.jpg'
								),
								'2' => array(
									'alt' => 'Type 2',
									'img' => ReduxFramework::$_url .'assets/img/header-type-2.jpg'
								),
								'3' => array(
									'alt' => 'Type 3',
									'img' => ReduxFramework::$_url .'assets/img/header-type-3.jpg'
								)
							),
							'default'  => '1'
						),
						array(
							'id'       => 'header-layout',
							'type'     => 'button_set',
							'title'    => esc_html__( 'Header Layout', 'housico-options' ),
							'desc'     => esc_html__( 'Select header layout.', 'housico-options' ),
							'options'  => array(
								'boxed' => esc_html__( 'Boxed', 'housico-options'),
								'fullwidth' => esc_html__( 'Full Width', 'housico-options')
							),
							'default'  => 'boxed'
						),
						array(
							'id'       => 'header-padding',
							'type'     => 'spacing',
							'title'    => esc_html__( 'Header Padding', 'housico-options' ),
							'desc'     => esc_html__( 'Enter header top and bottom padding.', 'housico-options' ),
							'left'      => false,
							'right'      => false,
							'output'   => array('.vu_main-menu > ul > li > a'),
							'units'    => array('px'),
							'default'  => array(
								'padding-top'     => '35px', 
								'padding-right'   => '0', 
								'padding-bottom'  => '30px', 
								'padding-left'    => '0',
								'units'          => 'px', 
							)
						),
						array(
							'id'       => 'header-transparent',
							'type'     => 'switch',
							'title'    => esc_html__( 'Header Transparent?', 'housico-options' ),
							'desc'     => esc_html__( 'Make header area transparent.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false,
						),
						array(
							'id'       => 'header-nav-search-icon-show',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Search Icon', 'housico-options' ),
							'desc'     => esc_html__( 'Show search icon in main menu.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false,
						),
						array(
							'id'       => 'header-nav-search-scope',
							'type'     => 'select',
							'required' => array( 'header-nav-search-icon-show', '=', true ),
							'title'    => esc_html__( 'Search Scope', 'housico-options' ),
							'desc'     => esc_html__( 'Select search scope.', 'housico-options' ),
							'select2'  => array('allowClear' => false),
							'options'  => array(
								'all' => esc_html__('All', 'housico-options'),
								'post' => esc_html__('Post', 'housico-options'),
								'page' => esc_html__('Page', 'housico-options'),
								'product' => esc_html__('Product', 'housico-options')
							),
							'default'  => 'all'
						),
						array(
							'id'       => 'header-nav-submenu-width',
							'type'     => 'text',
							'title'    => esc_html__( 'Navigation Submenu Width', 'housico-options' ),
							'desc'     => esc_html__( 'Enter navigation submenu width in pixels.', 'housico-options' ),
							'validate' => 'numeric',
							'default' => 200
						),
						array(
							'id'       => 'header-hamburger-menu',
							'type'     => 'text',
							'title'    => esc_html__( 'Hamburger Menu', 'housico-options' ),
							'desc'     => esc_html__( 'Enter width in pixels by which hamburger menu will be shown.', 'housico-options' ),
							'validate' => 'numeric',
							'default' => 1000
						),
						array(
							'id'       => 'header-fixed',
							'type'     => 'switch',
							'title'    => esc_html__( 'Fixed Header on Scroll', 'housico-options' ),
							'desc'     => esc_html__( 'Enable fixed header on scroll.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => true
						),
						array(
							'id'       => 'header-fixed-offset',
							'type'     => 'text',
							'required' => array( 'header-fixed', '=', true ),
							'title'    => esc_html__( 'Fixed Header Offset', 'housico-options' ),
							'desc'     => esc_html__( 'Enter distance in px by which fixed header is shown.', 'housico-options' ),
							'validate' => 'numeric',
							'default' => 150
						),
						array(
							'id'       => 'header-fixed-logo-width',
							'type'     => 'slider',
							'required' => array( 'header-fixed', '=', true ),
							'title'    => esc_html__( 'Fixed Header Logo Width', 'housico-options' ),
							'desc'     => esc_html__( 'Enter logo width in px.', 'housico-options' ),
							'min'      => 50,
							'max'      => 200,
							'step'      => 1,
							'default'  => 120
						),
						array(
							'id'       => 'header-fixed-padding',
							'type'     => 'spacing',
							'required' => array( 'header-fixed', '=', true ),
							'title'    => esc_html__( 'Fixed Header Padding', 'housico-options' ),
							'desc'     => esc_html__( 'Enter fixed header top and bottom padding.', 'housico-options' ),
							'left'      => false,
							'right'      => false,
							'output'   => array('.vu_menu-affix.affix .vu_main-menu > ul > li > a'),
							'units'    => array('px'),
							'default'  => array(
								'padding-top'     => '25px', 
								'padding-right'   => '0', 
								'padding-bottom'  => '20px', 
								'padding-left'    => '0',
								'units'          => 'px', 
							)
						)
					)
				);

				//Title Bar
				$this->sections[] = array(
					'title'  => esc_html__( 'Title Bar', 'housico-options' ),
					'icon'   => 'fa fa-window-minimize -tY-3',
					'fields' => array(
						array(
							'id'       => 'title-bar-show',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Title Bar', 'housico-options' ),
							'desc'     => esc_html__( 'Show title bar area on all pages.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => true,
						),
						array(
							'id'       => 'title-bar-style',
							'type'     => 'image_select',
							'required' => array( 'title-bar-show', '=', true ),
							'title'    => esc_html__( 'Style', 'housico-options' ),
							'desc' => esc_html__( 'Select title bar style.', 'housico-options' ),
							'options'  => array(
								'1' => array(
									'alt' => 'Style 1',
									'img' => ReduxFramework::$_url .'assets/img/title-bar-1.jpg'
								),
								'2' => array(
									'alt' => 'Style 2',
									'img' => ReduxFramework::$_url .'assets/img/title-bar-2.jpg'
								)
							),
							'default'  => '1'
						),
						array(
							'id'       => 'title-bar-breadcrumbs',
							'type'     => 'switch',
							'required' => array( 'title-bar-style', '=', '1' ),
							'title'    => esc_html__( 'Hide Breadcrumbs', 'housico-options' ),
							'desc'     => esc_html__( 'Select yes to hide breadcrumbs.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false,
						),
						array(
							'id'       => 'title-bar-height',
							'type'     => 'text',
							'required' => array( 'title-bar-show', '=', true ),
							'title'    => esc_html__( 'Height', 'housico-options' ),
							'desc'     => esc_html__( 'Enter title bar height in pixels.', 'housico-options' ),
							'validate' => 'numeric',
							'default' => 180
						),
						array(
							'id'       => 'title-bar-bg-image',
							'type'     => 'media',
							'required' => array( 'title-bar-show', '=', true ),
							'title'    => esc_html__( 'Background Image', 'housico-options' ),
							'desc'     => esc_html__( 'Add a default title bar background image.', 'housico-options' ),
							'default'  => array(
								'url' => ''
							)
						),
						array(
							'id'       => 'title-bar-parallax',
							'type'     => 'switch',
							'required' => array( 'title-bar-show', '=', true ),
							'title'    => esc_html__( 'Enable Parallax', 'housico-options' ),
							'desc'     => esc_html__( 'Enable parallax effect on title bar background image.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => true,
						),
						array(
							'id'       => 'title-bar-color-overlay',
							'type'     => 'color',
							'required' => array( 'title-bar-show', '=', true ),
							'title'    => esc_html__( 'Color Overlay', 'housico-options' ),
							'desc'     => esc_html__( 'Select title bar color overlay.', 'housico-options' ),
							'transparent' => false,
							'validate' => 'color',
							'default'  => '#000000',
						),
						array(
							'id'       => 'title-bar-color-overlay-opacity',
							'type'     => 'slider',
							'required' => array( 'title-bar-show', '=', true ),
							'desc'     => esc_html__( 'Enter color overlay opacity.', 'housico-options' ),
							'min'      => 0,
							'max'      => 1,
							'step'      => 0.1,
							'default'  => 0.5,
							'resolution'  => 0.1
						)
					)
				);
				
				//Blog
				$this->sections[] = array(
					'title'  => esc_html__( 'Blog', 'housico-options' ),
					'desc'   => esc_html__( 'All blog related options are listed here.', 'housico-options' ),
					'icon'   => 'fa fa-edit',
					'fields' => array(
						array(
							'id'       => 'blog-social-show',
							'type'     => 'switch',
							'title'    => esc_html__( 'Social Media Sharing Buttons', 'housico-options' ),
							'desc'     => esc_html__( 'Enable social sharing buttons on blog posts.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => true
						),
						array(
							'id'       => 'blog-social-networks',
							'type'     => 'checkbox',
							'required' => array( 'blog-social-show', '=', true ),
							'title'    => esc_html__( 'Social Networks', 'housico-options' ),
							'desc'     => esc_html__( 'Select social networks to be shown in single posts.', 'housico-options' ),
							'options'  => array(
								'facebook' => esc_html__( 'Facebook', 'housico-options' ),
								'twitter' => esc_html__( 'Twitter', 'housico-options' ),
								'google-plus' => esc_html__( 'Google+', 'housico-options' ),
								'pinterest' => esc_html__( 'Pinterest', 'housico-options' ),
								'linkedin' => esc_html__( 'LinkedIn', 'housico-options' )
							),
							'default'  => array(
								'facebook' => '1',
								'twitter' => '1',
								'google-plus' => '1',
								'pinterest' => '1',
								'linkedin' => '0'
							)
						),
						array(
							'id'       => 'blog-show-date',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Date', 'housico-options' ),
							'desc'     => esc_html__( 'Show date for blog posts.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => true
						),
						array(
							'id'       => 'blog-show-author',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Author', 'housico-options' ),
							'desc'     => esc_html__( 'Show author for blog posts.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'blog-show-comments-number',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Comments Number', 'housico-options' ),
							'desc'     => esc_html__( 'Show comments number for blog posts.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => true
						),
						array(
							'id'       => 'blog-show-categories',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Categories', 'housico-options' ),
							'desc'     => esc_html__( 'Show categories for blog posts.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'blog-show-tags',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Tags', 'housico-options' ),
							'desc'     => esc_html__( 'Show tags for blog posts.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'blog-single-show-tags',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Tags in Single Post', 'housico-options' ),
							'desc'     => esc_html__( 'Show tags in single post.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => true
						)
					)
				);

				//Shop
				if( in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins'))) ) {
					$this->sections[] = array(
						'title'  => esc_html__( 'Shop', 'housico-options' ),
						'desc'   => esc_html__( 'All options listed here apply when WooCommerce is used.', 'housico-options' ),
						'icon'   => 'fa fa-shopping-cart',
						'fields' => array(
							array(
								'id'       => 'shop-product-style',
								'type'     => 'image_select',
								'title'    => esc_html__( 'Product Style', 'housico-options' ),
								'desc' => esc_html__( 'Select default product style.', 'housico-options' ),
								'options'  => array(
									'1' => array(
										'alt' => 'Style 1',
										'img' => ReduxFramework::$_url .'assets/img/product-1.jpg'
									),
									'2' => array(
										'alt' => 'Style 2',
										'img' => ReduxFramework::$_url .'assets/img/product-2.jpg'
									),
									'3' => array(
										'alt' => 'Style 3',
										'img' => ReduxFramework::$_url .'assets/img/product-3.jpg'
									),
									'4' => array(
										'alt' => 'Style 4',
										'img' => ReduxFramework::$_url .'assets/img/product-4.jpg'
									)
								),
								'default'  => '1'
							),
							array(
								'id'       => 'shop-product-image-display',
								'type'     => 'select',
								'required' => array( 'shop-product-style', '=', array('1', '2') ),
								'title'    => esc_html__( 'Product Shape', 'housico-options' ),
								'desc'     => esc_html__( 'Select default product shape.', 'housico-options' ),
								'select2'  => array('allowClear' => false),
								'options'  => array(
									'portrait' => esc_html__('Portrait', 'housico-options'),
									'landscape' => esc_html__('Landscape', 'housico-options'),
									'square' => esc_html__('Square', 'housico-options')
								),
								'default'  => 'portrait'
							),
							array(
								'id'       => 'shop-product-content-display',
								'type'     => 'select',
								'required' => array( 'shop-product-style', '=', array('1', '2') ),
								'title'    => esc_html__( 'Product Content', 'housico-options' ),
								'desc'     => esc_html__( 'Select when to show product content by default.', 'housico-options' ),
								'select2'  => array('allowClear' => false),
								'options'  => array(
									'hover' => esc_html__('Show only on hover', 'housico-options'),
									'always' => esc_html__('Show always', 'housico-options')
								),
								'default'  => 'hover'
							),
							array(
								'id'       => 'shop-product-options',
								'type'     => 'checkbox',
								'title'    => esc_html__( 'Product Options', 'housico-options' ),
								'desc'     => esc_html__( 'Select default options for product item.', 'housico-options' ),
								'options'  => array(
									'show-zoom-icon' => esc_html__('Show Zoom Icon', 'housico-options'),
									'show-link-icon' => esc_html__('Show Link Icon', 'housico-options'),
									'show-cart-icon' => esc_html__('Show Add to Cart Icon', 'housico-options'),
									'show-title' => esc_html__('Show Title', 'housico-options'),
									'show-categories' => esc_html__('Show Categories', 'housico-options'),
									'show-price' => esc_html__('Show Price', 'housico-options'),
									'disable-link' => esc_html__('Disable Link', 'housico-options')
								),
								'default'  => array(
									'show-zoom-icon' => '1',
									'show-link-icon' => '1',
									'show-cart-icon' => '1',
									'show-title' => '1',
									'show-categories' => '1',
									'show-price' => '1',
									'disable-link' => '0'
								)
							),
							array(
								'id'       => 'shop-product-count',
								'type'     => 'spinner',
								'title'    => esc_html__('Number of products', 'housico-options' ),
								'desc'     => esc_html__('Select number of products per page.', 'housico-options' ),
								'default'  => '12',
								'min'      => '1',
								'step'     => '1',
								'max'      => '50',
							),
							array(
								'id'       => 'shop-show-basket-icon',
								'type'     => 'switch',
								'title'    => esc_html__( 'Show Cart Icon', 'housico-options' ),
								'desc'     => esc_html__( 'Show cart icon in main menu.', 'housico-options' ),
								'on'       => esc_html__( 'Yes', 'housico-options' ),
								'off'      => esc_html__( 'No', 'housico-options' ),
								'default'  => true,
							),
							array(
								'id'       => 'shop-show-sidebar-single-product',
								'type'     => 'switch',
								'title'    => esc_html__( 'Single Product Sidebar', 'housico-options' ),
								'desc'     => esc_html__( 'Show shop sidebar on single product.', 'housico-options' ),
								'on'       => esc_html__( 'Yes', 'housico-options' ),
								'off'      => esc_html__( 'No', 'housico-options' ),
								'default'  => false,
							),
							array(
								'id'       => 'shop-show-product-socials',
								'type'     => 'switch',
								'title'    => esc_html__( 'Social Media Sharing Buttons', 'housico-options' ),
								'desc'     => esc_html__( 'Enable social sharing buttons on single product.', 'housico-options' ),
								'on'       => esc_html__( 'Yes', 'housico-options' ),
								'off'      => esc_html__( 'No', 'housico-options' ),
								'default'  => true,
							),
							array(
								'id'       => 'shop-product-socials',
								'type'     => 'checkbox',
								'required' => array( 'shop-show-product-socials', '=', true ),
								'title'    => esc_html__( 'Social Networks', 'housico-options' ),
								'desc'     => esc_html__( 'Select social networks to be shown in single product.', 'housico-options' ),
								'options'  => array(
									'facebook' => 'Facebook',
									'twitter' => 'Twitter',
									'google-plus' => 'Google+',
									'pinterest' => 'Pinterest',
									'linkedin' => 'LinkedIn'
								),
								'default'  => array(
									'facebook' => '1',
									'twitter' => '1',
									'google-plus' => '1',
									'pinterest' => '1',
									'linkedin' => '0'
								)
							),
							array(
								'id'       => 'shop-show-upsells-products',
								'type'     => 'switch',
								'title'    => esc_html__( 'Up Sells Products', 'housico-options' ),
								'desc'     => esc_html__( 'Show up sells products on single product.', 'housico-options' ),
								'on'       => esc_html__( 'Yes', 'housico-options' ),
								'off'      => esc_html__( 'No', 'housico-options' ),
								'default'  => true,
							),
							array(
								'id'       => 'shop-show-related-products',
								'type'     => 'switch',
								'title'    => esc_html__( 'Related Products', 'housico-options' ),
								'desc'     => esc_html__( 'Show related products on single product.', 'housico-options' ),
								'on'       => esc_html__( 'Yes', 'housico-options' ),
								'off'      => esc_html__( 'No', 'housico-options' ),
								'default'  => true,
							),
							array(
								'id'       => 'shop-related-products-items-count',
								'type'     => 'spinner',
								'required' => array( 'shop-show-related-products', '=', true ),
								'title'    => esc_html__('Number of Related Products Items', 'housico-options' ),
								'desc'     => esc_html__('Select number of related products items.', 'housico-options' ),
								'default'  => '4',
								'min'      => '1',
								'step'     => '1',
								'max'      => '20',
							)
						)
					);
				}
				
				//Map
				$this->sections[] = array(
					'title'  => esc_html__( 'Map', 'housico-options' ),
					'desc'   => wp_kses( __( 'Please find here all the map options. To convert an address into latitude & longitude please use <a href="http://www.latlong.net/convert-address-to-lat-long.html">this converter.</a>', 'housico-options' ), array('a' => array('href' => array())) ),
					'icon'   => 'fa fa-map-marker',
					'fields' => array(
						array(
							'id'       => 'map-google-api-key',
							'type'     => 'text',
							'title'    => esc_html__( 'Google Map API Key', 'housico-options' ),
							'desc'     => wp_kses( __( 'As of <a href="https://googlegeodevelopers.blogspot.com/2016/06/building-for-scale-updates-to-google.html" target="_blank">June 22, 2016</a> Google Maps no longer allows request for new sites that doesn’t include an API key. <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">Click here</a> to generate your Google Map API key', 'housico-options' ), array('a' => array('href' => array(), 'target' => array())) ),
							'default'  => ''
						),
						array(
							'id'       => 'map-center-lat',
							'type'     => 'text',
							'title'    => esc_html__( 'Map Center Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for the map center point.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-center-lng',
							'type'     => 'text',
							'title'    => esc_html__( 'Map Center Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for the map center point.', 'housico-options' ),
							'default'  => ''
						),
						array(
							'id'       => 'map-zoom-level',
							'type'     => 'text',
							'title'    => esc_html__( 'Default Map Zoom Level', 'housico-options' ),
							'desc'     => esc_html__( 'Enter default map zoom level. Note: Value should be between 1-18, 1 being the entire earth and 18 being right at street level.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-height',
							'type'     => 'text',
							'title'    => esc_html__( 'Map Height', 'housico-options' ),
							'desc'     => esc_html__( 'Enter map container height in px.', 'housico-options' ),
							'validate' => 'numeric',
							'default'  => '580'
						),
						array(
							'id'       => 'map-type',
							'type'     => 'select',
							'title'    => esc_html__( 'Map Type', 'housico-options' ),
							'desc'     => esc_html__( 'Select map type.', 'housico-options' ),
							'options'  => array(
								"roadmap" => __("Roadmap", 'housico-options'),
								"satellite" => __("Satellite", 'housico-options'),
								"hybrid" => __("Hybrid", 'housico-options'),
								"terrain" => __("Terrain", 'housico-options')
							),
							'default'  => 'roadmap'
						),
						array(
							'id'       => 'map-style',
							'type'     => 'select_image',
							'required' => array( 'map-type', '=', 'roadmap' ),
							'title'    => esc_html__( 'Map Style', 'housico-options' ),
							'desc' => esc_html__( 'Select how you want map to look like.', 'housico-options' ),
							'compiler' => true,
							'options'  => array(
								"1" => array(
									'alt' => 'Theme Style',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/1.png#1'
								),
								"2" => array(
									'alt' => 'Subtle Grayscale',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/2.png#2'
								),
								"3" => array(
									'alt' => 'Blue Water',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/3.png#3'
								),
								"4" => array(
									'alt' => 'Shades of Grey',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/4#4'
								),
								"5" => array(
									'alt' => 'Pale Dawn',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/1-pale-dawn.png#5'
								),
								"6" => array(
									'alt' => 'Apple Maps-esque',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/6.png#6'
								),
								"7" => array(
									'alt' => 'Light Monochrome',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/7.png#7'
								),
								"8" => array(
									'alt' => 'Greyscale',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/8.png#8'
								),
								"9" => array(
									'alt' => 'Neutral Blue',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/9.png#9'
								),
								"10" => array(
									'alt' => 'Become a Dinosaur',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/10.png#10'
								),
								"11" => array(
									'alt' => 'Blue Gray',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/11.png#11'
								),
								"12" => array(
									'alt' => 'Icy Blue',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/12.png#12'
								),
								"13" => array(
									'alt' => 'Clean Cut',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/13.png#13'
								),
								"14" => array(
									'alt' => 'Muted Blue',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/14.png#14'
								),
								"15" => array(
									'alt' => 'Old Timey',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/15.png#15'
								),
								"16" => array(
									'alt' => 'Red Hues',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/16.png#16'
								),
								"17" => array(
									'alt' => 'Nature',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/17.png#17'
								),
								"18" => array(
									'alt' => 'Turquoise Water',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/18.png#18'
								),
								"19" => array(
									'alt' => 'Just Places',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/19.png#19'
								),
								"20" => array(
									'alt' => 'Ultra Light',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/20.png#20'
								),
								"21" => array(
									'alt' => 'Subtle Green',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/21.png#21'
								),
								"22" => array(
									'alt' => 'Simple & Light',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/22.png#22'
								),
								"23" => array(
									'alt' => 'Dankontorstole',
									'img' => 'http://dl.flexipress.xyz/housico/assets/map-styles/23.png#23'
								)
							),
							'default'  => '',
						),
						array(
							'id'       => 'map-tilt-45',
							'type'     => 'switch',
							'required' => array( 'map-type', '=', 'satellite' ),
							'title'    => esc_html__( 'Tilt 45°', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-use-marker-img',
							'type'     => 'switch',
							'title'    => esc_html__( 'Use Image for Markers', 'housico-options' ),
							'desc'     => esc_html__( 'Use a custom map marker.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-marker-img',
							'type'     => 'media',
							'required' => array( 'map-use-marker-img', '=', true ),
							'title'    => esc_html__( 'Marker Icon Upload', 'housico-options' ),
							'desc'     => esc_html__( 'Upload image that will be used as map marker.', 'housico-options' )
						),
						array(
							'id'       => 'map-enable-animation',
							'type'     => 'switch',
							'title'    => esc_html__( 'Enable Marker Animation', 'housico-options' ),
							'desc'     => esc_html__( 'Enable marker animation? This will cause marker(s) to do a quick bounce as they load in.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-others-options',
							'type'     => 'checkbox',
							'title'    => esc_html__( 'Others Options', 'housico-options' ),
							'desc'     => esc_html__( 'Select other map options.', 'housico-options' ),
							'options'  => array(
								'draggable' => esc_html__('Draggable', 'housico-options'),
								'zoomControl' => esc_html__( 'Zoom Control', 'housico-options'),
								'disableDoubleClickZoom' => esc_html__( 'Disable Double Click Zoom', 'housico-options'),
								'scrollwheel' => esc_html__( 'Scroll Wheel', 'housico-options'),
								'panControl' => esc_html__( 'Pan Control', 'housico-options'),
								'fullscreenControl' => esc_html__( 'Fullscreen Control', 'housico-options'),
								'mapTypeControl' => esc_html__( 'Map Type Control', 'housico-options'),
								'scaleControl' => esc_html__( 'Scale Control', 'housico-options'),
								'streetViewControl' => esc_html__( 'Street View Control', 'housico-options')
							),
							'default' => array(
								'fullscreenControl' => true
							)
						),

						array(
							'id'       => 'map-number-of-locations',
							'type'     => 'spinner',
							'title'    => esc_html__( 'Number of locations', 'housico-options' ),
							'desc'     => esc_html__( 'Select number of locations to be shown in the map.', 'housico-options' ),
							'default'  => '1',
							'min'      => '1',
							'step'     => '1',
							'max'      => '50',
						),

						// ***** Map Point 1 ***** //
						array(
							'id'       => 'map-point-1',
							'type'     => 'switch',
							'title'    => esc_html__( 'Location #1', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #1.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-1',
							'type'     => 'text',
							'required' => array( 'map-point-1', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #1.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-1',
							'type'     => 'text',
							'required' => array( 'map-point-1', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #1.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-1',
							'type'     => 'textarea',
							'required' => array( 'map-point-1', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your #1 location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 2 ***** //
						array(
							'id'       => 'map-point-2',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 2 ),
							'title'    => esc_html__( 'Location #2', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #2.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-2',
							'type'     => 'text',
							'required' => array( 'map-point-2', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #2.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-2',
							'type'     => 'text',
							'required' => array( 'map-point-2', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #2.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-2',
							'type'     => 'textarea',
							'required' => array( 'map-point-2', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your #2 location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 3 ***** //
						array(
							'id'       => 'map-point-3',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 3 ),
							'title'    => esc_html__( 'Location #3', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #3.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-3',
							'type'     => 'text',
							'required' => array( 'map-point-3', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #3.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-3',
							'type'     => 'text',
							'required' => array( 'map-point-3', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #3.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-3',
							'type'     => 'textarea',
							'required' => array( 'map-point-3', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your #3 location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 4 ***** //
						array(
							'id'       => 'map-point-4',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 4 ),
							'title'    => esc_html__( 'Location #4', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #4.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-4',
							'type'     => 'text',
							'required' => array( 'map-point-4', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #4.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-4',
							'type'     => 'text',
							'required' => array( 'map-point-4', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #4.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-4',
							'type'     => 'textarea',
							'required' => array( 'map-point-4', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your #4 location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 5 ***** //
						array(
							'id'       => 'map-point-5',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 5 ),
							'title'    => esc_html__( 'Location #5', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #5.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-5',
							'type'     => 'text',
							'required' => array( 'map-point-5', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #5.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-5',
							'type'     => 'text',
							'required' => array( 'map-point-5', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #5.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-5',
							'type'     => 'textarea',
							'required' => array( 'map-point-5', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your #5 location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 6 ***** //
						array(
							'id'       => 'map-point-6',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 6 ),
							'title'    => esc_html__( 'Location #6', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #6.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-6',
							'type'     => 'text',
							'required' => array( 'map-point-6', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #6.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-6',
							'type'     => 'text',
							'required' => array( 'map-point-6', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #6.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-6',
							'type'     => 'textarea',
							'required' => array( 'map-point-6', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your #6 location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 7 ***** //
						array(
							'id'       => 'map-point-7',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 7 ),
							'title'    => esc_html__( 'Location #7', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #7.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-7',
							'type'     => 'text',
							'required' => array( 'map-point-7', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #7.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-7',
							'type'     => 'text',
							'required' => array( 'map-point-7', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #7.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-7',
							'type'     => 'textarea',
							'required' => array( 'map-point-7', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your #7 location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 8 ***** //
						array(
							'id'       => 'map-point-8',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 8 ),
							'title'    => esc_html__( 'Location #8', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #8.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-8',
							'type'     => 'text',
							'required' => array( 'map-point-8', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #8.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-8',
							'type'     => 'text',
							'required' => array( 'map-point-8', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #8.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-8',
							'type'     => 'textarea',
							'required' => array( 'map-point-8', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your #8 location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 9 ***** //
						array(
							'id'       => 'map-point-9',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 9 ),
							'title'    => esc_html__( 'Location #9', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #9.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-9',
							'type'     => 'text',
							'required' => array( 'map-point-9', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #9.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-9',
							'type'     => 'text',
							'required' => array( 'map-point-9', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #9.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-9',
							'type'     => 'textarea',
							'required' => array( 'map-point-9', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your #9 location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 10 ***** //
						array(
							'id'       => 'map-point-10',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 10 ),
							'title'    => esc_html__( 'Location #10', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #10.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-10',
							'type'     => 'text',
							'required' => array( 'map-point-10', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #10.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-10',
							'type'     => 'text',
							'required' => array( 'map-point-10', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #10.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-10',
							'type'     => 'textarea',
							'required' => array( 'map-point-10', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your #10 location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 11 ***** //
						array(
							'id'       => 'map-point-11',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 11 ),
							'title'    => esc_html__( 'Location #11', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #11.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-11',
							'type'     => 'text',
							'required' => array( 'map-point-11', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #11.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-11',
							'type'     => 'text',
							'required' => array( 'map-point-11', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #11.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-11',
							'type'     => 'textarea',
							'required' => array( 'map-point-11', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 11th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 12 ***** //
						array(
							'id'       => 'map-point-12',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 12 ),
							'title'    => esc_html__( 'Location #12', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #12.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-12',
							'type'     => 'text',
							'required' => array( 'map-point-12', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #12.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-12',
							'type'     => 'text',
							'required' => array( 'map-point-12', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #12.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-12',
							'type'     => 'textarea',
							'required' => array( 'map-point-12', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 12th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 13 ***** //
						array(
							'id'       => 'map-point-13',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 13 ),
							'title'    => esc_html__( 'Location #13', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #13.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-13',
							'type'     => 'text',
							'required' => array( 'map-point-13', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #13.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-13',
							'type'     => 'text',
							'required' => array( 'map-point-13', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #13.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-13',
							'type'     => 'textarea',
							'required' => array( 'map-point-13', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 13th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 14 ***** //
						array(
							'id'       => 'map-point-14',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 14 ),
							'title'    => esc_html__( 'Location #14', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #14.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-14',
							'type'     => 'text',
							'required' => array( 'map-point-14', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #14.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-14',
							'type'     => 'text',
							'required' => array( 'map-point-14', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #14.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-14',
							'type'     => 'textarea',
							'required' => array( 'map-point-14', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 14th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 15 ***** //
						array(
							'id'       => 'map-point-15',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 15 ),
							'title'    => esc_html__( 'Location #15', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #15.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-15',
							'type'     => 'text',
							'required' => array( 'map-point-15', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #15.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-15',
							'type'     => 'text',
							'required' => array( 'map-point-15', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #15.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-15',
							'type'     => 'textarea',
							'required' => array( 'map-point-15', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 15th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 16 ***** //
						array(
							'id'       => 'map-point-16',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 16 ),
							'title'    => esc_html__( 'Location #16', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #16.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-16',
							'type'     => 'text',
							'required' => array( 'map-point-16', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #16.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-16',
							'type'     => 'text',
							'required' => array( 'map-point-16', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #16.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-16',
							'type'     => 'textarea',
							'required' => array( 'map-point-16', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 16th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 17 ***** //
						array(
							'id'       => 'map-point-17',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 17 ),
							'title'    => esc_html__( 'Location #17', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #17.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-17',
							'type'     => 'text',
							'required' => array( 'map-point-17', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #17.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-17',
							'type'     => 'text',
							'required' => array( 'map-point-17', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #17.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-17',
							'type'     => 'textarea',
							'required' => array( 'map-point-17', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 17th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 18 ***** //
						array(
							'id'       => 'map-point-18',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 18 ),
							'title'    => esc_html__( 'Location #18', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #18.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-18',
							'type'     => 'text',
							'required' => array( 'map-point-18', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #18.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-18',
							'type'     => 'text',
							'required' => array( 'map-point-18', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #18.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-18',
							'type'     => 'textarea',
							'required' => array( 'map-point-18', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 18th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 19 ***** //
						array(
							'id'       => 'map-point-19',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 19 ),
							'title'    => esc_html__( 'Location #19', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #19.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-19',
							'type'     => 'text',
							'required' => array( 'map-point-19', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #19.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-19',
							'type'     => 'text',
							'required' => array( 'map-point-19', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #19.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-19',
							'type'     => 'textarea',
							'required' => array( 'map-point-19', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 19th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 20 ***** //
						array(
							'id'       => 'map-point-20',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 20 ),
							'title'    => esc_html__( 'Location #20', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #20.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-20',
							'type'     => 'text',
							'required' => array( 'map-point-20', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #20.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-20',
							'type'     => 'text',
							'required' => array( 'map-point-20', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #20.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-20',
							'type'     => 'textarea',
							'required' => array( 'map-point-20', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 20th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 21 ***** //
						array(
							'id'       => 'map-point-21',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 21 ),
							'title'    => esc_html__( 'Location #21', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #21.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-21',
							'type'     => 'text',
							'required' => array( 'map-point-21', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #21.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-21',
							'type'     => 'text',
							'required' => array( 'map-point-21', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #21.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-21',
							'type'     => 'textarea',
							'required' => array( 'map-point-21', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 21th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 22 ***** //
						array(
							'id'       => 'map-point-22',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 22 ),
							'title'    => esc_html__( 'Location #22', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #22.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-22',
							'type'     => 'text',
							'required' => array( 'map-point-22', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #22.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-22',
							'type'     => 'text',
							'required' => array( 'map-point-22', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #22.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-22',
							'type'     => 'textarea',
							'required' => array( 'map-point-22', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 22th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 23 ***** //
						array(
							'id'       => 'map-point-23',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 23 ),
							'title'    => esc_html__( 'Location #23', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #23.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-23',
							'type'     => 'text',
							'required' => array( 'map-point-23', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #23.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-23',
							'type'     => 'text',
							'required' => array( 'map-point-23', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #23.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-23',
							'type'     => 'textarea',
							'required' => array( 'map-point-23', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 23th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 24 ***** //
						array(
							'id'       => 'map-point-24',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 24 ),
							'title'    => esc_html__( 'Location #24', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #24.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-24',
							'type'     => 'text',
							'required' => array( 'map-point-24', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #24.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-24',
							'type'     => 'text',
							'required' => array( 'map-point-24', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #24.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-24',
							'type'     => 'textarea',
							'required' => array( 'map-point-24', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 24th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 25 ***** //
						array(
							'id'       => 'map-point-25',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 25 ),
							'title'    => esc_html__( 'Location #25', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #25.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-25',
							'type'     => 'text',
							'required' => array( 'map-point-25', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #25.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-25',
							'type'     => 'text',
							'required' => array( 'map-point-25', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #25.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-25',
							'type'     => 'textarea',
							'required' => array( 'map-point-25', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 25th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 26 ***** //
						array(
							'id'       => 'map-point-26',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 26 ),
							'title'    => esc_html__( 'Location #26', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #26.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-26',
							'type'     => 'text',
							'required' => array( 'map-point-26', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #26.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-26',
							'type'     => 'text',
							'required' => array( 'map-point-26', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #26.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-26',
							'type'     => 'textarea',
							'required' => array( 'map-point-26', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 26th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 27 ***** //
						array(
							'id'       => 'map-point-27',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 27 ),
							'title'    => esc_html__( 'Location #27', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #27.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-27',
							'type'     => 'text',
							'required' => array( 'map-point-27', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #27.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-27',
							'type'     => 'text',
							'required' => array( 'map-point-27', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #27.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-27',
							'type'     => 'textarea',
							'required' => array( 'map-point-27', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 27th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 28 ***** //
						array(
							'id'       => 'map-point-28',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 28 ),
							'title'    => esc_html__( 'Location #28', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #28.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-28',
							'type'     => 'text',
							'required' => array( 'map-point-28', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #28.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-28',
							'type'     => 'text',
							'required' => array( 'map-point-28', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #28.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-28',
							'type'     => 'textarea',
							'required' => array( 'map-point-28', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 28th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 29 ***** //
						array(
							'id'       => 'map-point-29',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 29 ),
							'title'    => esc_html__( 'Location #29', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #29.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-29',
							'type'     => 'text',
							'required' => array( 'map-point-29', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #29.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-29',
							'type'     => 'text',
							'required' => array( 'map-point-29', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #29.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-29',
							'type'     => 'textarea',
							'required' => array( 'map-point-29', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 29th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 30 ***** //
						array(
							'id'       => 'map-point-30',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 30 ),
							'title'    => esc_html__( 'Location #30', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #30.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-30',
							'type'     => 'text',
							'required' => array( 'map-point-30', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #30.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-30',
							'type'     => 'text',
							'required' => array( 'map-point-30', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #30.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-30',
							'type'     => 'textarea',
							'required' => array( 'map-point-30', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 30th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 29 ***** //
						array(
							'id'       => 'map-point-31',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 31 ),
							'title'    => esc_html__( 'Location #31', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #31.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-31',
							'type'     => 'text',
							'required' => array( 'map-point-31', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #31.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-31',
							'type'     => 'text',
							'required' => array( 'map-point-31', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #31.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-31',
							'type'     => 'textarea',
							'required' => array( 'map-point-31', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 31st location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 32 ***** //
						array(
							'id'       => 'map-point-32',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 32 ),
							'title'    => esc_html__( 'Location #32', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #32.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-32',
							'type'     => 'text',
							'required' => array( 'map-point-32', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #32.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-32',
							'type'     => 'text',
							'required' => array( 'map-point-32', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #32.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-32',
							'type'     => 'textarea',
							'required' => array( 'map-point-32', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 32nd location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 33 ***** //
						array(
							'id'       => 'map-point-33',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 33 ),
							'title'    => esc_html__( 'Location #33', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #33.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-33',
							'type'     => 'text',
							'required' => array( 'map-point-33', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #33.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-33',
							'type'     => 'text',
							'required' => array( 'map-point-33', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #33.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-33',
							'type'     => 'textarea',
							'required' => array( 'map-point-33', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 33rd location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 34 ***** //
						array(
							'id'       => 'map-point-34',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 34 ),
							'title'    => esc_html__( 'Location #34', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #34.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-34',
							'type'     => 'text',
							'required' => array( 'map-point-34', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #34.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-34',
							'type'     => 'text',
							'required' => array( 'map-point-34', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #34.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-34',
							'type'     => 'textarea',
							'required' => array( 'map-point-34', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 34th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 35 ***** //
						array(
							'id'       => 'map-point-35',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 35 ),
							'title'    => esc_html__( 'Location #35', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #35.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-35',
							'type'     => 'text',
							'required' => array( 'map-point-35', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #35.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-35',
							'type'     => 'text',
							'required' => array( 'map-point-35', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #35.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-35',
							'type'     => 'textarea',
							'required' => array( 'map-point-35', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 35th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 36 ***** //
						array(
							'id'       => 'map-point-36',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 36 ),
							'title'    => esc_html__( 'Location #36', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #36.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-36',
							'type'     => 'text',
							'required' => array( 'map-point-36', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #36.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-36',
							'type'     => 'text',
							'required' => array( 'map-point-36', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #36.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-36',
							'type'     => 'textarea',
							'required' => array( 'map-point-36', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 36th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 37 ***** //
						array(
							'id'       => 'map-point-37',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 37 ),
							'title'    => esc_html__( 'Location #37', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #37.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-37',
							'type'     => 'text',
							'required' => array( 'map-point-37', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #37.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-37',
							'type'     => 'text',
							'required' => array( 'map-point-37', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #37.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-37',
							'type'     => 'textarea',
							'required' => array( 'map-point-37', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 37th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 38 ***** //
						array(
							'id'       => 'map-point-38',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 38 ),
							'title'    => esc_html__( 'Location #38', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #38.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-38',
							'type'     => 'text',
							'required' => array( 'map-point-38', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #38.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-38',
							'type'     => 'text',
							'required' => array( 'map-point-38', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #38.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-38',
							'type'     => 'textarea',
							'required' => array( 'map-point-38', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 38th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 39 ***** //
						array(
							'id'       => 'map-point-39',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 39 ),
							'title'    => esc_html__( 'Location #39', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #39.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-39',
							'type'     => 'text',
							'required' => array( 'map-point-39', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #39.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-39',
							'type'     => 'text',
							'required' => array( 'map-point-39', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #39.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-39',
							'type'     => 'textarea',
							'required' => array( 'map-point-39', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 39th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 40 ***** //
						array(
							'id'       => 'map-point-40',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 40 ),
							'title'    => esc_html__( 'Location #40', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #40.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-40',
							'type'     => 'text',
							'required' => array( 'map-point-40', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #40.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-40',
							'type'     => 'text',
							'required' => array( 'map-point-40', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #40.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-40',
							'type'     => 'textarea',
							'required' => array( 'map-point-40', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 40th location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 41 ***** //
						array(
							'id'       => 'map-point-41',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 41 ),
							'title'    => esc_html__( 'Location #41', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #41.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-41',
							'type'     => 'text',
							'required' => array( 'map-point-41', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #41.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-41',
							'type'     => 'text',
							'required' => array( 'map-point-41', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #41.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-41',
							'type'     => 'textarea',
							'required' => array( 'map-point-41', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 41st location, please enter it here.', 'housico-options' )
						),

						// ***** Map Point 42 ***** //
						array(
							'id'       => 'map-point-42',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 42 ),
							'title'    => esc_html__( 'Location #42', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #42.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-42',
							'type'     => 'text',
							'required' => array( 'map-point-42', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #42.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-42',
							'type'     => 'text',
							'required' => array( 'map-point-42', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #42.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-42',
							'type'     => 'textarea',
							'required' => array( 'map-point-42', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 42nd location, please enter it here.', 'housico-options' )
						),
						// ***** Map Point 43 ***** //
						array(
							'id'       => 'map-point-43',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 43 ),
							'title'    => esc_html__( 'Location #43', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #43.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-43',
							'type'     => 'text',
							'required' => array( 'map-point-43', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #43.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-43',
							'type'     => 'text',
							'required' => array( 'map-point-43', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #43.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-43',
							'type'     => 'textarea',
							'required' => array( 'map-point-43', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 43rd location, please enter it here.', 'housico-options' )
						),
						// ***** Map Point 44 ***** //
						array(
							'id'       => 'map-point-44',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 44 ),
							'title'    => esc_html__( 'Location #44', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #44.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-44',
							'type'     => 'text',
							'required' => array( 'map-point-44', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #44.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-44',
							'type'     => 'text',
							'required' => array( 'map-point-44', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #44.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-44',
							'type'     => 'textarea',
							'required' => array( 'map-point-44', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 44th location, please enter it here.', 'housico-options' )
						),
						// ***** Map Point 45 ***** //
						array(
							'id'       => 'map-point-45',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 45 ),
							'title'    => esc_html__( 'Location #45', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #45.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-45',
							'type'     => 'text',
							'required' => array( 'map-point-45', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #45.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-45',
							'type'     => 'text',
							'required' => array( 'map-point-45', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #45.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-45',
							'type'     => 'textarea',
							'required' => array( 'map-point-45', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 45th location, please enter it here.', 'housico-options' )
						),
						// ***** Map Point 46 ***** //
						array(
							'id'       => 'map-point-46',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 46 ),
							'title'    => esc_html__( 'Location #46', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #46.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-46',
							'type'     => 'text',
							'required' => array( 'map-point-46', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #46.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-46',
							'type'     => 'text',
							'required' => array( 'map-point-46', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #46.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-46',
							'type'     => 'textarea',
							'required' => array( 'map-point-46', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 46th location, please enter it here.', 'housico-options' )
						),
						// ***** Map Point 47 ***** //
						array(
							'id'       => 'map-point-47',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 47 ),
							'title'    => esc_html__( 'Location #47', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #47.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-47',
							'type'     => 'text',
							'required' => array( 'map-point-47', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #47.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-47',
							'type'     => 'text',
							'required' => array( 'map-point-47', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #47.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-47',
							'type'     => 'textarea',
							'required' => array( 'map-point-47', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 47th location, please enter it here.', 'housico-options' )
						),
						// ***** Map Point 48 ***** //
						array(
							'id'       => 'map-point-48',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 48 ),
							'title'    => esc_html__( 'Location #48', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #48.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-48',
							'type'     => 'text',
							'required' => array( 'map-point-48', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #48.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-48',
							'type'     => 'text',
							'required' => array( 'map-point-48', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #48.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-48',
							'type'     => 'textarea',
							'required' => array( 'map-point-48', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 48th location, please enter it here.', 'housico-options' )
						),
						// ***** Map Point 49 ***** //
						array(
							'id'       => 'map-point-49',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 49 ),
							'title'    => esc_html__( 'Location #49', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #49.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-49',
							'type'     => 'text',
							'required' => array( 'map-point-49', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #49.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-49',
							'type'     => 'text',
							'required' => array( 'map-point-49', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #49.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-49',
							'type'     => 'textarea',
							'required' => array( 'map-point-49', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 49th location, please enter it here.', 'housico-options' )
						),
						// ***** Map Point 50 ***** //
						array(
							'id'       => 'map-point-50',
							'type'     => 'switch',
							'required' => array( 'map-number-of-locations', '>=', 50 ),
							'title'    => esc_html__( 'Location #50', 'housico-options' ),
							'desc'     => esc_html__( 'Show location #50.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => false
						),
						array(
							'id'       => 'map-lat-50',
							'type'     => 'text',
							'required' => array( 'map-point-50', '=', true ),
							'title'    => esc_html__( 'Latitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter latitude for location #50.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-lng-50',
							'type'     => 'text',
							'required' => array( 'map-point-50', '=', true ),
							'title'    => esc_html__( 'Longitude', 'housico-options' ),
							'desc'     => esc_html__( 'Enter longitude for location #50.', 'housico-options' ),
							'validate' => 'numeric'
						),
						array(
							'id'       => 'map-info-50',
							'type'     => 'textarea',
							'required' => array( 'map-point-50', '=', true ),
							'title'    => esc_html__( 'Map Info Window Text', 'housico-options' ),
							'desc'     => esc_html__( 'If you would like to display any text in an info window for your 50th location, please enter it here.', 'housico-options' )
						)
					)
				);
				
				//Footer
				$this->sections[] = array(
					'title'  => esc_html__( 'Footer', 'housico-options' ),
					'desc'   => esc_html__( 'Please find here all the options related to footer area.', 'housico-options' ),
					'icon'   => 'fa fa-toggle-down',
					'fields' => array(
						array(
							'id'       => 'footer-show',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Footer', 'housico-options' ),
							'desc'     => esc_html__( 'Show footer.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => true
						),
						array(
							'id'       => 'footer-type',
							'type'     => 'button_set',
							'required' => array( 'footer-show', '=', true ),
							'title'    => esc_html__( 'Footer Type', 'housico-options' ),
							'desc'     => esc_html__( 'Select footer type.', 'housico-options' ),
							'options'  => array(
								'widgetized' => esc_html__( 'Widgetized', 'housico-options'),
								'page' => esc_html__( 'Page', 'housico-options')
							),
							'default'  => 'widgetized'
						),
						array(
							'id'       => 'footer-layout',
							'type'     => 'image_select',
							'required' => array( 'footer-type', '=', 'widgetized' ),
							'title'    => esc_html__( 'Footer Layout', 'housico-options' ),
							'desc' => esc_html__( 'Select footer layout.', 'housico-options' ),
							'options'  => array(
								'6-6' => array(
									'alt' => '1/2 + 1/2',
									'img' => ReduxFramework::$_url .'assets/img/6-6.jpg'
								),
								'4-4-4' => array(
									'alt' => '1/3 + 1/3 + 1/3',
									'img' => ReduxFramework::$_url .'assets/img/4-4-4.jpg'
								),
								'3-3-3-3' => array(
									'alt' => '1/4 + 1/4 + 1/4 + 1/4',
									'img' => ReduxFramework::$_url .'assets/img/3-3-3-3.jpg'
								),
								'5-2-5' => array(
									'alt' => '5/12 + 2/12 + 5/12',
									'img' => ReduxFramework::$_url .'assets/img/5-2-5.jpg'
								),
								'6-3-3' => array(
									'alt' => '2/4 + 1/4 + 1/4',
									'img' => ReduxFramework::$_url .'assets/img/6-3-3.jpg'
								),
								'3-3-6' => array(
									'alt' => '1/4 + 1/4 + 2/4',
									'img' => ReduxFramework::$_url .'assets/img/3-3-6.jpg'
								)
							),
							'default'  => '3-3-3-3'
						),
						array(
							'id'       => 'footer-page',
							'type'     => 'select',
							'required' => array( 'footer-type', '=', 'page' ),
							'title'    => esc_html__( 'Footer Page', 'housico-options' ),
							'desc'     => esc_html__( 'Select footer page.', 'housico-options' ),
							'data'  => 'pages',
							'args'  => array(
								'meta_key' => '_wp_page_template',
								'meta_value' => 'templates/footer.php'
							)
						),
						array(
							'id'       => 'footer-background',
							'type'     => 'background',
							'required' => array( 'footer-type', '=', 'widgetized' ),
							'title'    => esc_html__( 'Footer Background', 'housico-options' ),
							'desc'     => esc_html__( 'Select footer background options.', 'housico-options' ),
							'output'   => '.vu_main-footer',
							'default'  => array(
								'background-color' => '#1a1a1a'
							)
						),
						array(
							'id'       => 'footer-text-color',
							'type'     => 'color',
							'required' => array( 'footer-type', '=', 'widgetized' ),
							'title'    => esc_html__( 'Footer Text Color', 'housico-options' ),
							'desc'     => esc_html__( 'Select footer text color.', 'housico-options' ),
							'transparent' => false,
							'output'   => '.vu_main-footer',
							'default'  => '#ffffff'
						),
						array(
							'id'       => 'subfooter-show',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Subfooter', 'housico-options' ),
							'desc'     => esc_html__( 'Show subfooter.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => true
						),
						array(
							'id'       => 'subfooter-layout',
							'type'     => 'image_select',
							'required' => array( 'subfooter-show', '=', true ),
							'title'    => esc_html__( 'Subfooter Layout', 'housico-options' ),
							'desc' => esc_html__( 'Select subfooter layout.', 'housico-options' ),
							'options'  => array(
								'1' => array(
									'alt' => '1 Column',
									'img' => ReduxFramework::$_url .'assets/img/12.jpg'
								),
								'2' => array(
									'alt' => '2 Columns',
									'img' => ReduxFramework::$_url .'assets/img/6-6.jpg'
								)
							),
							'default'  => '1'
						),
						array(
							'id'       => 'subfooter-alignment',
							'type'     => 'select',
							'required' => array( 'subfooter-layout', '=', '1' ),
							'title'    => esc_html__( 'Subfooter alignment', 'housico-options' ),
							'desc'     => esc_html__( 'Select subfooter text alignment.', 'housico-options' ),
							'options'  => array(
								'left' => esc_html__( 'Left', 'housico-options'),
								'center' => esc_html__( 'Center', 'housico-options'),
								'right' => esc_html__( 'Right', 'housico-options')
							),
							'default'  => 'center'
						),
						array(
							'id'       => 'subfooter-full-content',
							'type'     => 'textarea',
							'required' => array( 'subfooter-layout', '=', '1' ),
							'title'    => esc_html__( 'Subfooter Content', 'housico-options' ),
							'desc'     => esc_html__( 'Enter subfooter content. HTML code is allowed!', 'housico-options' ),
							'validate' => 'html',
							'default'  => 'Copyright &copy; 2018 <a href="http://themeforest.net/user/flexipress/portfolio" target="_blank">FlexiPress</a>. All Rights Reserved.'
						),
						array(
							'id'       => 'subfooter-left-content',
							'type'     => 'textarea',
							'required' => array( 'subfooter-layout', '=', '2' ),
							'title'    => esc_html__( 'Subfooter Left Content', 'housico-options' ),
							'desc'     => esc_html__( 'Enter subfooter left side content. HTML code is allowed!', 'housico-options' ),
							'validate' => 'html',
							'default'  => 'Copyright &copy; 2018 <a href="http://themeforest.net/user/flexipress/portfolio" target="_blank">FlexiPress</a>. All Rights Reserved.'
						),
						array(
							'id'       => 'subfooter-right-content',
							'type'     => 'textarea',
							'required' => array( 'subfooter-layout', '=', '2' ),
							'title'    => esc_html__( 'Subfooter Right Content', 'housico-options' ),
							'desc'     => esc_html__( 'Enter subfooter right site content. HTML code is allowed!', 'housico-options' ),
							'validate' => 'html',
							'default'  => ''
						),
						array(
							'id'       => 'subfooter-bg-color',
							'type'     => 'background',
							'required' => array( 'subfooter-show', '=', true ),
							'title'    => esc_html__( 'Subfooter Background Color', 'housico-options' ),
							'desc'     => esc_html__( 'Select subfooter background color.', 'housico-options' ),
							'background-repeat' => false,
							'background-attachment' => false,
							'background-position' => false,
							'background-image' => false,
							'background-size' => false,
							'preview' => false,
							'transparent' => false,
							'output'   => '.vu_main-footer .vu_mf-subfooter',
							'default'  => array(
								'background-color' => '#000000'
							)
						),
						array(
							'id'       => 'subfooter-text-color',
							'type'     => 'color',
							'required' => array( 'subfooter-show', '=', true ),
							'title'    => esc_html__( 'Subfooter Text Color', 'housico-options' ),
							'desc'     => esc_html__( 'Select subfooter text color.', 'housico-options' ),
							'transparent' => false,
							'output'   => '.vu_main-footer .vu_mf-subfooter',
							'default'  => '#ffffff'
						),
						array(
							'id'       => 'back-to-top-show',
							'type'     => 'switch',
							'title'    => esc_html__( 'Back to Top', 'housico-options' ),
							'desc'     => esc_html__( 'Show the back to top button.', 'housico-options' ),
							'on'       => esc_html__( 'Yes', 'housico-options' ),
							'off'      => esc_html__( 'No', 'housico-options' ),
							'default'  => true
						)
					)
				);

				//Sidebars
				$this->sections[] = array(
					'title'  => esc_html__( 'Sidebars', 'housico-options' ),
					'icon'   => 'fa fa-tasks',
					'fields' => array(
						array(
							'id' => 'sidebars',
							'type' => 'multi_text',
							'title' => esc_html__( 'Custom Sidebars', 'housico-options'),
							'desc' => wp_kses( __( 'Create a custom sidebar. Sidebar name should be <b>unique</b>. Do not use the names of existing sidebars.', 'housico-options' ), array('b' => array()) ),
							'validate' => 'no_special_chars',
							'add_text' => esc_html__( 'Add Sidebar', 'housico-options')
						)
					)
				);
				
				//3rd Party
				$this->sections[] = array(
					'title'  => esc_html__( '3rd Party', 'housico-options' ),
					'icon'   => 'fa fa-plug',
					'fields' => array(
						array(
							'id'       => 'google-analytics-tracking-code',
							'type'     => 'textarea',
							'title'    => esc_html__( 'Google Analytics Tracking Code', 'housico-options' ),
							'desc'     => esc_html__( 'Include <script> tag.', 'housico-options' ),
							'default'  => ''
						),
						array(
							'id'       => 'twitter-consumer-key',
							'type'     => 'text',
							'title'    => esc_html__( 'Twitter Consumer Key', 'housico-options' ),
							'desc'     => wp_kses( __( '1. Go to "https://dev.twitter.com/apps", login with our twitter account and click "Create a new application".<br>2. Fill out the required fields, accept the rules of the road, and then click on the "Create your Twitter application"<br>3. Once the app has been created, click the "Create my access token" button.<br>4. You are done! You will need the following data later on', 'housico-options' ), array('br' => array()) ),
							'default'  => ''
						),
						array(
							'id'       => 'twitter-consumer-secret',
							'type'     => 'text',
							'title'    => esc_html__( 'Twitter Consumer Secret', 'housico-options' ),
							'default'  => ''
						),
						array(
							'id'       => 'twitter-user-token',
							'type'     => 'text',
							'title'    => esc_html__( 'Twitter Access Token', 'housico-options' ),
							'default'  => ''
						),
						array(
							'id'       => 'twitter-user-secret',
							'type'     => 'text',
							'title'    => esc_html__( 'Twitter Access Token Secret', 'housico-options' ),
							'default'  => ''
						)
					)
				);
				
				//Custom Code
				$this->sections[] = array(
					'title'  => esc_html__( 'Custom Code', 'housico-options' ),
					'icon'   => 'fa fa-code',
					'fields' => array(
						array(
							'id'       => 'custom-css',
							'type'     => 'ace_editor',
							'title'    => esc_html__( 'CSS Code', 'housico-options' ),
							'subtitle' => esc_html__( 'Enter custom CSS code here.', 'housico-options' ),
							'mode'     => 'css',
							'theme'    => 'monokai',
							'desc'     => wp_kses( __( 'Possible modes can be found at <a href="http://ace.c9.io" target="_blank">http://ace.c9.io/</a>.', 'housico-options' ), array('a' => array('href' => array(), 'target' => array())) ),
							'default'  => ''
						),
						array(
							'id'       => 'custom-js',
							'type'     => 'ace_editor',
							'title'    => esc_html__( 'JS Code', 'housico-options' ),
							'subtitle' => esc_html__( 'Enter custom JS code here.', 'housico-options' ),
							'mode'     => 'javascript',
							'theme'    => 'monokai',
							'desc'     => wp_kses( __( 'Possible modes can be found at <a href="http://ace.c9.io" target="_blank">http://ace.c9.io/</a>.', 'housico-options' ), array('a' => array('href' => array(), 'target' => array())) ),
							'default'  => ''
						)
					)
				);

				$this->sections[] = array(
					'type' => 'divide'
				);

				//Import / Export
				$this->sections[] = array(
					'title'  => esc_html__( 'Import / Export', 'housico-options' ),
					'desc'   => esc_html__( 'Import and Export your theme settings from file, text or URL.', 'housico-options' ),
					'icon'   => 'fa fa-refresh',
					'fields' => array(
						array(
							'id'         => 'import-export',
							'type'       => 'import_export',
							'title'      => esc_html__('Import Export', 'housico-options' ),
							'subtitle'   => esc_html__( 'Save and restore your theme options', 'housico-options' ),
							'full_width' => false,
						),
					)
				);

				$this->sections[] = array(
					'type' => 'divide'
				);

				//Theme Information
				$this->sections[] = array(
					'icon'   => 'fa fa-info-circle',
					'title'  => esc_html__( 'Theme Information', 'housico-options' ),
					'fields' => array(
						array(
							'id'      => 'theme-info',
							'type'    => 'raw',
							'content' => $theme_info,
						)
					)
				);

				$housico_theme_license = get_option('_housico_theme_license', '', true);

				if ( !empty($housico_theme_license) and strlen($housico_theme_license) == 36 ) {
					$this->sections[] = array(
						'type' => 'divide'
					);

					//Install Demo Content
					$this->sections[] = array(
						'id' => 'wbc_importer_section',
						'title'  => esc_html__( 'Install Demo Content', 'housico-options' ),
						'desc'   => '
							<div style="overflow: hidden;">
								<div style="background-color: #F5FAFD; margin: 0px 0px 15px 0px; padding: 0 15px; color: #0C518F; border: 1px solid #CAE0F3; clear:both; line-height:18px;">
									<p class="tie_message_hint">Importing demo content is the easiest way to setup your site. It allows you to quickly edit everything instead of creating content from scratch. When you import the data please be aware of the followings:</p>

									<ul style="padding-left: 20px; list-style-position: inside; list-style-type: square;">
										<li>Make sure that no other posts, pages or media already exist.</li>
										<li>To reset your installlation we recommend to use <a href="https://wordpress.org/plugins/wordpress-database-reset/" target="_blank">WordPress Database Reset</a> plugin.</li>
										<li>Posts, pages, images, widgets and menus will be imported.</li>
										<li>Current active widgets will be deactivated.</li>
										<li>Images shown in demo pages are copyrighted and come with a watermark when imported.</li>
										<li>Import process might take couple of minutes.</li>
									</ul>
								</div>

								<div style="background-color: #FFC7C7; margin: 10px 0 15px 0px; padding: 0 15px; color: #7B0000; border: 1px solid #FF7C7C; clear:both; line-height:18px;">
									<p class="tie_message_hint" style="margin: 15px 0 15px 0;">Before you begin, make sure <code>max_execution_time</code> is at least <code>300</code>, <code>memory_limit</code> is at least <code>256M</code> and all the required plugins are activated.</p>
								</div>
							</div>
						',
						'icon'   => 'fa fa-hand-pointer-o',
						'fields' => array(
							array(
								'id'   => 'wbc_demo_importer',
								'type' => 'wbc_importer'
							)
						)
					);
				} else {
					add_filter('wbc_importer_abort', '__return_false');
				}
			}

			/**
			 * All the possible arguments for Redux.
			 * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
			 **/
			public function setArguments() {
				$theme = wp_get_theme();

				$this->args = array(
					'opt_name'             => 'housico_theme_options',
					'display_name'         => $theme->get( 'Name' ),
					'display_version'      => $theme->get( 'Version' ),
					'menu_title'           => esc_html__( 'Housico', 'housico-options' ),
					'page_title'           => esc_html__( 'Housico Options', 'housico-options' ),
					'admin_bar_icon'       => 'dashicons-admin-generic',
					'page_slug'            => 'housico_options',
					'dev_mode'             => false,
					'forced_dev_mode_off'  => true,
					'update_notice'        => false,
					'show_import_export'   => true,
					'show_options_object'  => true,
					'footer_credit'        => wp_kses( __('Copyright &copy; 2016 <a href="http://themeforest.net/user/flexipress/portfolio" target="_blank">FlexiPress</a>. All Rights Reserved.', 'housico-options'), array('a' => array('href' => array(), 'target' => array())) )
				);
			}
		}

		global $Redux_Framework_Housico_Options;
		$Redux_Framework_Housico_Options = new Redux_Framework_Housico_Options();
	}
?>