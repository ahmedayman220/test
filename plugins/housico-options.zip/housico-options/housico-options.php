<?php 
	/*
		Plugin Name: Housico Options
		Plugin URI: https://themeforest.net/item/housico-ultimate-construction-building-company-theme/21801770
		Author: FlexiPress
		Author URI: http://themeforest.net/user/flexipress
		Description: This plugin is required in order for the theme to work properly. It includes advanced and flexible options that have been developed exclusively for this theme.
		Version: 1.0
		Text Domain: housico-options
		Domain Path: /languages
		License: GNU General Public License v2 or later
		License URI: license/README_License.txt
	*/

	if ( !defined('ABSPATH') ) exit();

	// Check if theme license is valid or current theme is 'housico'
	$housico_theme_license = get_option('_housico_theme_license', '', true);
	$housico_theme_info = json_decode(get_option('_housico_theme_info', '', true), true);

	if ( empty($housico_theme_license) or strlen($housico_theme_license) != 36 or (!isset($housico_theme_info['name']) and $housico_theme_info['name'] != 'housico') ) {
		return;
	}

	if ( !class_exists('Housico_Options') ) {
		class Housico_Options {
			public static $_version = '1.0';
			public static $_dir;
            public static $_url;
			
			public function __construct() {
				// Variables
				self::$_dir = plugin_dir_path( __FILE__ );
				self::$_url = plugin_dir_url( __FILE__ );

				// Framework
				require_once(self::$_dir .'framework/framework.php');
				
				// Options
				require_once(self::$_dir .'options.php');
				
				// Demo Import
				require_once(self::$_dir .'demo-import.php');

				// Actions
				add_action('init', array($this, 'load_plugin_textdomain'));
			}

			// Plugin Textdomain
			public function load_plugin_textdomain() {
				$textdomain = 'housico-options';

				$locale = apply_filters( 'plugin_locale', get_locale(), $textdomain );

				if ( $loaded = load_textdomain( $textdomain, trailingslashit( WP_LANG_DIR ) . $textdomain . '/' . $textdomain . '-' . $locale . '.mo' ) ) {
					return $loaded;
				} else {
					load_plugin_textdomain( $textdomain, false, self::$_dir . 'languages/' );
				}
			}
		}
	}

	if ( class_exists('Housico_Options') ) {
		$Housico_Options = new Housico_Options();
	}
?>